const { db, authenticate, requireAdmin, sendError, method, jsonObject } = require('./_lib');
module.exports = async (req, res) => {
  try {
    method(req, ['GET', 'PUT']);
    const user = await authenticate(req);
    const sql = db();
    if (req.method === 'GET') {
      const rows = await sql`SELECT documento_id AS id, dados FROM jogo_documentos WHERE colecao = 'eventos'`;
      return res.status(200).json({ sucesso: true, eventos: rows.map(r => ({ id: r.id, ...r.dados })) });
    }
    requireAdmin(user);
    const { id, evento } = req.body || {};
    if (typeof id !== 'string' || !/^[a-zA-Z0-9_-]{1,100}$/.test(id)) { const e = new Error('Identificador de evento inválido.'); e.status = 400; throw e; }
    const dados = jsonObject(evento);
    await sql`INSERT INTO jogo_documentos (colecao, documento_id, dados, atualizado_em)
      VALUES ('eventos', ${id}, ${JSON.stringify(dados)}::jsonb, NOW())
      ON CONFLICT (colecao, documento_id) DO UPDATE SET dados = EXCLUDED.dados, atualizado_em = NOW()`;
    return res.status(200).json({ sucesso: true, mensagem: 'Evento salvo no Neon.' });
  } catch (e) { return sendError(res, e); }
};
