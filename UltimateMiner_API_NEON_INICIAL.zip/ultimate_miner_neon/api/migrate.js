const { db, firebaseAdmin, sendError, method } = require('./_lib');
module.exports = async (req, res) => {
  try {
    method(req, ['POST']);
    const secret = process.env.MIGRATION_SECRET;
    if (!secret) { const e = new Error('MIGRATION_SECRET não configurada na Vercel.'); e.status = 500; throw e; }
    if ((req.headers['x-migration-secret'] || '') !== secret) { const e = new Error('Chave de migração incorreta.'); e.status = 401; throw e; }
    const firestore = firebaseAdmin().firestore();
    const sql = db();
    const collections = ['jogadores', 'rankingGlobal', 'eventos'];
    const resumo = {};
    for (const collectionName of collections) {
      let last = null, total = 0;
      while (true) {
        let query = firestore.collection(collectionName).orderBy('__name__').limit(200);
        if (last) query = query.startAfter(last);
        const snap = await query.get();
        if (snap.empty) break;
        for (const doc of snap.docs) {
          const data = doc.data() || {};
          // Migração idempotente: se já existir, preserva dados mais novos no Neon.
          await sql`INSERT INTO jogo_documentos (colecao, documento_id, dados, atualizado_em, migrado_em)
            VALUES (${collectionName}, ${doc.id}, ${JSON.stringify(data)}::jsonb, NOW(), NOW())
            ON CONFLICT (colecao, documento_id) DO NOTHING`;
          total++;
        }
        last = snap.docs[snap.docs.length - 1];
        if (snap.size < 200) break;
      }
      resumo[collectionName] = total;
    }
    return res.status(200).json({ sucesso: true, mensagem: 'Cópia inicial concluída. Os documentos originais continuam no Firebase; documentos já existentes no Neon foram preservados.', copiados: resumo });
  } catch (e) { return sendError(res, e); }
};
