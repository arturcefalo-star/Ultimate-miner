const { db, authenticate, sendError, method } = require('./_lib');
module.exports = async (req, res) => {
  try {
    method(req, ['GET']);
    await authenticate(req);
    const sql = db();
    const rows = await sql`SELECT documento_id AS id, dados FROM jogo_documentos WHERE colecao = 'rankingGlobal' ORDER BY COALESCE((dados->>'moedas')::numeric, 0) DESC LIMIT 500`;
    return res.status(200).json({ sucesso: true, jogadores: rows.map(r => ({ id: r.id, ...r.dados })) });
  } catch (e) { return sendError(res, e); }
};
