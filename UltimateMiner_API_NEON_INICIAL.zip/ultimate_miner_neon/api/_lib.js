const { neon } = require('@neondatabase/serverless');
const admin = require('firebase-admin');

function db() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL não configurada na Vercel.');
  return neon(process.env.DATABASE_URL);
}
function firebaseAdmin() {
  if (!admin.apps.length) {
    const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
    if (!raw) throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON não configurada na Vercel.');
    let serviceAccount;
    try { serviceAccount = JSON.parse(raw); }
    catch (_) { throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON não contém JSON válido.'); }
    admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
  }
  return admin;
}
async function authenticate(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) { const e = new Error('Faça login para continuar.'); e.status = 401; throw e; }
  try { return await firebaseAdmin().auth().verifyIdToken(token); }
  catch (_) { const e = new Error('Sessão inválida ou expirada. Entre novamente.'); e.status = 401; throw e; }
}
function requireAdmin(user) {
  if (user.uid !== (process.env.ADMIN_UID || 'fWMMFNbKxmYozmkwsAwPTJO2skI3')) {
    const e = new Error('Acesso permitido somente ao administrador.'); e.status = 403; throw e;
  }
}
function sendError(res, err) {
  const status = Number(err.status) || 500;
  if (status >= 500) console.error(err);
  return res.status(status).json({ sucesso: false, erro: status >= 500 ? 'Erro interno da API.' : err.message });
}
function method(req, allowed) {
  if (!allowed.includes(req.method)) { const e = new Error('Método não permitido.'); e.status = 405; throw e; }
}
function jsonObject(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) { const e = new Error('O campo dados precisa ser um objeto JSON.'); e.status = 400; throw e; }
  return value;
}
module.exports = { db, firebaseAdmin, authenticate, requireAdmin, sendError, method, jsonObject };
