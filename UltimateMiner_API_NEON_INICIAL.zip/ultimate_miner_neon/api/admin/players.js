const { db, authenticate, requireAdmin, sendError, method } = require('../_lib');
module.exports = async (req, res) => {
  try {
    method(req, ['GET']);
    const user = await authenticate(req);
    requireAdmin(user);
    const sql = db();
    const rows = await sql`SELECT documento_id AS id, dados FROM jogo_documentos WHERE colecao = 'jogadores' ORDER BY atualizado_em DESC LIMIT 1000`;
    return res.status(200).json({ sucesso: true, jogadores: rows.map(r => ({ id: r.id, ...r.dados })) });
  } catch (e) { return sendError(res, e); }
};
