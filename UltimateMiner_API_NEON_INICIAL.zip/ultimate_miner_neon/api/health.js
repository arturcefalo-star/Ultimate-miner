const { db, sendError, method } = require('./_lib');
module.exports = async (req, res) => {
  try {
    method(req, ['GET']);
    const sql = db();
    const rows = await sql`SELECT NOW() AS horario`;
    return res.status(200).json({ sucesso: true, neon: 'conectado', horario: rows[0].horario });
  } catch (e) { return sendError(res, e); }
};
