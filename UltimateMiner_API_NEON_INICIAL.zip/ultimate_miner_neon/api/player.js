const { db, authenticate, sendError, method, jsonObject } = require('./_lib');
module.exports = async (req, res) => {
  try {
    method(req, ['GET', 'PUT']);
    const user = await authenticate(req);
    const sql = db();
    if (req.method === 'GET') {
      const rows = await sql`SELECT dados FROM jogo_documentos WHERE colecao = 'jogadores' AND documento_id = ${user.uid} LIMIT 1`;
      return res.status(200).json({ sucesso: true, existe: !!rows.length, jogador: rows[0]?.dados || null });
    }
    const body = req.body || {};
    const dados = jsonObject(body.jogador);
    await sql`INSERT INTO jogo_documentos (colecao, documento_id, dados, atualizado_em)
      VALUES ('jogadores', ${user.uid}, ${JSON.stringify(dados)}::jsonb, NOW())
      ON CONFLICT (colecao, documento_id) DO UPDATE SET dados = EXCLUDED.dados, atualizado_em = NOW()`;
    return res.status(200).json({ sucesso: true, mensagem: 'Jogador salvo no Neon.' });
  } catch (e) { return sendError(res, e); }
};
