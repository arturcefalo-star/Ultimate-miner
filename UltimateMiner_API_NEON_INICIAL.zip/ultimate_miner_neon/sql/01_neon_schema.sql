-- Ultimate Miner: armazenamento compatível com os documentos atuais do Firestore.
-- Não apaga nem altera nenhuma tabela antiga.
CREATE TABLE IF NOT EXISTS jogo_documentos (
  colecao TEXT NOT NULL,
  documento_id TEXT NOT NULL,
  dados JSONB NOT NULL DEFAULT '{}'::jsonb,
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  migrado_em TIMESTAMPTZ,
  PRIMARY KEY (colecao, documento_id)
);
CREATE INDEX IF NOT EXISTS jogo_documentos_colecao_idx ON jogo_documentos (colecao);
CREATE INDEX IF NOT EXISTS jogo_documentos_atualizado_idx ON jogo_documentos (atualizado_em DESC);
