ULTIMATE MINER — API INICIAL NEON (MIGRAÇÃO SEGURA)

ATENÇÃO: este pacote prepara a API e uma cópia inicial dos documentos. Ele NÃO substitui ainda o HTML atual nem desliga o Firestore. O jogo continua usando o Firebase até a integração do HTML ser concluída e testada.

1) No SQL Editor do Neon, execute o arquivo sql/01_neon_schema.sql.
   Isso cria a tabela genérica jogo_documentos e não apaga suas tabelas existentes.

2) No projeto GitHub que a Vercel já publica, adicione/substitua os arquivos:
   - package.json
   - pasta api/ inteira (incluindo api/_lib.js e api/admin/players.js)
   - pasta sql/ (opcional para guardar o SQL no repositório)
   Não apague os arquivos atuais do jogo.

3) Na Vercel > Project > Settings > Environment Variables, confirme/crie:
   DATABASE_URL = string de conexão PostgreSQL do Neon (com SSL, copiada do painel Neon)
   FIREBASE_SERVICE_ACCOUNT_JSON = JSON completo da conta de serviço Firebase Admin
   MIGRATION_SECRET = uma senha longa e aleatória criada por você
   ADMIN_UID = fWMMFNbKxmYozmkwsAwPTJO2skI3
   Marque Production (e Preview se desejar). Nunca coloque esses segredos no HTML ou GitHub.

4) Faça Deploy/ redeploy na Vercel.

5) Teste no navegador:
   https://SEU-DOMINIO-VERCEL/api/health
   Deve retornar sucesso true e neon conectado.

6) A migração dos documentos só deve ser executada depois de confirmar que DATABASE_URL e FIREBASE_SERVICE_ACCOUNT_JSON estão corretas. Ela é disparada por POST para /api/migrate com o cabeçalho x-migration-secret contendo o MIGRATION_SECRET. Não publique essa chave no HTML. Se não souber usar um cliente HTTP para fazer esse POST, pare nessa etapa e peça ajuda antes de continuar.

ENDPOINTS PREPARADOS:
GET  /api/health
GET  /api/player  (Authorization: Bearer <Firebase ID token>)
PUT  /api/player  (Authorization: Bearer <Firebase ID token>, body {"jogador": {...}})
GET  /api/ranking (Authorization: Bearer <Firebase ID token>)
GET  /api/events  (Authorization: Bearer <Firebase ID token>)
PUT  /api/events  (admin + token, body {"id":"...","evento":{...}})
GET  /api/admin/players (admin + token)
POST /api/migrate (cabeçalho x-migration-secret)

IMPORTANTE SOBRE A INTEGRAÇÃO:
O HTML atual usa recursos específicos do Firestore, incluindo listeners onSnapshot, lotes e transações. Esta API inicial não faz uma substituição automática desses recursos. Não altere ainda o HTML para apontar para o Neon e não considere a migração terminada até a próxima versão do HTML adaptar e testar cada fluxo. O endpoint de migração faz uma cópia inicial sem sobrescrever documentos que já existam no Neon e sem apagar o Firebase.
