const { db, authenticate, sendError, method, jsonObject } = require('./_lib');
const ALLOWED = new Set(['jogadores','rankingGlobal','eventos']);
const ADMIN = process.env.ADMIN_UID || 'fWMMFNbKxmYozmkwsAwPTJO2skI3';
const ID_RE = /^[A-Za-z0-9_-]{1,160}$/;
function fail(message,status=400){const e=new Error(message);e.status=status;throw e;}
function allowedRead(u,c,id){return c!=='jogadores'||id===u.uid||u.uid===ADMIN;}
function allowedWrite(u,c,id){return c==='eventos'?u.uid===ADMIN:(c==='jogadores'||c==='rankingGlobal')&&(id===u.uid||u.uid===ADMIN);}
module.exports=async(req,res)=>{try{
 method(req,['GET','PUT','PATCH','DELETE']);const user=await authenticate(req);const c=String(req.query?.colecao||'');const id=req.query?.id==null?'':String(req.query.id);if(!ALLOWED.has(c))fail('Coleção inválida.');if(id&&!ID_RE.test(id))fail('ID inválido.');const sql=db();
 await sql`CREATE TABLE IF NOT EXISTS jogo_documentos (colecao TEXT NOT NULL, documento_id TEXT NOT NULL, dados JSONB NOT NULL DEFAULT '{}'::jsonb, atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(), migrado_em TIMESTAMPTZ, PRIMARY KEY (colecao,documento_id))`;
 if(req.method==='GET'){
  if(id){if(!allowedRead(user,c,id))fail('Sem permissão.',403);const rows=await sql`SELECT documento_id AS id,dados FROM jogo_documentos WHERE colecao=${c} AND documento_id=${id} LIMIT 1`;return res.status(200).json({sucesso:true,existe:!!rows.length,documento:rows[0]?.dados||null});}
  if(c==='jogadores'&&user.uid!==ADMIN)fail('Somente o administrador pode listar jogadores.',403);
  const limit=Math.min(1000,Math.max(1,Number(req.query?.limite)||500));const rows=await sql`SELECT documento_id AS id,dados FROM jogo_documentos WHERE colecao=${c} ORDER BY atualizado_em DESC LIMIT ${limit}`;return res.status(200).json({sucesso:true,documentos:rows.map(r=>({id:r.id,...r.dados}))});
 }
 if(!id)fail('Informe um ID.');if(!allowedWrite(user,c,id))fail('Sem permissão para alterar este documento.',403);
 if(req.method==='DELETE'){await sql`DELETE FROM jogo_documentos WHERE colecao=${c} AND documento_id=${id}`;return res.status(200).json({sucesso:true});}
 const payload=jsonObject(req.body?.dados);
 if(req.method==='PUT'){
  if(req.body?.merge===true) await sql`INSERT INTO jogo_documentos(colecao,documento_id,dados,atualizado_em) VALUES(${c},${id},${JSON.stringify(payload)}::jsonb,NOW()) ON CONFLICT(colecao,documento_id) DO UPDATE SET dados=jogo_documentos.dados||EXCLUDED.dados,atualizado_em=NOW()`;
  else await sql`INSERT INTO jogo_documentos(colecao,documento_id,dados,atualizado_em) VALUES(${c},${id},${JSON.stringify(payload)}::jsonb,NOW()) ON CONFLICT(colecao,documento_id) DO UPDATE SET dados=EXCLUDED.dados,atualizado_em=NOW()`;
 }else{
  for(const [path,value] of Object.entries(payload)){const parts=path.split('.');if(parts.length>8||parts.some(p=>!/^[A-Za-z0-9_-]{1,80}$/.test(p)))fail('Caminho inválido.');await sql`INSERT INTO jogo_documentos(colecao,documento_id,dados,atualizado_em) VALUES(${c},${id},jsonb_set('{}'::jsonb,${'{'+parts.join(',')+'}'}::text[],${JSON.stringify(value)}::jsonb,true),NOW()) ON CONFLICT(colecao,documento_id) DO UPDATE SET dados=jsonb_set(jogo_documentos.dados,${'{'+parts.join(',')+'}'}::text[],${JSON.stringify(value)}::jsonb,true),atualizado_em=NOW()`;}
 }
 return res.status(200).json({sucesso:true});
 }catch(e){return sendError(res,e);}};
