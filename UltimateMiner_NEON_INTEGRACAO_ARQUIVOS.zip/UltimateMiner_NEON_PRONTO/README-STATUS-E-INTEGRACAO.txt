ULTIMATE MINER — MIGRAÇÃO FIRESTORE -> NEON

ESTE PACOTE É A BASE DE BACKEND, NÃO É A MIGRAÇÃO FINAL DO HTML.

O HTML enviado continua usando diretamente firebase.firestore(). Portanto, publicar somente este pacote NÃO transfere o jogo para Neon e NÃO reduz as operações do Firestore. Não substitua o HTML ativo ainda.

O que este pacote já fornece:
- conexão com Neon por DATABASE_URL;
- validação de sessão Firebase Authentication no servidor;
- endpoints para documentos de jogadores, rankingGlobal e eventos;
- endpoint de cópia inicial do Firestore para Neon;
- endpoints auxiliares de jogador, ranking, eventos e saúde.

O que falta antes de ligar o jogo ao Neon:
1. Adaptador frontend compatível com as chamadas Firestore encontradas no HTML (get/set/update, snapshots/polling, batch e transações).
2. Operações administrativas de saldo/inventário com atomicidade real no banco.
3. Testes de integração com as variáveis reais da Vercel.

IMPORTANTE:
- Não apagar nem desativar Firestore/Firebase.
- Não executar migração antes de configurar MIGRATION_SECRET na Vercel.
- Não colocar DATABASE_URL nem a chave de serviço Firebase no HTML.
- Firebase Authentication permanece responsável pelo login.
- A cópia inicial usa ON CONFLICT DO NOTHING: não sobrescreve documentos que já existam no Neon.

Variáveis necessárias na Vercel:
DATABASE_URL
FIREBASE_SERVICE_ACCOUNT_JSON
MIGRATION_SECRET (somente para endpoint de migração)
ADMIN_UID (opcional; padrão já definido no código)

O arquivo HTML original enviado pelo usuário não foi alterado nesta etapa.
