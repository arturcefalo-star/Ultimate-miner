const firebaseConfig={
apiKey:"AIzaSyCxpkYQcmdoOPeiSUb6CeP8F5iNBcLFrX0",
authDomain:"ultimate-miner-6dcb2.firebaseapp.com",
projectId:"ultimate-miner-6dcb2",
storageBucket:"ultimate-miner-6dcb2.firebasestorage.app",
messagingSenderId:"204675648250",
appId:"1:204675648250:web:da41d34510c910425d1743"
};
firebase.initializeApp(firebaseConfig);
const auth=firebase.auth();
const db=firebase.firestore();
const ADMIN_UID="fWMMFNbKxmYozmkwsAwPTJO2skI3";

let usuarioAtual=null;
let timerSalvamentoNuvem=null;
let carregandoDados=false;
let dadosCarregados=false;
let saindoDaConta=false;
let cancelarMonitoramentoJogador=null;
let timerPresenca=null;
let ultimaPresencaUid="";

const loginModal=document.getElementById("loginModal");
const nomeLogin=document.getElementById("nomeLogin");
const senhaLogin=document.getElementById("senhaLogin");
const mensagemLogin=document.getElementById("mensagemLogin");
const botaoEntrar=document.getElementById("botaoEntrar");
const botaoCriar=document.getElementById("botaoCriar");
const contasSalvas=document.getElementById("contasSalvas");
const senhaModal=document.getElementById("senhaModal");
const senhaAtualInput=document.getElementById("senhaAtual");
const senhaNovaInput=document.getElementById("senhaNova");
const senhaConfirmarInput=document.getElementById("senhaConfirmar");
const mensagemSenha=document.getElementById("mensagemSenha");
const botaoAtualizarSenha=document.getElementById("botaoAtualizarSenha");
const botaoCancelarSenha=document.getElementById("botaoCancelarSenha");

const CHAVE_CONTAS_SALVAS="ultimate_miner_contas_salvas";
function lerContasSalvas(){
try{
const lista=JSON.parse(localStorage.getItem(CHAVE_CONTAS_SALVAS)||"[]");
return Array.isArray(lista)?lista.filter((n,i,a)=>typeof n==="string"&&nomeValido(n)&&a.findIndex(x=>String(x).toLowerCase()===n.toLowerCase())===i).slice(0,100):[];
}catch(e){return [];}
}
function salvarContaUsada(nome){
const lista=lerContasSalvas().filter(n=>n.toLowerCase()!==nome.toLowerCase());
lista.unshift(nome);
try{localStorage.setItem(CHAVE_CONTAS_SALVAS,JSON.stringify(lista.slice(0,100)));}catch(e){}
mostrarContasSalvas();
}
function removerContaSalva(nome){
const lista=lerContasSalvas().filter(n=>n.toLowerCase()!==nome.toLowerCase());
try{localStorage.setItem(CHAVE_CONTAS_SALVAS,JSON.stringify(lista));}catch(e){}
mostrarContasSalvas();
}
function mostrarContasSalvas(){
if(!contasSalvas)return;
contasSalvas.innerHTML="";
const lista=lerContasSalvas();
if(!lista.length)return;
const titulo=document.createElement("div");
titulo.textContent="CONTAS SALVAS — TOQUE PARA ENTRAR";
titulo.style.cssText="font-size:11px;color:#9db9ef;text-align:left;font-weight:bold;margin-bottom:2px";
contasSalvas.appendChild(titulo);
lista.forEach(nome=>{
const linha=document.createElement("div");
linha.className="conta-salva";
const escolher=document.createElement("button");
escolher.type="button";
escolher.textContent="CONTA: "+nome;
escolher.addEventListener("click",async()=>{
nomeLogin.value=nome;
const emailSalvo=usuarioEmail(nome);
const sessaoAtual=auth.currentUser;
if(sessaoAtual&&sessaoAtual.email&&sessaoAtual.email.toLowerCase()===emailSalvo.toLowerCase()){
  mensagemDeLogin("Esta conta já está autenticada. Abrindo seu jogo...",false);
  await entrarNoJogo(sessaoAtual,nome);
  return;
}
// Por segurança, o jogo guarda somente o nome. A senha fica no gerenciador
// de senhas do navegador/dispositivo e nunca é gravada em texto puro no site.
senhaLogin.value="";
mensagemDeLogin("Conta selecionada. Confirme ou preencha a senha para entrar.",false);
senhaLogin.focus();
});
const remover=document.createElement("button");
remover.type="button";
remover.className="remover-conta";
remover.textContent="×";
remover.title="Remover conta desta lista";
remover.addEventListener("click",()=>removerContaSalva(nome));
linha.append(escolher,remover);
contasSalvas.appendChild(linha);
});
}

function mensagemDeLogin(texto,erro=true){
mensagemLogin.textContent=texto;
mensagemLogin.style.color=erro?"#ffb0b0":"#9dffb0";
}

function usuarioEmail(nome){
return nome.toLowerCase()+"@ultimateminer.com";
}

function nomeValido(nome){
return /^[a-zA-Z0-9_]{3,20}$/.test(nome);
}

function bloquearLogin(bloquear){
botaoEntrar.disabled=bloquear;
botaoCriar.disabled=bloquear;
botaoEntrar.textContent=bloquear?"AGUARDE...":"ENTRAR";
}

function comTempoLimite(promessa,ms,etapa){
let temporizador;
return Promise.race([
Promise.resolve(promessa),
new Promise((_,rejeitar)=>{temporizador=setTimeout(()=>{const erro=new Error("Tempo esgotado ao "+etapa+". Verifique a conexão e as configurações do Firebase.");erro.code="app/timeout";rejeitar(erro);},ms);})
]).finally(()=>clearTimeout(temporizador));
}


// UTILITÁRIOS

const MAX_MOEDAS=1e36;
const SUFIXOS_NUMERO={K:1e3,M:1e6,B:1e9,T:1e12,QA:1e15,QI:1e18,SX:1e21,SP:1e24,OC:1e27,NO:1e30,DC:1e33};

// Lê números como as pessoas digitam: 5000, 1.500.000, 2,5M, 10K, 1e6
function lerNumero(texto){
const t=String(texto==null?"":texto).trim().toUpperCase().replace(/\s+/g,"").replace(/^\$/,"");
if(!t)return NaN;
if(/^\d+(\.\d+)?E\d+$/.test(t))return Number(t);
const m=t.match(/^([0-9.,]+)([A-Z]{0,2})$/);
if(!m)return NaN;
let num=m[1];
if(/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(num))num=num.replace(/\./g,"").replace(",",".");
else if(/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(num))num=num.replace(/,/g,"");
else num=num.replace(",",".");
if(!/^\d+(\.\d+)?$/.test(num))return NaN;
let valor=Number(num);
if(m[2]){
if(!Object.prototype.hasOwnProperty.call(SUFIXOS_NUMERO,m[2]))return NaN;
valor*=SUFIXOS_NUMERO[m[2]];
}
return valor;
}

// O jogo só pode salvar depois que o progresso da conta foi carregado
function jogoPronto(){
return !!usuarioAtual&&dadosCarregados;
}

// Aplica dados vindos do servidor sem perder o desbloqueio do painel admin
function aplicarDadosDoServidor(dados){
const admin=adminDesbloqueado,codigo=codigoAdminSessao;
carregandoDados=true;
aplicarDados(dados);
carregandoDados=false;
adminDesbloqueado=admin;
codigoAdminSessao=codigo;
}

// Sincroniza somente alterações explícitas feitas pelo painel Admin.
// Snapshots comuns dos próprios salvamentos não podem reaplicar um saldo antigo
// por cima das moedas que o jogador acabou de minerar.
function iniciarMonitoramentoJogador(uid){
if(cancelarMonitoramentoJogador){
try{cancelarMonitoramentoJogador();}catch(e){}
cancelarMonitoramentoJogador=null;
}
let primeiroSnapshot=true;
const ref=db.collection("jogadores").doc(uid);
cancelarMonitoramentoJogador=ref.onSnapshot(snapshot=>{
if(!usuarioAtual||usuarioAtual.uid!==uid||!dadosCarregados||!snapshot.exists)return;
if(snapshot.metadata&&snapshot.metadata.hasPendingWrites)return;
const registro=snapshot.data()||{};
const avisoAdmin=registro.avisoAdmin;
const idAviso=avisoAdmin&&avisoAdmin.id?String(avisoAdmin.id):"";
// O primeiro snapshot serve apenas para memorizar o aviso já existente.
if(primeiroSnapshot){
primeiroSnapshot=false;
ultimoAvisoAdminId=idAviso;
return;
}
// Sem um novo aviso, não aplicar dados remotos: pode ser apenas um eco atrasado
// de um salvamento anterior do próprio jogador.
if(!idAviso||idAviso===ultimoAvisoAdminId)return;
ultimoAvisoAdminId=idAviso;
const idadeAviso=Date.now()-(Number(avisoAdmin.criadoEm)||0);
if(idadeAviso>=0&&idadeAviso<86400000){
mostrarAviso(String(avisoAdmin.texto||"O admin "+nomeDoAdminAtual()+" fez uma alteração na sua conta."),"info");
}
const dados=registro.dados;
if(!dados||typeof dados!=="object"||Array.isArray(dados))return;
if(timerSalvamentoNuvem){clearTimeout(timerSalvamentoNuvem);timerSalvamentoNuvem=null;}
aplicarDadosDoServidor(dados);
try{localStorage.setItem("mining_game_save_"+uid,JSON.stringify(dados));}catch(e){}
atualizarAdmin();
},error=>{
console.error("Erro ao sincronizar os dados do jogador em tempo real:",error);
});
}

function textoErroLogin(error){
const c=error&&error.code;
if(c==="auth/username-case-mismatch")return "Nome de usuário incorreto. Digite exatamente como foi cadastrado, respeitando maiúsculas e minúsculas.";
if(c==="auth/wrong-password"||c==="auth/invalid-credential"||c==="auth/invalid-login-credentials")return "Esta conta está com a senha incorreta. Digite a senha atual para entrar novamente.";
if(c==="auth/user-not-found")return "Essa conta não foi encontrada. Confira o nome de usuário.";
if(c==="auth/user-disabled")return "Esta conta foi banida ou desativada.";
if(c==="auth/too-many-requests")return "Muitas tentativas seguidas. Aguarde um pouco e tente de novo.";
if(c==="auth/network-request-failed")return "Sem conexão com a internet. Tente novamente.";
if(c==="app/timeout")return "O Firebase demorou demais para responder. Verifique a internet e tente novamente.";
return (error&&error.message)||"Não foi possível entrar.";
}

function textoErroCriar(error){
const c=error&&error.code;
if(c==="auth/email-already-in-use")return "Esse nome já existe. Use ENTRAR com a senha dessa conta.";
if(c==="auth/weak-password")return "Senha fraca demais. Use pelo menos 6 caracteres.";
if(c==="auth/operation-not-allowed")return "O cadastro por e-mail e senha está desativado no Firebase (Authentication > Sign-in method).";
if(c==="auth/network-request-failed")return "Sem conexão com a internet. Tente novamente.";
if(c==="app/timeout")return "O Firebase demorou demais para responder. A conta pode ter sido criada; tente ENTRAR com esse nome.";
return "Não foi possível criar a conta: "+((error&&error.message)||"erro desconhecido");
}



// SALVAMENTO E CONTAS FIREBASE

const canvas=document.getElementById("game");
const ctx=canvas.getContext("2d");
// Renderização em alta densidade: mantém as coordenadas lógicas de 500x300.
// A escala é reaplicada no início de cada quadro para não acumular transformações.
const UM_BASE_W=500, UM_BASE_H=300;
let umRenderScale=1;
function atualizarResolucaoUltimate(){
  const largura=canvas.getBoundingClientRect().width||500;
  const altura=canvas.getBoundingClientRect().height||300;
  const dpr=Math.min(window.devicePixelRatio||1,2);
  const escala=Math.max(1,Math.min(4,Math.ceil(Math.max(largura/UM_BASE_W,altura/UM_BASE_H)*dpr)));
  if(escala===umRenderScale&&canvas.width===500*escala&&canvas.height===300*escala)return;
  umRenderScale=escala;
  canvas.width=UM_BASE_W*escala;
  canvas.height=UM_BASE_H*escala;
  ctx.imageSmoothingEnabled=true;
  ctx.imageSmoothingQuality='high';
}
window.addEventListener('resize',atualizarResolucaoUltimate,{passive:true});
window.addEventListener('orientationchange',atualizarResolucaoUltimate,{passive:true});
atualizarResolucaoUltimate();

const modal=document.getElementById("codeModal");
const codeInput=document.getElementById("codeInput");

if(!ctx)throw new Error("Canvas não disponível");

if(!ctx.roundRect){
ctx.roundRect=function(x,y,w,h,r=0){
const a=Math.max(0,Math.min(r,w/2,h/2));
this.moveTo(x+a,y);
this.lineTo(x+w-a,y);
this.quadraticCurveTo(x+w,y,x+w,y+a);
this.lineTo(x+w,y+h-a);
this.quadraticCurveTo(x+w,y+h,x+w-a,y+h);
this.lineTo(x+a,y+h);
this.quadraticCurveTo(x,y+h,x,y+h-a);
this.lineTo(x,y+a);
this.quadraticCurveTo(x,y,x+a,y);
this.closePath();
};
}

const picaretas=[
["Wood Pickaxe",0,1,[130,75,30]],
["Stone Pickaxe",180,3,[140,140,140]],
["Copper Pickaxe",650,6,[190,110,60]],
["Gold Pickaxe",1800,10,[255,215,55]],
["Iron Pickaxe",4200,15,[190,190,210]],
["Diamond Pickaxe",9000,22,[0,220,255]],
["Obsidian Pickaxe",18000,31,[55,35,80]],
["Ruby Pickaxe",35000,42,[220,20,60]],
["Emerald Pickaxe",65000,56,[0,200,90]],
["Amethyst Pickaxe",110000,73,[150,70,220]],
["Sapphire Pickaxe",180000,94,[30,100,255]],
["Titanium Pickaxe",290000,120,[160,180,190]],
["Cobalt Pickaxe",460000,151,[20,70,180]],
["Uranium Pickaxe",720000,189,[120,255,20]],
["Plasma Pickaxe",1100000,235,[0,255,220]],
["Void Pickaxe",1650000,290,[65,0,110]],
["Meteor Pickaxe",2400000,355,[110,75,65]],
["Magma Pickaxe",3400000,430,[255,75,0]],
["Crystal Pickaxe",4800000,520,[130,220,255]],
["Ancient Pickaxe",6700000,630,[180,150,90]],
["Dragon Pickaxe",9200000,760,[180,20,20]],
["Celestial Pickaxe",12500000,910,[255,240,160]],
["Quantum Pickaxe",17000000,1080,[0,255,180]],
["Galactic Pickaxe",23000000,1280,[100,50,220]],
["Eternity Pickaxe",31000000,1510,[255,100,200]],
["Infinity Pickaxe",42000000,1780,[255,255,255]],
["Starsteel Pickaxe",58000000,2100,[120,190,255]],
["Solar Pickaxe",80000000,2500,[255,150,30]],
["Lunar Pickaxe",110000000,3000,[190,200,255]],
["Godslayer Pickaxe",150000000,3600,[255,50,80]],
["Abyssal Pickaxe",205000000,4300,[75,0,130]],
["Phoenix Pickaxe",280000000,5200,[255,90,20]],
["Titan Pickaxe",380000000,6300,[100,220,180]],
["Divine Pickaxe",520000000,7600,[255,245,170]],
["Omniverse Pickaxe",710000000,9200,[180,100,255]],
["Genesis Pickaxe",1000000000,11200,[255,255,255]],
["Quartz Pickaxe",1350000000,14560,[100, 245, 39]],
["Topaz Pickaxe",1799903019,18928,[224, 18, 139]],
["Onyx Pickaxe",2399741392,24606,[87, 235, 255]],
["Jade Pickaxe",3199482798,31988,[209, 178, 25]],
["Garnet Pickaxe",4265747221,41585,[158, 66, 237]],
["Peridot Pickaxe",5687356521,54060,[37, 230, 84]],
["Tourmaline Pickaxe",7582733462,70278,[245, 20, 30]],
["Aquamarine Pickaxe",10109766559,91362,[76, 126, 224]],
["Moonstone Pickaxe",13478962485,118770,[172, 255, 31]],
["Sunstone Pickaxe",17970981684,154402,[209, 59, 197]],
["Bloodstone Pickaxe",23960017922,200722,[38, 237, 195]],
["Malachite Pickaxe",31944969336,260939,[230, 123, 18]],
["Opal Pickaxe",42590997601,339220,[116, 83, 245]],
["Citrine Pickaxe",56784937171,440986,[44, 224, 27]],
["Tanzanite Pickaxe",75709170274,573282,[255, 71, 141]],
["Alexandrite Pickaxe",100940121608,745267,[33, 151, 209]],
["Zircon Pickaxe",134579577525,968847,[229, 237, 19]],
["Spinel Pickaxe",179429768841,1259501,[191, 78, 230]],
["Morganite Pickaxe",239226802003,1637351,[29, 245, 127]],
["Lapis Pickaxe",318951883884,2128556,[224, 89, 63]],
["Thunder Pickaxe",425246265809,2767123,[41, 69, 255]],
["Storm Pickaxe",566964472453,3597260,[98, 209, 17]],
["Frost Pickaxe",755911900631,4676437,[237, 81, 192]],
["Blazing Pickaxe",1007828231359,6079369,[28, 230, 228]],
["Glacier Pickaxe",1343698575293,7903179,[245, 192, 69]],
["Venom Pickaxe",1791501572454,10274133,[113, 36, 224]],
["Spectral Pickaxe",2388540066291,13356373,[20, 255, 48]],
["Phantom Pickaxe",3184548501659,17363285,[209, 71, 95]],
["Aether Pickaxe",4245835898900,22572270,[28, 125, 237]],
["Runic Pickaxe",5660809521663,29343951,[189, 230, 64]],
["Prismatic Pickaxe",7547339370523,38147137,[235, 39, 245]],
["Enchanted Pickaxe",10062576978762,49591278,[18, 224, 154]],
["Cursed Pickaxe",13416046434718,64468661,[255, 149, 87]],
["Wraith Pickaxe",17887098137824,83809259,[39, 25, 209]],
["Soul Pickaxe",23848179219488,108952037,[103, 237, 66]],
["Infernal Pickaxe",31795859099257,141637648,[230, 37, 135]],
["Frostfire Pickaxe",42392194664222,184128942,[20, 200, 245]],
["Tempest Pickaxe",56519880870000,239367625,[224, 211, 76]],
["Thunderlord Pickaxe",75355780913486,311177912,[169, 31, 255]],
["Leviathan Pickaxe",100468961180974,404531286,[59, 209, 108]],
["Behemoth Pickaxe",133951397469727,525890672,[237, 45, 38]],
["Colossus Pickaxe",178592240560468,683657873,[18, 73, 230]],
["Eclipse Pickaxe",238110157795230,888755235,[172, 245, 83]],
["Nova Pickaxe",317463105156983,1155381806,[224, 27, 193]],
["Supernova Pickaxe",423261334455898,1501996347,[71, 255, 230]],
["Nebula Pickaxe",564318039908290,1952595251,[209, 134, 33]],
["Pulsar Pickaxe",752383514018137,2538373827,[81, 19, 237]],
["Quasar Pickaxe",1003123969345860,3299885975,[79, 230, 78]],
["Blackhole Pickaxe",1337426563883932,4289851767,[245, 29, 94]],
["Stardust Pickaxe",1783139341141258,5576807297,[63, 159, 224]],
["Cosmic Pickaxe",2377391025262766,7249849487,[230, 255, 41]],
["Astral Pickaxe",3169683914540586,9424804333,[175, 17, 209]],
["Chronos Pickaxe",4226017517243250,12252245632,[81, 237, 164]],
["Dimension Pickaxe",5634386436489619,15927919322,[230, 76, 28]],
["Rift Pickaxe",7512110488459877,20706295119,[69, 78, 245]],
["Paradox Pickaxe",10015607666766196,26918183654,[101, 224, 36]],
["Singularity Pickaxe",13353424059548374,34993638750,[255, 20, 169]],
["Multiverse Pickaxe",17803606136231444,45491730376,[71, 199, 209]],
["Overlord Pickaxe",23736862548554320,59139249488,[237, 191, 28]],
["Apocalypse Pickaxe",31647444868055576,76881024335,[145, 64, 230]],
["Worldbreaker Pickaxe",42194319684326472,99945331635,[39, 245, 80]],
["Reality Pickaxe",56256061778314608,129928931126,[224, 18, 37]],
["Omniscient Pickaxe",75004041076674320,168907610463,[87, 152, 255]],
["Transcendent Pickaxe",99999999999999776,219579893602,[150, 209, 25]]
];

const minerios=[
["Stone",0,1,[110,110,110]],
["Coal",100,1.5,[30,30,30]],
["Copper",400,2,[190,110,60]],
["Gold",1200,2.5,[255,215,55]],
["Iron",3000,3,[190,190,210]],
["Diamond",7000,3.5,[0,220,255]],
["Obsidian",15000,4,[55,35,80]],
["Ruby",30000,4.5,[220,20,60]],
["Emerald",55000,5,[0,200,90]],
["Amethyst",95000,5.5,[150,70,220]],
["Sapphire",160000,6,[30,100,255]],
["Titanium",260000,6.5,[160,180,190]],
["Cobalt",420000,7,[20,70,180]],
["Uranium",680000,7.5,[120,255,20]],
["Plasma",1050000,8,[0,255,220]],
["Void",1600000,8.5,[65,0,110]],
["Meteorite",2200000,9,[110,75,65]],
["Magma",3100000,9.5,[255,75,0]],
["Crystal",4400000,10,[130,220,255]],
["Ancient Ore",6200000,10.5,[180,150,90]],
["Dragonite",8700000,11,[180,20,20]],
["Celestite",12000000,11.5,[255,240,160]],
["Quantum Ore",16500000,12,[0,255,180]],
["Galactium",22500000,12.5,[100,50,220]],
["Eternium",30000000,13,[255,100,200]],
["Infinity Ore",40000000,13.5,[255,255,255]],
["Starsteel Ore",55000000,14,[120,190,255]],
["Solar Ore",75000000,14.5,[255,150,30]],
["Lunar Ore",105000000,15,[190,200,255]],
["Godslayer Ore",145000000,15.5,[255,50,80]],
["Abyssal Ore",195000000,16,[75,0,130]],
["Phoenix Ore",270000000,16.5,[255,90,20]],
["Titan Ore",370000000,17,[100,220,180]],
["Divine Ore",500000000,17.5,[255,245,170]],
["Omniverse Ore",690000000,18,[180,100,255]],
["Genesis Ore",950000000,18.5,[255,255,255]],
["Quartz Ore",1250000000,19.0,[39, 245, 170]],
["Topaz Ore",1668614011,19.5,[224, 89, 18]],
["Onyx Ore",2227418173,20.0,[95, 87, 255]],
["Jade Ore",2973360936,20.5,[69, 209, 25]],
["Garnet Ore",3969113374,21.0,[237, 66, 157]],
["Peridot Ore",5298334548,21.5,[37, 196, 230]],
["Tourmaline Ore",7072700207,22.0,[245, 219, 20]],
["Aquamarine Ore",9441285326,22.5,[164, 76, 224]],
["Moonstone Ore",12603088777,23.0,[31, 255, 98]],
["Sunstone Ore",16823752408,23.5,[209, 60, 59]],
["Bloodstone Ore",22457879182,24.0,[38, 94, 237]],
["Malachite Ore",29978825480,24.5,[140, 230, 18]],
["Opal Ore",40018470571,25.0,[245, 83, 223]],
["Citrine Ore",53420304540,25.5,[27, 224, 193]],
["Tanzanite Ore",71310294881,26.0,[255, 172, 71]],
["Alexandrite Ore",95191485707,26.5,[79, 33, 209]],
["Zircon Ore",127070277386,27.0,[26, 237, 19]],
["Spinel Ore",169624996133,27.5,[230, 78, 127]],
["Morganite Ore",226430916066,28.0,[29, 162, 245]],
["Lapis Ore",302260639170,28.5,[210, 224, 63]],
["Thunderstone",403485069878,29.0,[212, 41, 255]],
["Stormite",538608672508,29.5,[17, 209, 114]],
["Frostium",718983981708,30.0,[237, 114, 81]],
["Blazium",959765396174,30.5,[28, 43, 230]],
["Glacierite",1281182389494,31.0,[133, 245, 69]],
["Venomite",1710239108114,31.5,[224, 36, 160]],
["Spectralite",2282983149711,32.0,[20, 244, 255]],
["Phantomite",3047534135511,32.5,[209, 176, 71]],
["Aetherium",4068126524842,33.0,[126, 28, 237]],
["Runestone",5430506332737,33.5,[64, 230, 93]],
["Prism Ore",7249135160819,34.0,[245, 39, 64]],
["Enchanted Ore",9676806794799,34.5,[18, 103, 224]],
["Cursed Ore",12917484315920,35.0,[205, 255, 87]],
["Wraithstone",17243436248176,35.5,[209, 25, 208]],
["Soulstone",23018111450576,36.0,[66, 237, 188]],
["Infernium",30726674609720,36.5,[230, 118, 37]],
["Frostfire Crystal",41016767800382,37.0,[49, 20, 245]],
["Tempestite",54752922734381,37.5,[100, 224, 76]],
["Thunderlord Ore",73089195193219,38.0,[255, 31, 132]],
["Leviathan Scale",97566124093648,38.5,[59, 171, 209]],
["Behemothite",130240161291859,39.0,[237, 230, 38]],
["Colossium",173856446291218,39.5,[160, 18, 230]],
["Eclipse Ore",232079441680639,40.0,[83, 245, 145]],
["Novarium",309800806353638,40.5,[224, 44, 27]],
["Supernova Core",413550372761737,41.0,[71, 109, 255]],
["Nebulite",552044756836907,41.5,[120, 209, 33]],
["Pulsarium",736919692553875,42.0,[237, 19, 191]],
["Quasarite",983707618898976,42.5,[78, 230, 218]],
["Blackhole Shard",1313142652120328,43.0,[245, 165, 29]],
["Stardust Crystal",1752902581711828,43.5,[117, 63, 224]],
["Cosmium",2339934245537272,44.0,[41, 255, 51]],
["Astralite",3123557652639822,44.5,[209, 17, 64]],
["Chronos Ore",4169609649490206,45.0,[81, 165, 237]],
["Dimensionite",5565975263632048,45.5,[195, 230, 28]],
["Riftstone",7429971445684757,46.0,[223, 69, 245]],
["Paradoxium",9918203561628378,46.5,[36, 224, 146]],
["Singularium",13239722737700486,47.0,[255, 90, 20]],
["Multiverse Ore",17673589484425140,47.5,[72, 71, 209]],
["Overlordite",23592319223917052,48.0,[89, 237, 28]],
["Apocalypse Crystal",31493179518156624,48.5,[230, 64, 160]],
["Worldbreaker Ore",42039968463862072,49.0,[39, 219, 245]],
["Reality Shard",56118784304506008,49.5,[224, 190, 18]],
["Omniscient Ore",74912471795093056,50.0,[178, 87, 255]],
["Transcendent Crystal",100000000000000224,50.5,[25, 209, 71]]
];

let moedas=0;
let renascimentos=0;
let picaretasCompradas=[0],mineriosComprados=[0];
let picaretaAtual=0,minerioAtual=0;

let lojaAberta=false;
let adminAberto=false;
let configuracoesAbertas=false;
let melhoriasAbertas=false;

let adminDesbloqueado=false;
let categoria="picaretas",scroll=0;

let diagonal=false,tempoGolpe=0;
let recompensaTexto="",mostrarRecompensa=false,tempoRecompensa=0;

let arrastando=false,inicioY=0,scrollInicial=0,moveuLista=false;
let volumeArrastando=false;

let audio=null,audioAtivo=false,masterGain=null;
let volumeGeral=1;

let codigosUsados=[];
let codigoModalAberto=false;
let codigoAdminSessao="";

// AVISOS (caixa em HTML: quebra linha e nunca corta o texto)

const avisoEl=document.getElementById("aviso");
let avisoTimer=null;

function mostrarAviso(mensagem,tipo="erro"){
const texto=String(mensagem);
avisoEl.style.background="";avisoEl.style.color="";avisoEl.style.borderColor="";avisoEl.style.boxShadow="";
avisoEl.textContent=texto;
avisoEl.className="visivel "+tipo;
clearTimeout(avisoTimer);
avisoTimer=setTimeout(()=>{avisoEl.className="";},Math.min(8000,Math.max(2000,texto.length*55)));
}

window.alert=function(mensagem){
mostrarAviso(mensagem,"info");
};

function mostrarAvisoPet(mensagem,pets){
 mostrarAviso(mensagem,"ok");
 const ordem={Comum:0,Incomum:1,Raro:2,"Épico":3,"Lendário":4,"Mítico":5,"Secreto":6};
 const maior=(pets||[]).slice().sort((a,b)=>(ordem[b.raridade]||0)-(ordem[a.raridade]||0))[0];
 if(!maior)return;
 const estilos={
  "Comum":{"bg":"#343943","fg":"#f0f0f0","border":"#cbd0d8"},
  "Incomum":{"bg":"#123b22","fg":"#a9ffbd","border":"#45d36b"},
  "Raro":{"bg":"#102b55","fg":"#c6e0ff","border":"#4295ff"},
  "Épico":{"bg":"#35164e","fg":"#edcaff","border":"#b66cff"},
  "Lendário":{"bg":"#4b3908","fg":"#fff0a6","border":"#ffd43b"},
  "Mítico":{"bg":"#650f19","fg":"#fff0f0","border":"#ff4545"},
  "Secreto":{"bg":"#050505","fg":"#ffffff","border":"#ffffff"}
 };
 const c=estilos[maior.raridade];if(c){avisoEl.style.background=c.bg;avisoEl.style.color=c.fg;avisoEl.style.borderColor=c.border;avisoEl.style.boxShadow="0 0 18px "+c.border+"88";}
}


// SISTEMA DE MELHORIAS

let multiplicadorCompras=0;
let precoMultiplicador=100;
// Melhorias dos ovos e dos mascotes.
let autoOvoComprado=false,autoOvoAtivo=false,ultimoAutoOvo=Date.now();
let triploOvoComprado=false;
const CUSTO_TRIPLO_OVO=25000000;
let sorteOvoNivel=0,precoSorteOvo=200;
let impulsoPetsNivel=0,precoImpulsoPets=500000;
let petsVendaAutomatica=[];
const CUSTO_OVO_PET=100000,INTERVALO_AUTO_OVO=1000;

// Evento global de dinheiro sincronizado pelo Firestore.
let eventoGlobal={ativo:false,multiplicador:1,expiraEm:0,admin:"Admin",id:""};
let eventoSorteGlobal={ativo:false,multiplicador:1,expiraEm:0,admin:"Admin",id:""};
const eventosMutacao={anjo:{ativo:false,expiraEm:0,id:"",ativadoEm:0},hacker:{ativo:false,expiraEm:0,id:"",ativadoEm:0},galaxia:{ativo:false,expiraEm:0,id:"",ativadoEm:0}};
const nomesMutacaoEvento={anjo:"Anjo",hacker:"Hacker",galaxia:"Galáxia"};
function obterMutacoesEventoAtivas(){const agora=Date.now();return Object.keys(eventosMutacao).filter(k=>eventosMutacao[k].ativo&&(eventosMutacao[k].permanente===true||eventosMutacao[k].expiraEm>agora));}
function multiplicadorBonusMutacoes(mutacoes){const fatores={anjo:1.5,hacker:2,galaxia:2.5};return [...new Set(Array.isArray(mutacoes)?mutacoes:[])].reduce((total,k)=>total*(fatores[k]||1),1);}
let cancelarMonitoramentoEvento=null;
let ultimoAvisoAdminId="";

let autoClickerComprado=false;
let autoClickerProComprado=false;

let autoClickerAtivo=false;
let autoClickerProAtivo=false;

let ultimoAutoClick=Date.now();

// MUNDOS: desbloqueio permanente por progresso de minérios.
const mundosJogo=[
 {nome:"Superfície",sigla:"SUP",custo:0,mult:1,descricao:"O começo da sua jornada."},
 {nome:"Cavernas Profundas",sigla:"CAV",custo:50000,mult:1.5,descricao:"Minere minérios mais valiosos."},
 {nome:"Vulcão",sigla:"VOL",custo:750000,mult:2,descricao:"Calor extremo e recompensas maiores."},
 {nome:"Glacial",sigla:"GLA",custo:10000000,mult:3,descricao:"Uma dimensão congelada e rara."},
 {nome:"Galáxia",sigla:"GAL",custo:150000000,mult:5,descricao:"O mundo final, com bônus máximo."}
];
let mundoAtual=0;
let mundosDesbloqueados=[0];
let petsInventario=[];
let petsEquipados=[];
let melhoriaInventarioPets=0; // 0=50 slots; até 6=200
let melhoriaPetsEquipados=0; // 0=3 slots; até 3=6
let paginaMelhorias=0;
let scrollMelhorias=0, arrastandoMelhorias=false, inicioYMelhorias=0, scrollInicialMelhorias=0;
const ALTURA_LINHA_MELHORIA=42, TOPO_LISTA_MELHORIAS=52, ALTURA_LISTA_MELHORIAS=211;
let modoVendaPets="raridade";
let petsMarcadosVenda=new Set();
function limiteInventarioPets(){return 50+25*Math.max(0,Math.min(6,Number(melhoriaInventarioPets)||0));}
function limitePetsEquipados(){return 3+Math.max(0,Math.min(3,Number(melhoriaPetsEquipados)||0));}
let petsConseguidosSessao=[];
let painelAFKAberto=false;
let ovosAbertos=0;
let rankingTipo="dinheiro";
let rankingCarregando=false;
let rankingProximaAtualizacao=Date.now()+60000;
let cancelarRankingAoVivo=null;
let rankingUltimaLista=[];
let rankingUltimoSnapshot=null;
let rankingUltimaBusca=0;
let rankingBuscaEmAndamento=false;
const catalogoPets=[
 {nome:"Slime",sigla:"SL",raridade:"Comum",peso:45,mult:1.10,cor:"#d1d5db"},
 {nome:"Coelhinho",sigla:"CO",raridade:"Incomum",peso:25,mult:1.15,cor:"#45d36b"},
 {nome:"Raposa",sigla:"RA",raridade:"Raro",peso:15,mult:1.30,cor:"#4295ff"},
 {nome:"Lobo",sigla:"LO",raridade:"Épico",peso:8,mult:1.60,cor:"#b66cff"},
 {nome:"Dragão",sigla:"DR",raridade:"Lendário",peso:5,mult:2.20,cor:"#ffd43b"},
 {nome:"Fênix",sigla:"FE",raridade:"Mítico",peso:1.8,mult:3.00,cor:"#ff4545"},
 {nome:"Sombra",sigla:"SO",raridade:"Secreto",peso:0.2,mult:5.00,cor:"#111111",borda:"#ffffff"}
];
const ORDEM_RARIDADE_PETS={"Comum":0,"Incomum":1,"Raro":2,"Épico":3,"Lendário":4,"Mítico":5,"Secreto":6};
const CORES_RARIDADE_PETS={"Comum":"#d1d5db","Incomum":"#45d36b","Raro":"#4295ff","Épico":"#b66cff","Lendário":"#ffd43b","Mítico":"#ff4545","Secreto":"#ffffff"};
let petsOrdenacao="melhores";
function multiplicadorPets(){
 // Os bônus dos pets equipados são SOMADOS, nunca multiplicados entre si.
 // Exemplo: 600 + 600 + 600 = 1.800.
 const base=petsEquipados.reduce((total,id)=>{
  const pet=petsInventario.find(p=>p.id===id);
  return total+(pet?Math.max(0,Number(pet.mult)||0):0);
 },0);
 if(!petsEquipados.length)return 1;
 // Mantém o upgrade Impulso de Pets aplicado ao total somado.
 return base*(1+Math.max(0,impulsoPetsNivel)*0.15);
}
function pesoPetComSorte(p){
 const nivel=Math.max(0,Math.min(20,Number(sorteOvoNivel)||0));
 const raridade=ORDEM_RARIDADE_PETS[p.raridade]||0;
 const eventoAtivo=eventoSorteGlobal.ativo&&(eventoSorteGlobal.permanente===true||eventoSorteGlobal.expiraEm>Date.now());
 const bonusEvento=eventoAtivo?Math.pow(Math.max(1,eventoSorteGlobal.multiplicador),raridade/6):1;
 return p.peso*(1+raridade*0.35*nivel)*bonusEvento;
}
function multiplicadorMundo(){return mundosJogo[mundoAtual]?.mult||1;}
function atualizarMundosDesbloqueados(){
 // Mundos são liberados por compra ou pelo painel Admin, nunca automaticamente por minérios.
 mundosDesbloqueados=[...new Set([0,...(Array.isArray(mundosDesbloqueados)?mundosDesbloqueados:[])])]
  .map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<mundosJogo.length);
 if(!mundosDesbloqueados.includes(mundoAtual))mundoAtual=0;
}
function abrirNovoModal(tipo){
 if(!jogoPronto())return;
 fecharNovosModais();
 if(tipo==="mundos"){atualizarMundosDesbloqueados();renderizarMundos();document.getElementById("mundosModal").style.display="flex";}
 if(tipo==="ovos"){renderizarChancesOvo();renderizarResumoPets();document.getElementById("ovosPetsModal").style.display="flex";}
 if(tipo==="inventario"){renderizarPets();document.getElementById("inventarioPetsModal").style.display="flex";}
 if(tipo==="ranking"){document.getElementById("rankingModal").style.display="flex";atualizarContagemRanking();carregarRanking();}
 somAbrirLoja();
}
function fecharNovosModais(){
 const ovos=document.getElementById("ovosPetsModal");
 const estavaNosOvos=ovos&&ovos.style.display==="flex";
 ["mundosModal","ovosPetsModal","inventarioPetsModal","venderPetsModal","rankingModal"].forEach(id=>document.getElementById(id).style.display="none");
 pararRankingAoVivo();
 if(estavaNosOvos&&autoOvoAtivo){autoOvoAtivo=false;salvar();}
 painelAFKAberto=false;atualizarControlesOvo();
}
function renderizarMundos(){
 const el=document.getElementById("listaMundos");el.innerHTML="";
 const cenarios=[
  {tema:"Campos verdes, grama e vegetação"},
  {tema:"Estalactites, pedras e minérios brilhantes"},
  {tema:"Rochas vulcânicas e rios de lava"},
  {tema:"Montanhas de gelo e cristais congelados"},
  {tema:"Planetas, estrelas e nebulosas roxas"}
 ];
 mundosJogo.forEach((m,i)=>{
  const aberto=mundosDesbloqueados.includes(i),selecionado=mundoAtual===i,visual=cenarios[i];
  const card=document.createElement("div");
  card.className="novo-card mundo-card"+(aberto?"":" mundo-bloqueado")+(selecionado?" mundo-atual":"");
  card.dataset.mundo=String(i);
  const cena=document.createElement("div");cena.className="mundo-cenario";
  const arte=document.createElement("span");arte.className="mundo-decor";cena.append(arte);
  const info=document.createElement("div");info.className="mundo-info";
  const nome=document.createElement("strong");nome.textContent=m.nome;
  const desc=document.createElement("small");
  desc.textContent=aberto?visual.tema:("PREÇO DE COMPRA: $ "+formatarDinheiro(m.custo));
  info.append(nome,desc);
  const rodape=document.createElement("div");rodape.className="mundo-rodape";
  const bonus=document.createElement("span");bonus.className="mundo-bonus";bonus.textContent="BÔNUS "+m.mult+"x";
  const b=document.createElement("button");
  const mundoAnteriorLiberado=i===0||mundosDesbloqueados.includes(i-1);
  b.textContent=selecionado?"ATUAL":(aberto?"ENTRAR":(mundoAnteriorLiberado?("COMPRAR $"+formatarDinheiro(m.custo)):"BLOQUEADO"));
  b.disabled=selecionado||(!aberto&&!mundoAnteriorLiberado);
  if(!aberto&&!mundoAnteriorLiberado)b.title="Desbloqueie primeiro o mundo anterior.";
  else if(!aberto&&moedas<m.custo)b.title="Você precisa de mais $ "+formatarDinheiro(m.custo-moedas)+" para comprar";
  b.addEventListener("click",()=>{
   if(!mundosDesbloqueados.includes(i)){
    if(!mundoAnteriorLiberado){mostrarAviso("Desbloqueie primeiro o mundo anterior.","erro");return;}
    if(m.custo>0&&moedas<m.custo){mostrarAviso("Dinheiro insuficiente! Faltam $ "+formatarDinheiro(m.custo-moedas)+" para comprar este mundo.","erro");return;}
    if(m.custo>0){moedas-=m.custo;}
    mundosDesbloqueados.push(i);
    mostrarAviso("Mundo "+(i+1)+" desbloqueado: "+m.nome+"!","ok");
   }
   mundoAtual=i;salvar();renderizarMundos();
   if(m.custo===0)mostrarAviso("Mundo alterado: "+m.nome+" (bônus "+m.mult+"x).","ok");
  });
  rodape.append(bonus,b);card.append(cena,info,rodape);el.appendChild(card);
 });
}
function escolherPetAleatorio(){
 const total=catalogoPets.reduce((a,p)=>a+pesoPetComSorte(p),0);let n=Math.random()*total;
 for(const p of catalogoPets){n-=pesoPetComSorte(p);if(n<=0)return p;}return catalogoPets[0];
}
function abrirOvosQuantidade(quantidade=1,automatico=false){
 if(!jogoPronto())return false;
 quantidade=Math.max(1,Math.min(3,Math.floor(Number(quantidade)||1)));
 if(quantidade===3&&!triploOvoComprado){mostrarAviso("Desbloqueie o upgrade OVOS TRIPLOS na seção de melhorias.","erro");return false;}
 const custo=CUSTO_OVO_PET*quantidade;
 if(moedas<custo){
  if(automatico){autoOvoAtivo=false;salvar();atualizarControlesOvo();mostrarAviso("Ovos automáticos pausados: saldo insuficiente.","erro");}
  else mostrarAviso("Você precisa de $ "+formatarDinheiro(custo)+" para abrir "+quantidade+" ovo(s).","erro");
  return false;
 }
 const sorteios=Array.from({length:quantidade},()=>escolherPetAleatorio());
 const novosNoInventario=sorteios.filter(base=>!petsVendaAutomatica.includes(base.nome)).length;
 if(petsInventario.length+novosNoInventario>limiteInventarioPets()){
  if(automatico){autoOvoAtivo=false;salvar();atualizarControlesOvo();mostrarAviso("Ovos automáticos pausados: inventário cheio.","erro");}
  else mostrarAviso("Não há espaço suficiente no inventário para abrir essa quantidade de ovos.","erro");
  return false;
 }
 moedas-=custo;
 const encontrados=[],vendidos=[];
 sorteios.forEach((base)=>{
  // Cada pet nascido recebe todas as mutações globais que estiverem ativas naquele instante.
  const mutacoesEvento=obterMutacoesEventoAtivas();
  const multMutacoes=multiplicadorBonusMutacoes(mutacoesEvento);
  const pet={id:"pet_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,9),nome:base.nome,sigla:base.sigla,raridade:base.raridade,peso:base.peso,mult:base.mult*multMutacoes,cor:base.cor,borda:base.borda||"",dourado:false,mutacoesEvento};
  ovosAbertos++;
  if(petsVendaAutomatica.includes(base.nome)){
   const valor=VALOR_VENDA_PET[pet.raridade]||0;moedas+=valor;vendidos.push({pet,valor});
  }else{petsInventario.push(pet);encontrados.push(pet);petsConseguidosSessao.push({nome:pet.nome,raridade:pet.raridade,dourado:false,diamante:false,rainbow:false,mutacoesEvento});}
 });
 atualizarPainelAFK();
 salvar();renderizarChancesOvo();renderizarResumoPets();
 const raros=encontrados.filter(p=>(ORDEM_RARIDADE_PETS[p.raridade]??0)>=2);
 if(raros.length){
  const nomes=raros.map(p=>p.nome+" ("+p.raridade+", "+p.mult.toFixed(2)+"x)").join(", ");
  mostrarAvisoPet("PET BOM ENCONTRADO! "+nomes,encontrados);somRaro();
 }else if(encontrados.length&&!automatico){
  mostrarAvisoPet("Você conseguiu: "+encontrados.map(p=>p.nome).join(", ")+".",encontrados);
 }
 return true;
}
function abrirOvoPet(automatico=false){return abrirOvosQuantidade(1,automatico);}
function abrirTresOvosPet(){return abrirOvosQuantidade(3,autoOvoComprado&&autoOvoAtivo);}
function atualizarPainelAFK(){
 const botao=document.getElementById("botaoAFKOvos"),painel=document.getElementById("painelAFKOvos"),lista=document.getElementById("listaAFKOvos");
 if(!botao||!painel||!lista)return;
 botao.hidden=!(autoOvoComprado&&autoOvoAtivo);
 painel.hidden=!painelAFKAberto||botao.hidden;
 if(!petsConseguidosSessao.length)lista.textContent="Nenhum pet conseguido ainda.";
 else lista.textContent=petsConseguidosSessao.map((p,i)=>(i+1)+". "+p.nome+(p.void?" VOID":p.rainbow?" RAINBOW":p.diamante?" DIAMANTE":p.dourado?" DOURADO":"")+(p.mutacoesEvento&&p.mutacoesEvento.length?" | "+p.mutacoesEvento.map(k=>nomesMutacaoEvento[k]).join(" + "):"")+" — "+p.raridade).join("\n");
}
function atualizarControlesOvo(){
 const triplo=document.getElementById("abrirTresOvosPet");
 if(triplo){triplo.disabled=!triploOvoComprado;triplo.classList.toggle("triplo-bloqueado",!triploOvoComprado);triplo.textContent=triploOvoComprado?"ABRIR 3 OVOS - $ "+formatarDinheiro(CUSTO_OVO_PET*3):"TRIPLO OVO BLOQUEADO - $ 25M";}
 const auto=document.getElementById("alternarAutoOvoPet");
 if(auto){auto.classList.toggle("auto-ovo-ligado",autoOvoComprado&&autoOvoAtivo);auto.classList.toggle("auto-ovo-desligado",!autoOvoComprado||!autoOvoAtivo);auto.textContent=!autoOvoComprado?"DESBLOQUEAR AUTO - $ 5M":"ABERTURA AUTOMÁTICA: "+(autoOvoAtivo?"LIGADA":"DESLIGADA");}
 atualizarPainelAFK();
}
function processarOvosAutomaticos(){
 const modal=document.getElementById("ovosPetsModal");
 if(!autoOvoComprado||!autoOvoAtivo||!jogoPronto()||!modal||modal.style.display!=="flex")return;
 const agora=Date.now();if(agora-ultimoAutoOvo<INTERVALO_AUTO_OVO)return;
 ultimoAutoOvo=agora;abrirOvosQuantidade(triploOvoComprado?3:1,true);
}
function alternarPet(id){
 const i=petsEquipados.indexOf(id);
 if(i>=0)petsEquipados.splice(i,1);
 else if(petsEquipados.length>=limitePetsEquipados()){mostrarAviso("Seu limite atual é de "+limitePetsEquipados()+" pets equipados. Compre melhorias de pets equipados para liberar mais espaços.","erro");return;}
 else petsEquipados.push(id);
 petSelecionadoId=id;salvar();renderizarPets();
}
let petSelecionadoId=null;
const VALOR_VENDA_PET={"Comum":10000,"Incomum":15000,"Raro":25000,"Épico":50000,"Lendário":100000,"Mítico":250000,"Secreto":500000};
function renderizarResumoPets(){
 const texto="Mascotes: "+petsInventario.length+"/"+limiteInventarioPets()+" | Equipados: "+petsEquipados.length+"/"+limitePetsEquipados()+" | Bônus equipado: "+multiplicadorPets().toFixed(2)+"x | Ovos abertos: "+ovosAbertos+" | Sorte: nível "+sorteOvoNivel;
 const resumo=document.getElementById("petsResumo");if(resumo)resumo.textContent=texto;
 const ovos=document.getElementById("ovosResumo");if(ovos)ovos.textContent="Saldo: $ "+formatarDinheiro(moedas)+" | "+texto;
}
function renderizarChancesOvo(){
 const el=document.getElementById("listaChancesPets");if(!el)return;el.innerHTML="";
 const total=catalogoPets.reduce((a,p)=>a+pesoPetComSorte(p),0);
 const lista=catalogoPets.slice().sort((a,b)=>(ORDEM_RARIDADE_PETS[b.raridade]??-1)-(ORDEM_RARIDADE_PETS[a.raridade]??-1));
 lista.forEach(p=>{
  const cor=CORES_RARIDADE_PETS[p.raridade]||"#d1d5db",autoVenda=petsVendaAutomatica.includes(p.nome);
  const card=document.createElement("div");card.className="pet-chance-card"+(autoVenda?" venda-auto":"");card.style.borderColor=autoVenda?"#ff4545":(p.raridade==="Secreto"?"#fff":cor);card.style.cursor="pointer";card.setAttribute("role","button");card.setAttribute("aria-pressed",String(autoVenda));card.title="Clique para "+(autoVenda?"desativar":"ativar")+" a venda automática";
  const nome=document.createElement("strong");nome.textContent=p.nome;
  const rar=document.createElement("span");rar.className="pet-raridade";rar.textContent=p.raridade.toUpperCase();rar.style.color=cor;rar.style.borderColor=cor;rar.style.background=p.raridade==="Secreto"?"#050505":"#ffffff0b";
  const info=document.createElement("small");info.textContent="Chance: "+(pesoPetComSorte(p)/total*100).toFixed(pesoPetComSorte(p)/total<0.01?3:2)+"% | Multiplicador: "+p.mult.toFixed(2)+"x";
  const status=document.createElement("small");status.className="pet-auto-status";status.textContent=autoVenda?"VENDA AUTOMÁTICA ATIVA — CLIQUE PARA DESATIVAR":"CLIQUE PARA MARCAR VENDA AUTOMÁTICA";
  card.append(nome,rar,info,status);card.addEventListener("click",()=>{if(petsVendaAutomatica.includes(p.nome))petsVendaAutomatica=petsVendaAutomatica.filter(n=>n!==p.nome);else petsVendaAutomatica.push(p.nome);salvar();renderizarChancesOvo();});el.appendChild(card);
 });
 const botao=document.getElementById("comprarOvoPet");if(botao)botao.textContent="ABRIR 1 OVO - $ 100K";
 atualizarControlesOvo();
}
function petCor(p){return p.raridade==="Secreto"?"#ffffff":(CORES_RARIDADE_PETS[p.raridade]||"#d1d5db");}
function selecionarPetInventario(id){petSelecionadoId=id;renderizarPets();}
function nivelEvolucaoPet(p){return p&&p.void?4:p&&p.rainbow?3:p&&p.diamante?2:p&&p.dourado?1:0;}
function nomeNivelPet(n){return n===4?"VOID":n===3?"RAINBOW":n===2?"DIAMANTE":n===1?"DOURADO":"NORMAL";}
function multiplicadorNivelPet(base,nivel){return Number(base.mult||1)*Math.pow(2,nivel);}
function contarPetsMesmoNivel(p,nivel){return petsInventario.filter(x=>x.nome===p.nome&&nivelEvolucaoPet(x)===nivel).length;}
function contarPetsParaDourado(p){return contarPetsMesmoNivel(p,0);}
function criarPetEvoluido(id,nivelDestino){
 const selecionado=petsInventario.find(x=>x.id===id);
 if(!selecionado){mostrarAviso("Selecione um pet primeiro.","erro");return false;}
 const nivelAtual=nivelEvolucaoPet(selecionado);
 if(nivelDestino!==nivelAtual+1||nivelDestino>4){mostrarAviso("Não é possível evoluir esse pet.","erro");return false;}
 const iguais=petsInventario.filter(x=>x.nome===selecionado.nome&&nivelEvolucaoPet(x)===nivelAtual).slice(0,3);
 if(iguais.length<3){mostrarAviso("Você precisa de 3 pets "+selecionado.nome+" "+nomeNivelPet(nivelAtual).toLowerCase()+" iguais.","erro");return false;}
 const ids=new Set(iguais.map(x=>x.id));
 const eraEquipado=iguais.some(x=>petsEquipados.includes(x.id));
 petsInventario=petsInventario.filter(x=>!ids.has(x.id));
 petsEquipados=petsEquipados.filter(x=>!ids.has(x));
 const base=catalogoPets.find(x=>x.nome===selecionado.nome)||selecionado;
 const evoluido={id:"pet_"+nomeNivelPet(nivelDestino).toLowerCase()+"_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,8),nome:base.nome,sigla:base.sigla,raridade:base.raridade,peso:base.peso,mult:multiplicadorNivelPet(base,nivelDestino)*multiplicadorBonusMutacoes([...new Set(iguais.flatMap(x=>Array.isArray(x.mutacoesEvento)?x.mutacoesEvento:[]))]),cor:base.cor,borda:base.borda||"",dourado:nivelDestino>=1,diamante:nivelDestino>=2,rainbow:nivelDestino>=3,void:nivelDestino>=4,mutacoesEvento:[...new Set(iguais.flatMap(x=>Array.isArray(x.mutacoesEvento)?x.mutacoesEvento:[]))]};
 petsInventario.push(evoluido);
 if(eraEquipado&&petsEquipados.length<limitePetsEquipados())petsEquipados.push(evoluido.id);
 petSelecionadoId=evoluido.id;salvar();renderizarPets();somRaro();
 mostrarAviso("PET "+nomeNivelPet(nivelDestino)+" CRIADO! "+evoluido.nome+" agora tem multiplicador "+evoluido.mult.toFixed(2)+"x.","ok");
 return true;
}
function criarPetDourado(id){return criarPetEvoluido(id,1);}
function fundirTodosPetsDourados(){
 // Cada clique avança somente um estágio global: normal, dourado, diamante, rainbow e void.
 // Cada trio mantém apenas as mutações que realmente estavam nos seus três pets.
 let nivelAlvo=-1;
 for(let nivel=0;nivel<4;nivel++){
  const temGrupo=catalogoPets.some(base=>Math.floor(petsInventario.filter(p=>p.nome===base.nome&&nivelEvolucaoPet(p)===nivel).length/3)>0);
  if(temGrupo){nivelAlvo=nivel;break;}
 }
 if(nivelAlvo<0){mostrarAviso("Você não tem grupos de 3 pets iguais para avançar de mutação.","info");return;}
 const removidos=new Set(),novos=[],equiparNovos=[];let totalGrupos=0;
 for(const base of catalogoPets){
  const iguais=petsInventario.filter(p=>p.nome===base.nome&&nivelEvolucaoPet(p)===nivelAlvo);
  const grupos=Math.floor(iguais.length/3);if(!grupos)continue;
  const usados=iguais.slice(0,grupos*3);usados.forEach(p=>removidos.add(p.id));
  const deveEquipar=usados.some(p=>petsEquipados.includes(p.id));
  for(let i=0;i<grupos;i++){
   const destino=nivelAlvo+1;
   const trio=usados.slice(i*3,i*3+3);
   const mutacoesEvento=[...new Set(trio.flatMap(x=>Array.isArray(x.mutacoesEvento)?x.mutacoesEvento:[]))];
   const novo={id:"pet_"+nomeNivelPet(destino).toLowerCase()+"_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,9)+"_"+totalGrupos,nome:base.nome,sigla:base.sigla,raridade:base.raridade,peso:base.peso,mult:multiplicadorNivelPet(base,destino)*multiplicadorBonusMutacoes(mutacoesEvento),cor:base.cor,borda:base.borda||"",dourado:destino>=1,diamante:destino>=2,rainbow:destino>=3,void:destino>=4,mutacoesEvento};
   novos.push(novo);if(deveEquipar&&i===0)equiparNovos.push(novo.id);totalGrupos++;
  }
 }
 petsInventario=petsInventario.filter(p=>!removidos.has(p.id)).concat(novos);
 petsEquipados=petsEquipados.filter(id=>!removidos.has(id));
 for(const id of equiparNovos){if(petsEquipados.length<limitePetsEquipados())petsEquipados.push(id);}
 petSelecionadoId=novos[novos.length-1]?.id||petsInventario[0]?.id||null;salvar();renderizarPets();somRaro();
 mostrarAviso("FUSÃO CONCLUÍDA: "+totalGrupos+" PET(S) " +nomeNivelPet(nivelAlvo+1)+" CRIADO(S)!","ok");
}
function renderizarStatusPet(){
 const painel=document.getElementById("petStatusPainel");if(!painel)return;
 const p=petsInventario.find(x=>x.id===petSelecionadoId);
 painel.innerHTML="";
 const titulo=document.createElement("h3");titulo.textContent="STATUS DO PET";painel.appendChild(titulo);
 if(!p){const vazio=document.createElement("p");vazio.textContent=petsInventario.length?"Selecione um mascote na grade para ver os detalhes.":"Seu inventário está vazio. Abra um ovo para conseguir mascotes.";painel.appendChild(vazio);return;}
 const nivel=nivelEvolucaoPet(p),rotulo=nomeNivelPet(nivel);
 const nome=document.createElement("div");nome.className="pet-status-nome";nome.textContent=p.nome+(nivel?" "+rotulo:"");nome.style.color=nivel===4?"#c9a7ff":nivel===3?"#ff9ded":nivel===2?"#aaf2ff":nivel===1?"#ffe27a":petCor(p);
 const rar=document.createElement("p");rar.textContent="Raridade: "+p.raridade+(nivel?" | "+rotulo:"");rar.style.color=nome.style.color;
 const mult=document.createElement("p");mult.textContent="Multiplicador: "+Number(p.mult||1).toFixed(2)+"x"+(nivel?" ("+Math.pow(2,nivel)+"x do normal)":"");
 const equipado=document.createElement("p");equipado.textContent=petsEquipados.includes(p.id)?"Status: EQUIPADO":"Status: NO INVENTÁRIO";
 const base=catalogoPets.find(x=>x.nome===p.nome),total=catalogoPets.reduce((a,x)=>a+x.peso,0);
 const chance=document.createElement("p");chance.textContent="Chance no ovo: "+(base?(base.peso/total*100).toFixed(base.peso<1?2:1):"-")+"%";
 const acao=document.createElement("button");acao.className="novo-acao";acao.type="button";acao.textContent=petsEquipados.includes(p.id)?"DESEQUIPAR":"EQUIPAR PET";if(petsEquipados.includes(p.id))acao.style.background="linear-gradient(180deg,#e34b4b,#9d2020)";acao.addEventListener("click",()=>alternarPet(p.id));
 painel.append(nome,rar,mult,equipado,chance,acao);
 if((p.mutacoesEvento||[]).length){const tag=document.createElement("p");tag.textContent="MUTAÇÃO DE EVENTO: "+p.mutacoesEvento.map(k=>nomesMutacaoEvento[k]||k).join(" + ");tag.className="pet-mutacao-tag";tag.style.color=p.mutacoesEvento.includes("hacker")?"#54ff91":p.mutacoesEvento.includes("anjo")?"#fff1a8":"#d2a2ff";painel.appendChild(tag);}
 if(nivel<4){
  const proximo=nivel+1,qtd=contarPetsMesmoNivel(p,nivel);
  const evoluir=document.createElement("button");evoluir.id=proximo===1?"fazerPetDourado":proximo===2?"fazerPetDiamante":proximo===3?"fazerPetRainbow":"fazerPetVoid";evoluir.className="novo-acao";evoluir.type="button";evoluir.textContent="FUNDIR PARA "+nomeNivelPet(proximo)+" ("+qtd+"/3)";evoluir.disabled=qtd<3;evoluir.style.opacity=qtd<3?".55":"1";evoluir.addEventListener("click",()=>criarPetEvoluido(p.id,proximo));painel.appendChild(evoluir);
 }else{
  const etiqueta=document.createElement("p");etiqueta.textContent="PET "+nomeNivelPet(nivel)+": multiplicador "+Math.pow(2,nivel)+"x";etiqueta.style.color=nivel===4?"#c9a7ff":"#ff9ded";etiqueta.style.fontWeight="900";painel.appendChild(etiqueta);
 }
}
function renderizarPets(){
 renderizarResumoPets();
 const el=document.getElementById("listaPets");if(!el)return;el.innerHTML="";
 document.querySelectorAll("[data-pets-ordem]").forEach(b=>b.classList.toggle("ativa",b.dataset.petsOrdem===petsOrdenacao));
 const ordenar=(a,b)=>{
  if(petsOrdenacao==="nome")return a.nome.localeCompare(b.nome,"pt-BR");
  if(petsOrdenacao==="raridade")return (ORDEM_RARIDADE_PETS[b.raridade]??-1)-(ORDEM_RARIDADE_PETS[a.raridade]??-1)||Number(b.mult)-Number(a.mult);
  return Number(b.mult)-Number(a.mult)||(ORDEM_RARIDADE_PETS[b.raridade]??-1)-(ORDEM_RARIDADE_PETS[a.raridade]??-1);
 };
 if(!petsInventario.length){const v=document.createElement("div");v.className="novo-vazio";v.textContent="INVENTARIO VAZIO - ABRA UM OVO PARA CONSEGUIR PETS";el.appendChild(v);petSelecionadoId=null;renderizarStatusPet();return;}
 if(!petsInventario.some(p=>p.id===petSelecionadoId))petSelecionadoId=petsInventario[0].id;
 petsInventario.slice().sort(ordenar).forEach(p=>{
  const cor=petCor(p);const equipado=petsEquipados.includes(p.id);const mutacoes=Array.isArray(p.mutacoesEvento)?[...new Set(p.mutacoesEvento)]:[];const card=document.createElement("button");card.type="button";card.className="pet-slot"+(p.id===petSelecionadoId?" selecionado":"")+(p.void?" void":p.rainbow?" rainbow":p.diamante?" diamante":p.dourado?" dourado":"")+(mutacoes.length?" mutacao-"+mutacoes[0]:"")+(equipado?" equipado":"");card.style.borderColor=equipado?"#35e879":(p.void?"#b58aff":p.rainbow?"#ff75e8":p.diamante?"#55dfff":p.dourado?"#f4cf55":cor);card.addEventListener("click",()=>selecionarPetInventario(p.id));
  const sigla=document.createElement("span");sigla.className="pet-iniciais";sigla.textContent=p.sigla||p.nome.slice(0,2).toUpperCase();sigla.style.color=cor;sigla.style.borderColor=cor;sigla.style.background=p.raridade==="Secreto"?"#050505":"#202d40";
  const nome=document.createElement("strong");nome.className="pet-nome-card";nome.textContent=p.nome;
  const rar=document.createElement("small");rar.className="pet-raridade-card";rar.textContent=p.raridade+(nivelEvolucaoPet(p)?" • "+nomeNivelPet(nivelEvolucaoPet(p)):"");
  if(equipado){const estado=document.createElement("span");estado.className="pet-equipado-tag";estado.textContent="✓ EQUIPADO";card.appendChild(estado);}
  if(mutacoes.length){const painelMutacoes=document.createElement("span");painelMutacoes.className="pet-mutacoes-canto";painelMutacoes.setAttribute("aria-label","Mutações: "+mutacoes.map(k=>nomesMutacaoEvento[k]||k).join(", "));mutacoes.forEach(k=>{const tag=document.createElement("span");tag.className="pet-mutacao-mini pet-mutacao-mini-"+k;tag.textContent=k==="anjo"?"A":k==="hacker"?"H":k==="galaxia"?"G":String(k).slice(0,1).toUpperCase();tag.title=nomesMutacaoEvento[k]||k;tag.setAttribute("aria-label",nomesMutacaoEvento[k]||k);painelMutacoes.appendChild(tag);});card.appendChild(painelMutacoes);}
  card.append(sigla,nome,rar);el.appendChild(card);
 });
 renderizarStatusPet();
}
function equiparMelhoresPets(){
 if(!petsInventario.length){mostrarAviso("Você ainda não tem mascotes.","erro");return;}
 const melhores=petsInventario.slice().sort((a,b)=>Number(b.mult)-Number(a.mult)||(ORDEM_RARIDADE_PETS[b.raridade]??-1)-(ORDEM_RARIDADE_PETS[a.raridade]??-1)).slice(0,limitePetsEquipados());
 petsEquipados=melhores.map(p=>p.id);petSelecionadoId=melhores[0]?.id||null;salvar();renderizarPets();mostrarAviso("Seus "+melhores.length+" melhores mascotes foram equipados.","ok");
}
function renderizarModoVendaPets(){
 const area=document.getElementById("vendaPetsConteudo"),botao=document.getElementById("venderPetsSelecionados");if(!area||!botao)return;
 document.querySelectorAll("[data-modo-venda]").forEach(b=>b.classList.toggle("ativa",b.dataset.modoVenda===modoVendaPets));
 area.innerHTML="";
 if(modoVendaPets==="todos"){
  area.innerHTML='<div class="pet-venda-titulo">VENDER TODO O INVENTÁRIO</div><p class="novo-desc">Todos os '+petsInventario.length+' pets serão selecionados, inclusive os equipados.</p>';
 }else if(modoVendaPets==="raridade"){
  const titulo=document.createElement("div");titulo.className="pet-venda-titulo";titulo.textContent="SELECIONE AS RARIDADES";area.appendChild(titulo);
  const valores=document.createElement("div");valores.style.cssText="font-size:10px;color:#bdc9da;margin-bottom:7px";valores.textContent="Comum $10K | Incomum $15K | Raro $25K | Épico $50K | Lendário $100K | Mítico $250K | Secreto $500K";area.appendChild(valores);
  const grade=document.createElement("div");grade.className="pet-venda-opcoes";
  Object.keys(VALOR_VENDA_PET).forEach(r=>{const label=document.createElement("label"),input=document.createElement("input");input.type="checkbox";input.dataset.vendaRaridade=r;label.append(input,document.createTextNode(" "+r));grade.appendChild(label);});area.appendChild(grade);
 }else{
  const titulo=document.createElement("div");titulo.className="pet-venda-titulo";titulo.textContent="SELECIONE OS PETS INDIVIDUALMENTE";area.appendChild(titulo);
  const aviso=document.createElement("p");aviso.className="novo-desc";aviso.textContent="Toque nos pets para marcar. Os selecionados recebem um X vermelho.";area.appendChild(aviso);
  const grade=document.createElement("div");grade.style.cssText="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px;max-height:38vh;overflow:auto";
  petsInventario.forEach(p=>{const label=document.createElement("label");label.style.cssText="display:flex;align-items:center;gap:6px;padding:7px;border:1px solid #52647d;border-radius:7px;background:#172438;color:#fff;font-size:11px";const input=document.createElement("input");input.type="checkbox";input.checked=petsMarcadosVenda.has(p.id);input.addEventListener("change",()=>{if(input.checked)petsMarcadosVenda.add(p.id);else petsMarcadosVenda.delete(p.id);renderizarModoVendaPets();});const x=document.createElement("strong");x.textContent=input.checked?"✖":"";x.style.cssText="color:#ff4141;font-size:17px";label.append(input,x,document.createTextNode(p.nome+" • "+p.raridade));grade.appendChild(label);});area.appendChild(grade);
 }
 botao.textContent="VENDER PETS";botao.dataset.confirmar="nao";
}
function venderPetsSelecionados(){
 let vender=[];
 if(modoVendaPets==="todos")vender=petsInventario.slice();
 else if(modoVendaPets==="raridade"){
  const raridades=[...document.querySelectorAll("[data-venda-raridade]:checked")].map(x=>x.dataset.vendaRaridade);
  if(!raridades.length){mostrarAviso("Selecione pelo menos uma raridade.","erro");return;}
  vender=petsInventario.filter(p=>raridades.includes(p.raridade));
 }else vender=petsInventario.filter(p=>petsMarcadosVenda.has(p.id));
 if(!vender.length){mostrarAviso("Nenhum pet foi selecionado para venda.","erro");return;}
 const total=vender.reduce((s,p)=>s+(VALOR_VENDA_PET[p.raridade]||0),0),botao=document.getElementById("venderPetsSelecionados");
 if(botao.dataset.confirmar!=="sim"){
  botao.dataset.confirmar="sim";botao.textContent="CLIQUE NOVAMENTE PARA CONFIRMAR • "+vender.length+" PET(S)";
  mostrarAviso("Confira a seleção. Clique novamente em VENDER PETS para confirmar.","info");return;
 }
 const ids=new Set(vender.map(p=>p.id));petsInventario=petsInventario.filter(p=>!ids.has(p.id));petsEquipados=petsEquipados.filter(id=>!ids.has(id));
 ids.forEach(id=>petsMarcadosVenda.delete(id));moedas+=total;petSelecionadoId=petsInventario[0]?.id||null;
 salvar();renderizarPets();renderizarModoVendaPets();document.getElementById("venderPetsModal").style.display="none";mostrarAviso(vender.length+" pet(s) vendidos. Você recebeu $ "+formatarDinheiro(total)+".","ok");
}

function jogadorEstaOnline(registro){
 const r=registro||{};
 const nested=r.presenca||{};
 // heartbeatAt é um horário numérico escrito junto com o status; evita depender
 // da conversão de serverTimestamp em snapshots recém-gravados.
 const pres=(typeof r.online==="boolean"&&(r.heartbeatAt||r.atualizadoEm))?r:nested;
 const onlineMarcado=pres.online===true;
 let atualizado=Number(pres.heartbeatAt)||0;
 if(!atualizado){
  try{
   const valor=pres.atualizadoEm;
   if(valor&&typeof valor.toMillis==="function") atualizado=valor.toMillis();
   else if(valor&&typeof valor.toDate==="function") atualizado=valor.toDate().getTime();
   else if(valor&&typeof valor.seconds==="number") atualizado=valor.seconds*1000;
   else if(typeof valor==="number") atualizado=valor>100000000000?valor:valor*1000;
  }catch(e){atualizado=0;}
 }
 const idade=Date.now()-atualizado;
 return onlineMarcado&&atualizado>0&&idade>=-15000&&idade<70000;
}

function criarEtiquetaPresenca(online){
 const tag=document.createElement("span");
 tag.className="presenca-tag "+(online?"on":"off");
 tag.textContent=online?"ON":"OFF";
 tag.setAttribute("aria-label",online?"Jogador online":"Jogador offline");
 return tag;
}

async function renderizarListaRanking(snap){
 const el=document.getElementById("listaRanking");
 const mapa=new Map();
 // rankingGlobal é a lista pública; jogadores contém o cadastro histórico de toda conta criada.
 // Unimos os dois formatos para não limitar o ranking a quem entrou recentemente.
 const docs=Array.isArray(snap)?snap:(snap&&snap.docs?snap.docs:[]);
 docs.forEach(doc=>{
  const d=typeof doc.data==="function"?(doc.data()||{}):(doc.data||{});
  const uid=doc.id||d.uid;if(!uid)return;
  const dados=d.dados||{};const ranking=d.ranking||{};
  const nome=String(d.nome||d.displayName||d.emailNome||("Jogador "+String(uid).slice(0,6)));
  const moedas=Number(d.moedas??ranking.moedas??dados.moedas)||0;
  const renascimentos=Number(d.renascimentos??ranking.renascimentos??dados.renascimentos)||0;
  const anterior=mapa.get(uid)||{};
  mapa.set(uid,{uid,nome:(nome&&nome!=="Jogador "+String(uid).slice(0,6))?nome:(anterior.nome||nome),moedas:Number.isFinite(moedas)?moedas:(anterior.moedas||0),renascimentos:Number.isFinite(renascimentos)?renascimentos:(anterior.renascimentos||0),registroJogador:(d.presenca||typeof d.online==="boolean")?d:anterior.registroJogador||null,online:false});
 });
 const lista=[...mapa.values()];
 lista.forEach(j=>{j.online=!!(j.registroJogador&&jogadorEstaOnline(j.registroJogador));});
 lista.sort((a,b)=>{
  const diferenca=rankingTipo==="dinheiro"?b.moedas-a.moedas:b.renascimentos-a.renascimentos;
  return diferenca||a.nome.localeCompare(b.nome,"pt-BR");
 });
 rankingUltimaLista=lista;
 el.innerHTML="";el.className="";
 if(!lista.length){el.className="novo-vazio";el.textContent="Ainda não há jogadores cadastrados.";return;}
 lista.forEach((j,i)=>{
  const card=document.createElement("div");card.className="novo-card";
  const n=document.createElement("div");n.className="novo-rank-num";n.textContent=(i+1)+"º";
  const info=document.createElement("div");info.className="novo-info";
  const nome=document.createElement("strong");nome.textContent=j.nome+(usuarioAtual&&j.uid===usuarioAtual.uid?" (Você)":"");nome.appendChild(criarEtiquetaPresenca(j.online));
  const desc=document.createElement("small");
  if(rankingTipo==="dinheiro"){
   desc.className="valor-dinheiro";desc.textContent="$ "+formatarDinheiro(j.moedas);
  }else{desc.className="valor-renascimentos";desc.textContent=String(j.renascimentos);}
  info.append(nome,desc);card.append(n,info);el.appendChild(card);
 });
}

async function sincronizarRankingHistoricoAdmin(){
 // Somente o administrador pode ler a coleção privada completa de jogadores.
 // Ele publica apenas nome e estatísticas no rankingGlobal, sem expor inventário ou dados privados.
 if(!usuarioAtual||usuarioAtual.uid!==ADMIN_UID)return;
 try{
  const snap=await comTempoLimite(db.collection("jogadores").get(),25000,"recuperar todas as contas já criadas para o ranking");
  const docs=snap.docs||[];
  for(let i=0;i<docs.length;i+=400){
   const lote=db.batch();
   docs.slice(i,i+400).forEach(doc=>{
    const d=doc.data()||{},dados=d.dados||{},ranking=d.ranking||{};
    lote.set(db.collection("rankingGlobal").doc(doc.id),{
     nome:String(d.nome||("Jogador "+doc.id.slice(0,6))),
     moedas:Math.max(0,Number(ranking.moedas??dados.moedas)||0),
     renascimentos:Math.max(0,Number(ranking.renascimentos??dados.renascimentos)||0),
     presenca:d.presenca||{online:false}
    },{merge:true});
   });
   await lote.commit();
  }
  console.info("Ranking histórico sincronizado: "+docs.length+" conta(s).");
 }catch(error){console.warn("Não foi possível sincronizar todas as contas antigas no ranking:",error);}
}

function pararRankingAoVivo(){
 // Mantido por compatibilidade com os botões existentes; o ranking agora usa
 // consultas pontuais, nunca um listener em tempo real.
 cancelarRankingAoVivo=null;
}

async function carregarRanking(forcar=false){
 const modal=document.getElementById("rankingModal");
 if(!modal||modal.style.display!=="flex"||rankingBuscaEmAndamento)return;
 const expirou=(Date.now()-rankingUltimaBusca)>=30000;
 if(!forcar&&rankingUltimoSnapshot&&!expirou){renderizarListaRanking(rankingUltimoSnapshot);return;}
 rankingBuscaEmAndamento=true;
 const el=document.getElementById("listaRanking");
 if(!rankingUltimoSnapshot){el.className="novo-vazio";el.textContent="Carregando ranking...";}
 try{
  // Busca o índice público sem esperar a sincronização histórica do administrador.
  const rankingPromise=comTempoLimite(db.collection("rankingGlobal").get(),18000,"ler rankingGlobal");
  let docs=[];
  if(usuarioAtual&&usuarioAtual.uid===ADMIN_UID){
   const [rankingSnap,jogadoresSnap]=await Promise.all([
    rankingPromise,
    comTempoLimite(db.collection("jogadores").get(),18000,"ler contas dos jogadores")
   ]);
   docs=[...(rankingSnap.docs||[]),...(jogadoresSnap.docs||[])];
   // A sincronização histórica publica os registros antigos para os outros jogadores,
   // mas não bloqueia a exibição do ranking nesta tela.
   sincronizarRankingHistoricoAdmin().catch(e=>console.warn("Sincronização histórica adiada:",e));
  }else{
   const rankingSnap=await rankingPromise;
   docs=rankingSnap.docs||[];
  }
  rankingUltimoSnapshot=docs;
  rankingUltimaBusca=Date.now();
  await renderizarListaRanking(docs);
 }catch(error){
  console.error("Falha ao atualizar ranking:",error);
  el.className="novo-vazio";
  el.textContent=(error&&error.code==="permission-denied")?"O Firestore bloqueou a leitura do ranking. Confira as regras de rankingGlobal.":"Não foi possível carregar o ranking. Toque para tentar novamente.";
 }finally{rankingBuscaEmAndamento=false;}
}

function atualizarContagemRanking(){
 const texto=document.getElementById("rankingContagem");
 const modal=document.getElementById("rankingModal");
 const agora=Date.now();
 if(agora>=rankingProximaAtualizacao){
  rankingProximaAtualizacao=agora+60000;
  if(modal&&modal.style.display==="flex")carregarRanking(true);
 }
 const restante=Math.max(0,Math.ceil((rankingProximaAtualizacao-Date.now())/1000));
 if(texto)texto.textContent=String(Math.floor(restante/60)).padStart(2,"0")+":"+String(restante%60).padStart(2,"0");
}
// Ao voltar de uma aba/app em segundo plano, sincroniza o cronômetro com o relógio real.
document.addEventListener("visibilitychange",()=>{if(!document.hidden)atualizarContagemRanking();});


function multiplicadorRenascimento(){
// Bônus linear: 0 renascimentos = 1x; cada renascimento acrescenta +1x.
return 1+renascimentos;
}

function multiplicadorMelhoria(){
// Bônus exclusivo da melhoria de dinheiro: nível 0 = 1x, nível 1 = 2x, nível 2 = 3x.
return 1+multiplicadorCompras;
}

function multiplicadorDinheiro(){
// Os bônus permanentes ficam separados do evento temporário global.
return multiplicadorRenascimento()*multiplicadorMelhoria();
}

function multiplicadorEventoAtual(){
const restante=Number(eventoGlobal.expiraEm)||0;
if(!eventoGlobal.ativo||(eventoGlobal.permanente!==true&&restante<=Date.now())){
if(eventoGlobal.ativo&&eventoGlobal.permanente!==true){eventoGlobal.ativo=false;atualizarBadgeEvento();}
return 1;
}
return Math.max(1,Number(eventoGlobal.multiplicador)||1);
}

function formatarTempoEvento(ms){const total=Math.max(0,Math.ceil(ms/1000));const m=Math.floor(total/60),s=total%60;return String(m).padStart(2,"0")+":" +String(s).padStart(2,"0");}
function atualizarBadgeEvento(){
const badge=document.getElementById("eventoGlobalBadge");
if(!badge)return;
const restante=(Number(eventoGlobal.expiraEm)||0)-Date.now();
const ativo=eventoGlobal.ativo&&(eventoGlobal.permanente===true||restante>0);
badge.style.display=ativo?"flex":"none";
if(!ativo)return;
document.getElementById("eventoGlobalMultiplicador").textContent=eventoGlobal.multiplicador+"x";
document.getElementById("eventoGlobalTempo").textContent=eventoGlobal.permanente?"DINHEIRO PERMANENTE":"DINHEIRO "+formatarTempoEvento(restante);
}

let estadoEventoGlobalConhecido=false;
let eventoGlobalEstavaAtivo=false;
function iniciarMonitoramentoEventoGlobal(){
 iniciarMonitoramentoEventoSorte();
if(cancelarMonitoramentoEvento){try{cancelarMonitoramentoEvento();}catch(e){}cancelarMonitoramentoEvento=null;}
const ref=db.collection("eventos").doc("multiplicadorGlobal");
cancelarMonitoramentoEvento=ref.onSnapshot(snapshot=>{
const estavaAtivo=estadoEventoGlobalConhecido&&eventoGlobalEstavaAtivo;
if(!snapshot.exists){
eventoGlobal={ativo:false,multiplicador:1,expiraEm:0,admin:"Admin",id:""};
atualizarBadgeEvento();
if(estavaAtivo)mostrarAviso("O admin "+nomeDoAdminAtual()+" desativou o evento global de dinheiro.","info");
estadoEventoGlobalConhecido=true;
eventoGlobalEstavaAtivo=false;
if(typeof atualizarStatusEventoAdmin==="function")atualizarStatusEventoAdmin();
return;
}
const ev=snapshot.data()||{};
const expira=ev.expiraEm&&typeof ev.expiraEm.toMillis==="function"?ev.expiraEm.toMillis():Number(ev.expiraEm)||0;
const permanente=ev.permanente===true;
const ativo=ev.ativo===true&&(permanente||expira>Date.now());
const id=String(ev.id||"");
const admin=String(ev.admin||"Admin");
const multiplicador=Math.max(1,Number(ev.multiplicador)||1);
eventoGlobal={ativo,multiplicador,expiraEm:expira,permanente,admin,id};
atualizarBadgeEvento();

// Cada aparelho recebe esta atualização diretamente do mesmo documento do Firestore.
if(ativo&&(!estadoEventoGlobalConhecido||!eventoGlobalEstavaAtivo||id!==ultimoEventoGlobalAvisado)){
ultimoEventoGlobalAvisado=id;
mostrarAviso("O admin "+admin+" ativou o evento permanente de dinheiro de "+multiplicador+"x!","ok");
}else if(!ativo&&estavaAtivo){
if(ev.ativo===true&&ev.permanente!==true&&expira<=Date.now()){
mostrarAviso("O evento global de dinheiro terminou.","info");
}else{
mostrarAviso("O admin "+admin+" desativou o evento global de dinheiro de "+multiplicador+"x.","info");
}
}
estadoEventoGlobalConhecido=true;
eventoGlobalEstavaAtivo=ativo;
if(typeof atualizarStatusEventoAdmin==="function")atualizarStatusEventoAdmin();
},error=>console.error("Erro ao acompanhar evento global:",error));
}
let ultimoEventoGlobalAvisado="";
setInterval(()=>{atualizarBadgeEvento();atualizarBadgeEventoSorte();atualizarBadgesMutacao();},500);

function precoRenascimento(){
// Começa em 10 milhões e triplica a cada renascimento realizado.
return 10000000*Math.pow(3,renascimentos);
}

const renascimentoModal=document.getElementById("renascimentoModal");
const renascimentoInfo=document.getElementById("renascimentoInfo");
const confirmarRenascimento=document.getElementById("confirmarRenascimento");
const cancelarRenascimento=document.getElementById("cancelarRenascimento");

function abrirRenascimento(){
if(!jogoPronto())return;
const custo=precoRenascimento();
const proximo=1+(renascimentos+1);
renascimentoInfo.innerHTML="Custo: <strong>$ "+formatarDinheiro(custo)+"</strong><br>Seu dinheiro: <strong>$ "+formatarDinheiro(moedas)+"</strong><br>Bônus de renascimento atual: <strong>"+multiplicadorRenascimento().toFixed(1)+"x</strong><br>Melhoria de dinheiro atual: <strong>"+multiplicadorMelhoria().toFixed(1)+"x</strong><br>Bônus de renascimento após comprar: <strong>"+proximo.toFixed(1)+"x</strong><br>Renascimentos: <strong>"+renascimentos+" → "+(renascimentos+1)+"</strong>";
confirmarRenascimento.disabled=moedas<custo;
confirmarRenascimento.textContent=moedas>=custo?"FAZER RENASCIMENTO":"DINHEIRO INSUFICIENTE";
confirmarRenascimento.style.opacity=moedas>=custo?"1":".55";
renascimentoModal.style.display="flex";
}

function fecharRenascimento(){
renascimentoModal.style.display="none";
}

function fazerRenascimento(){
if(!jogoPronto())return;
const custo=precoRenascimento();
if(moedas<custo){
mostrarAviso("Você precisa de $ "+formatarDinheiro(custo)+" para renascer.","erro");
fecharRenascimento();
return;
}
renascimentos++;
moedas=0;
picaretasCompradas=[0];
mineriosComprados=[0];
picaretaAtual=0;
minerioAtual=0;
// Todas as melhorias compradas são resetadas.
multiplicadorCompras=0;
precoMultiplicador=100;
autoClickerComprado=false;
autoClickerProComprado=false;
autoClickerAtivo=false;
autoClickerProAtivo=false;
autoOvoComprado=false;autoOvoAtivo=false;ultimoAutoOvo=Date.now();triploOvoComprado=false;
sorteOvoNivel=0;precoSorteOvo=200;impulsoPetsNivel=0;precoImpulsoPets=500000;melhoriaInventarioPets=0;melhoriaPetsEquipados=0;
ultimoAutoClick=Date.now();
salvar();
somRaro();
fecharRenascimento();
mostrarAviso("RENASCIMENTO "+renascimentos+"! Bônus de renascimento: "+multiplicadorRenascimento().toFixed(1)+"x. Melhoria de dinheiro: "+multiplicadorMelhoria().toFixed(1)+"x.","ok");
}

confirmarRenascimento.addEventListener("click",fazerRenascimento);
cancelarRenascimento.addEventListener("click",fecharRenascimento);
renascimentoModal.addEventListener("pointerdown",evento=>{if(evento.target===renascimentoModal)fecharRenascimento();});

function comprarMultiplicador(){
if(moedas<precoMultiplicador){
mostrarAviso("SALDO INSUFICIENTE");
return;
}

moedas-=precoMultiplicador;
multiplicadorCompras++;
precoMultiplicador*=3;

somRaro();
salvar();
}

function comprarAutoClicker(){
if(autoClickerComprado)return;

if(moedas<100000){
mostrarAviso("SALDO INSUFICIENTE");
return;
}

moedas-=100000;
autoClickerComprado=true;
autoClickerAtivo=false;

somRaro();
salvar();
mostrarAviso("AUTO CLICKER DESBLOQUEADO!","ok");
}

function comprarAutoClickerPro(){
if(autoClickerProComprado)return;

if(moedas<10000000){
mostrarAviso("SALDO INSUFICIENTE");
return;
}

moedas-=10000000;
autoClickerProComprado=true;
autoClickerProAtivo=false;

somRaro();
salvar();
mostrarAviso("AUTO CLICKER PRO DESBLOQUEADO!","ok");
}

function alternarAutoClicker(){
if(!autoClickerComprado)return;

autoClickerAtivo=!autoClickerAtivo;

if(autoClickerAtivo){
autoClickerProAtivo=false;
ultimoAutoClick=Date.now();
somEquipar();
}else{
somClique();
}

salvar();
}

function alternarAutoClickerPro(){
if(!autoClickerProComprado)return;

autoClickerProAtivo=!autoClickerProAtivo;

if(autoClickerProAtivo){
autoClickerAtivo=false;
ultimoAutoClick=Date.now();
somRaro();
}else{
somClique();
}

salvar();
}

// ÁUDIO

function iniciarAudio(){
if(audioAtivo){
if(audio&&audio.state==="suspended")audio.resume();
return;
}
try{
const A=window.AudioContext||window.webkitAudioContext;
if(!A)return;
audio=new A();
masterGain=audio.createGain();
masterGain.gain.value=volumeGeral*1.8;
masterGain.connect(audio.destination);
audioAtivo=true;
if(audio.state==="suspended")audio.resume();
}catch(e){}
}

function tom(freq,duracao,volume,tipo="sine",freqFinal=null,atraso=0){
if(!audioAtivo||!audio)return;
try{
const agora=audio.currentTime+atraso;
const osc=audio.createOscillator();
const ganho=audio.createGain();
osc.type=tipo;
osc.frequency.setValueAtTime(freq,agora);
if(freqFinal!==null)osc.frequency.exponentialRampToValueAtTime(Math.max(1,freqFinal),agora+duracao);
ganho.gain.setValueAtTime(0.0001,agora);
ganho.gain.exponentialRampToValueAtTime(volume,agora+0.01);
ganho.gain.exponentialRampToValueAtTime(0.0001,agora+duracao);
osc.connect(ganho);
ganho.connect(masterGain);
osc.start(agora);
osc.stop(agora+duracao+0.02);
}catch(e){}
}

function ruido(duracao,volume,frequencia=1200,atraso=0){
if(!audioAtivo||!audio)return;
try{
const tamanho=Math.ceil(audio.sampleRate*duracao);
const buffer=audio.createBuffer(1,tamanho,audio.sampleRate);
const dados=buffer.getChannelData(0);
for(let i=0;i<tamanho;i++)dados[i]=Math.random()*2-1;
const fonte=audio.createBufferSource();
const filtro=audio.createBiquadFilter();
const ganho=audio.createGain();
const agora=audio.currentTime+atraso;
fonte.buffer=buffer;
filtro.type="lowpass";
filtro.frequency.value=frequencia;
ganho.gain.setValueAtTime(volume,agora);
ganho.gain.exponentialRampToValueAtTime(0.0001,agora+duracao);
fonte.connect(filtro);
filtro.connect(ganho);
ganho.connect(masterGain);
fonte.start(agora);
fonte.stop(agora+duracao);
}catch(e){}
}

function somMinerar(){
ruido(0.075,0.9,650);
ruido(0.055,0.55,1100,0.006);
}

function somCompra(){
tom(520,0.13,0.25,"sine",700);
tom(780,0.18,0.25,"sine",1050,0.10);
tom(1040,0.22,0.20,"sine",1300,0.19);
}

function somEquipar(){
tom(650,0.10,0.22,"sine",850);
tom(950,0.15,0.22,"sine",1150,0.08);
}

function somRaro(){
tom(660,0.35,0.25,"sine",1000);
tom(990,0.40,0.25,"sine",1500,0.10);
tom(1320,0.55,0.22,"sine",1800,0.22);
}

function somClique(){tom(480,0.045,0.16,"sine",350)}

function somAbrirLoja(){
tom(380,0.10,0.22,"sine",550);
tom(620,0.13,0.20,"sine",850,0.07);
}

function somFecharLoja(){tom(650,0.10,0.20,"sine",400)}


// Remove valores que o Firestore rejeita antes de enviar o progresso.
// Isso protege o salvamento mesmo quando algum pet/registro antigo tem campo undefined
// ou uma data inválida. Os dados válidos do jogador são preservados.
function limparDadosParaFirestore(valor,emArray=false){
if(valor===undefined||typeof valor==="function"||typeof valor==="symbol")return emArray?null:undefined;
if(valor===null)return null;
if(typeof valor==="number")return Number.isFinite(valor)?valor:null;
if(valor instanceof Date)return Number.isFinite(valor.getTime())?valor:null;
if(Array.isArray(valor))return valor.map(item=>limparDadosParaFirestore(item,true));
if(typeof valor==="object"){
// Mantém objetos especiais do Firebase sem desmontá-los.
if(typeof valor.toDate==="function"||typeof valor.toMillis==="function")return valor;
const limpo={};
for(const chave of Object.keys(valor)){
const item=limparDadosParaFirestore(valor[chave],false);
if(item!==undefined)limpo[chave]=item;
}
return limpo;
}
return valor;
}

function dadosDoJogo(){
return{
moedas,
renascimentos,
picaretasCompradas,
mineriosComprados,
picaretaAtual,
minerioAtual,
volumeGeral,
adminDesbloqueado:false,
codigosUsados,
multiplicadorCompras,
precoMultiplicador,
autoClickerComprado,
autoClickerProComprado,
autoClickerAtivo,
autoClickerProAtivo,
autoOvoComprado,
autoOvoAtivo:false,
triploOvoComprado,
sorteOvoNivel,
precoSorteOvo,
impulsoPetsNivel,
precoImpulsoPets,
petsVendaAutomatica,
mundoAtual,
mundosDesbloqueados,
petsInventario,
petsEquipados,
melhoriaInventarioPets,
melhoriaPetsEquipados,
ovosAbertos:ovosAbertos
};
}

async function publicarResumoRanking(uid,nome,dados,online=true){
 if(!uid||!dados)return;
 const resumo={nome:String(nome||"Jogador"),moedas:Math.max(0,Number(dados.moedas)||0),renascimentos:Math.max(0,Number(dados.renascimentos)||0),online:online===true,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()};
 try{await db.collection("rankingGlobal").doc(uid).set(resumo,{merge:true});}
 catch(error){console.warn("Não foi possível atualizar o ranking público:",error);}
}

let bloqueandoSalvamentoAdmin=false;
function agendarSalvamentoNuvem(dados){
if(bloqueandoSalvamentoAdmin||!jogoPronto()||carregandoDados||!usuarioAtual)return;
// Não reinicia o temporizador em cada mineração: isso impedia o envio
// quando o jogador ganhava dinheiro continuamente (auto-click/mineração rápida).
if(timerSalvamentoNuvem)return;
const id=usuarioAtual.uid;
timerSalvamentoNuvem=setTimeout(async()=>{
timerSalvamentoNuvem=null;
if(!usuarioAtual||usuarioAtual.uid!==id||!jogoPronto()||carregandoDados)return;
// Lê o estado atual no momento do envio, não uma cópia antiga capturada antes.
const copia=limparDadosParaFirestore(dadosDoJogo());
try{
const nomeRanking=usuarioAtual.displayName||usuarioAtual.email.split("@")[0];
await db.collection("jogadores").doc(id).set({
nome:nomeRanking,
dados:copia,
ranking:{moedas:Number(copia.moedas)||0,renascimentos:Number(copia.renascimentos)||0},
atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()
},{merge:true});
await publicarResumoRanking(id,nomeRanking,copia,true);
}catch(error){console.error("Erro ao salvar no Firebase:",error);}
},500);
}

function salvar(){
atualizarMundosDesbloqueados();
const dados=dadosDoJogo();
if(!jogoPronto()||carregandoDados)return;
// Marca a versão local para recuperar alterações recentes caso a página seja atualizada
// antes do envio com atraso ao Firestore terminar.
dados._saveUpdatedAt=Date.now();
try{localStorage.setItem("mining_game_save_"+usuarioAtual.uid,JSON.stringify(dados));}catch(e){}
agendarSalvamentoNuvem(dados);
}

function aplicarDados(dados){
moedas=0;
renascimentos=0;
picaretasCompradas=[0];
mineriosComprados=[0];
picaretaAtual=0;
minerioAtual=0;
volumeGeral=1;
adminDesbloqueado=false;
codigosUsados=[];
multiplicadorCompras=0;
precoMultiplicador=100;
autoClickerComprado=false;
autoClickerProComprado=false;
autoClickerAtivo=false;
autoClickerProAtivo=false;
autoOvoComprado=false;autoOvoAtivo=false;ultimoAutoOvo=Date.now();triploOvoComprado=false;
sorteOvoNivel=0;precoSorteOvo=200;impulsoPetsNivel=0;precoImpulsoPets=500000;petsVendaAutomatica=[];
mundoAtual=0;mundosDesbloqueados=[0];petsInventario=[];petsEquipados=[];melhoriaInventarioPets=0;melhoriaPetsEquipados=0;ovosAbertos=0;

if(!dados||typeof dados!=="object")return;
moedas=Math.max(0,Number(dados.moedas)||0);
renascimentos=Math.max(0,Math.min(1000,Math.floor(Number(dados.renascimentos)||0)));
picaretasCompradas=Array.isArray(dados.picaretasCompradas)?dados.picaretasCompradas.map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<picaretas.length):[0];
mineriosComprados=Array.isArray(dados.mineriosComprados)?dados.mineriosComprados.map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<minerios.length):[0];
picaretasCompradas=[...new Set(picaretasCompradas)];
mineriosComprados=[...new Set(mineriosComprados)];
if(!picaretasCompradas.includes(0))picaretasCompradas.push(0);
if(!mineriosComprados.includes(0))mineriosComprados.push(0);
const picaretaSalva=Number(dados.picaretaAtual);
const minerioSalvo=Number(dados.minerioAtual);
if(picaretasCompradas.includes(picaretaSalva))picaretaAtual=picaretaSalva;
if(mineriosComprados.includes(minerioSalvo))minerioAtual=minerioSalvo;
const volumeSalvo=Number(dados.volumeGeral);
if(Number.isFinite(volumeSalvo))volumeGeral=Math.max(0,Math.min(1,volumeSalvo));
// Atualiza o ganho de áudio imediatamente ao carregar cada conta, inclusive 0%.
if(masterGain&&audio){
 try{masterGain.gain.cancelScheduledValues(audio.currentTime);masterGain.gain.setValueAtTime(volumeGeral*1.8,audio.currentTime);}catch(e){masterGain.gain.value=volumeGeral*1.8;}
}
adminDesbloqueado=false;
codigosUsados=Array.isArray(dados.codigosUsados)?dados.codigosUsados.filter(c=>typeof c==="string"):[];
multiplicadorCompras=Math.max(0,Math.floor(Number(dados.multiplicadorCompras)||0));
precoMultiplicador=Number(dados.precoMultiplicador);
if(!Number.isFinite(precoMultiplicador)||precoMultiplicador<100)precoMultiplicador=100*Math.pow(3,multiplicadorCompras);
autoClickerComprado=!!dados.autoClickerComprado;
autoClickerProComprado=!!dados.autoClickerProComprado;
autoClickerAtivo=!!dados.autoClickerAtivo&&autoClickerComprado;
autoClickerProAtivo=!!dados.autoClickerProAtivo&&autoClickerProComprado;
autoOvoComprado=!!dados.autoOvoComprado;autoOvoAtivo=!!dados.autoOvoAtivo&&autoOvoComprado;ultimoAutoOvo=Date.now();triploOvoComprado=!!dados.triploOvoComprado;
sorteOvoNivel=Math.max(0,Math.min(20,Math.floor(Number(dados.sorteOvoNivel)||0)));
precoSorteOvo=Number(dados.precoSorteOvo);if(!Number.isFinite(precoSorteOvo)||precoSorteOvo<200)precoSorteOvo=200*Math.pow(3,sorteOvoNivel);
impulsoPetsNivel=Math.max(0,Math.min(20,Math.floor(Number(dados.impulsoPetsNivel)||0)));
precoImpulsoPets=Number(dados.precoImpulsoPets);if(!Number.isFinite(precoImpulsoPets)||precoImpulsoPets<500000)precoImpulsoPets=500000*Math.pow(2,impulsoPetsNivel);
petsVendaAutomatica=Array.isArray(dados.petsVendaAutomatica)?dados.petsVendaAutomatica.filter(n=>catalogoPets.some(p=>p.nome===n)):[];
if(autoClickerAtivo&&autoClickerProAtivo)autoClickerAtivo=false;
mundoAtual=Math.max(0,Math.min(mundosJogo.length-1,Math.floor(Number(dados.mundoAtual)||0)));
mundosDesbloqueados=Array.isArray(dados.mundosDesbloqueados)?dados.mundosDesbloqueados.map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<mundosJogo.length):[0];
if(!mundosDesbloqueados.includes(0))mundosDesbloqueados.push(0);
melhoriaInventarioPets=Math.max(0,Math.min(6,Math.floor(Number(dados.melhoriaInventarioPets)||0)));
melhoriaPetsEquipados=Math.max(0,Math.min(3,Math.floor(Number(dados.melhoriaPetsEquipados)||0)));
petsInventario=Array.isArray(dados.petsInventario)?dados.petsInventario.filter(p=>p&&typeof p.id==="string"&&catalogoPets.some(c=>c.nome===p.nome)).slice(0,limiteInventarioPets()).map(p=>{const base=catalogoPets.find(c=>c.nome===p.nome);const voidPet=!!p.void,rainbow=!!p.rainbow&&!voidPet,diamante=!!p.diamante&&!rainbow&&!voidPet,dourado=!!p.dourado||diamante||rainbow||voidPet,nivel=voidPet?4:rainbow?3:diamante?2:dourado?1:0;return {...p,sigla:p.sigla||base.sigla,dourado,diamante,rainbow,void:voidPet,mutacoesEvento:Array.isArray(p.mutacoesEvento)?p.mutacoesEvento.filter(k=>["anjo","hacker","galaxia"].includes(k)):[],mult:Number(p.mult)||multiplicadorNivelPet(base,nivel),emoji:undefined};}):[];
petsEquipados=Array.isArray(dados.petsEquipados)?dados.petsEquipados.filter(id=>petsInventario.some(p=>p.id===id)).slice(0,limitePetsEquipados()):[];
ovosAbertos=Math.max(0,Math.floor(Number(dados.ovosAbertos)||0));
atualizarMundosDesbloqueados();
}

let entradaEmAndamento=null;
let uidEntradaEmAndamento=null;
let operacaoManualDeConta=false;

// Presença online/offline compartilhada pelo Firestore.
async function atualizarPresenca(online,uidForcado){
const uid=uidForcado||(usuarioAtual&&usuarioAtual.uid);
if(!uid||!db)return;
const agora=Date.now();
const marca={online:!!online,heartbeatAt:agora,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()};
try{
 await db.collection("jogadores").doc(uid).set({online:!!online,heartbeatAt:agora,atualizadoEm:marca.atualizadoEm,presenca:marca},{merge:true});
 await db.collection("rankingGlobal").doc(uid).set({online:!!online,heartbeatAt:agora,atualizadoEm:marca.atualizadoEm},{merge:true});
}catch(error){console.warn("Não foi possível atualizar a presença:",error);}
}
function iniciarPresenca(uid){
if(timerPresenca)clearInterval(timerPresenca);
ultimaPresencaUid=uid;
atualizarPresenca(true,uid);
timerPresenca=setInterval(()=>{
if(usuarioAtual&&usuarioAtual.uid===uid)atualizarPresenca(true,uid);
},15000);
}
function pararPresenca(uid){
if(timerPresenca){clearInterval(timerPresenca);timerPresenca=null;}
if(uid)atualizarPresenca(false,uid);
}
window.addEventListener("pagehide",()=>{if(ultimaPresencaUid)atualizarPresenca(false,ultimaPresencaUid);});
document.addEventListener("visibilitychange",()=>{
if(usuarioAtual&&document.visibilityState!=="hidden")atualizarPresenca(true,usuarioAtual.uid);
});

function nomeDoAdminAtual(){
if(!usuarioAtual)return "Admin";
const nome=String(usuarioAtual.displayName||usuarioAtual.email||"").trim();
return nome.includes("@")?nome.split("@")[0]:(nome||"Admin");
}

function entrarNoJogo(user,nome){
mensagemDeLogin("Conta reconhecida. Carregando seu progresso...",false);
if(entradaEmAndamento&&uidEntradaEmAndamento===user.uid)return entradaEmAndamento;
uidEntradaEmAndamento=user.uid;
entradaEmAndamento=(async()=>{
dadosCarregados=false;
usuarioAtual=user;
ultimoAvisoAdminId="";
try{
mensagemDeLogin("Conectado! Buscando seu progresso salvo...",false);
const ref=db.collection("jogadores").doc(user.uid);
// Fazemos uma única leitura do documento por entrada. A versão anterior
// consultava o mesmo documento duas vezes e ainda aguardava updateProfile.
const snap=await comTempoLimite(ref.get(),12000,"consultar os dados da conta");
const registroInicial=snap.exists?(snap.data()||{}):{};
// O Firebase autentica e-mails sem diferenciar maiúsculas, mas o nome público
// continua respeitando exatamente a capitalização originalmente cadastrada.
const nomeCanonico=user.uid===ADMIN_UID?"Artur":String(registroInicial.nome||user.displayName||nome||user.email.split("@")[0]);
if(nome&&nomeCanonico!==nome){
  try{await auth.signOut();}catch(e){}
  const erroNome=new Error("Nome de usuário incorreto. Digite exatamente como foi cadastrado, respeitando maiúsculas e minúsculas.");
  erroNome.code="auth/username-case-mismatch";
  throw erroNome;
}
let dadosConta={};
let dadosLocais={};
try{dadosLocais=JSON.parse(localStorage.getItem("mining_game_save_"+user.uid)||"{}");}catch(e){dadosLocais={};}
if(snap.exists){
const dadosNuvem=(snap.data()||{}).dados||{};
const versaoLocal=Number(dadosLocais&&dadosLocais._saveUpdatedAt)||0;
const versaoNuvem=Number(dadosNuvem&&dadosNuvem._saveUpdatedAt)||0;
// Recupera inventário, pets equipados e preferências de venda mais recentes do aparelho.
dadosConta=versaoLocal>versaoNuvem?dadosLocais:dadosNuvem;
ultimoAvisoAdminId="";
// Corrige registros antigos sem bloquear a abertura do jogo.
if(!registroInicial.nome){
  ref.set({nome:nomeCanonico},{merge:true}).catch(e=>console.warn("Não foi possível atualizar o nome público:",e));
}
}else{
try{dadosConta=JSON.parse(localStorage.getItem("mining_game_save_"+user.uid)||"{}");}catch(e){dadosConta={};}
await comTempoLimite(ref.set({
nome:nomeCanonico,
dados:dadosConta,
criadoEm:firebase.firestore.FieldValue.serverTimestamp()
},{merge:true}),15000,"criar o registro do jogador");
}
carregandoDados=true;
aplicarDados(dadosConta);
if(masterGain&&audio){try{masterGain.gain.cancelScheduledValues(audio.currentTime);masterGain.gain.setValueAtTime(volumeGeral*1.8,audio.currentTime);}catch(e){masterGain.gain.value=volumeGeral*1.8;}}
try{localStorage.setItem("mining_game_save_"+user.uid,JSON.stringify(dadosConta));}catch(e){}
carregandoDados=false;
if(snap.exists&&Number(dadosConta&&dadosConta._saveUpdatedAt)>Number(((snap.data()||{}).dados||{})._saveUpdatedAt||0)){
ref.set({dados:dadosConta,ranking:{moedas:Number(dadosConta.moedas)||0,renascimentos:Number(dadosConta.renascimentos)||0},atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true}).catch(e=>console.warn("Não foi possível sincronizar imediatamente o salvamento recuperado:",e));
}
adminDesbloqueado=(user.uid===ADMIN_UID);
codigoAdminSessao="";
dadosCarregados=true;
iniciarMonitoramentoJogador(user.uid);
iniciarMonitoramentoEventoGlobal();
iniciarPresenca(user.uid);
// O ranking é complementar: nunca pode bloquear a entrada no jogo.
// As gravações continuam acontecendo em segundo plano, sem prender a tela de login.
publicarResumoRanking(user.uid,nomeCanonico,dadosConta,true).catch(error=>console.warn("Falha ao publicar ranking após login:",error));
if(user.uid===ADMIN_UID){
  sincronizarRankingHistoricoAdmin().catch(error=>console.warn("Falha ao sincronizar ranking histórico:",error));
}
loginModal.style.display="none";
mensagemLogin.textContent="";
senhaLogin.value="";
salvarContaUsada(nomeCanonico);
return true;
}catch(error){
usuarioAtual=null;
carregandoDados=false;
dadosCarregados=false;
console.error("Erro ao carregar conta:",error);
let detalhe=error.code==="permission-denied"
?"O Firebase bloqueou o acesso aos dados. Verifique as regras do Firestore da coleção jogadores (ou a conta pode estar banida)."
:"Erro ao carregar seu progresso: "+(error.message||"falha de conexão");
mensagemDeLogin(detalhe);
return false;
}
})();
return entradaEmAndamento.finally(()=>{
if(uidEntradaEmAndamento===user.uid){
entradaEmAndamento=null;
uidEntradaEmAndamento=null;
}
});
}

async function fazerLogin(){
const nome=nomeLogin.value.trim();
const senha=senhaLogin.value;
if(!nomeValido(nome)){mensagemDeLogin("Use de 3 a 20 letras, números ou _.");return;}
if(!senha){mensagemDeLogin("Digite sua senha.");return;}
bloquearLogin(true);
operacaoManualDeConta=true;
mensagemDeLogin("ETAPA 1/2: conectando à conta...",false);
let avisoLogin=setTimeout(()=>{mensagemDeLogin("Ainda aguardando o Firebase. Se continuar assim, atualize a página e confira se publicou este arquivo novo.");},40000);
try{
await comTempoLimite(auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL),10000,"salvar a sessão neste aparelho");
const cred=await comTempoLimite(auth.signInWithEmailAndPassword(usuarioEmail(nome),senha),20000,"entrar na conta");
// O Firebase trata o e-mail sem diferenciar maiúsculas/minúsculas.
// Esta conferência adicional mantém o nome de usuário realmente exato.
// A validação do nome e a leitura dos dados são feitas juntas em entrarNoJogo.
// Isso evita duas viagens de rede seguidas ao Firestore em todo login.
mensagemDeLogin("Conta reconhecida! Abrindo seu jogo...",false);
const ok=await entrarNoJogo(cred.user,nome);
if(!ok&&auth.currentUser)await auth.signOut();
}catch(error){
console.error("Erro no login:",error);
mensagemDeLogin(textoErroLogin(error));
}finally{
clearTimeout(avisoLogin);
operacaoManualDeConta=false;
bloquearLogin(false);
}
}

async function criarConta(){
const nome=nomeLogin.value.trim();
const senha=senhaLogin.value;
if(!nomeValido(nome)){mensagemDeLogin("Use de 3 a 20 letras, números ou _.");return;}
if(senha.length<6){mensagemDeLogin("A senha precisa ter pelo menos 6 caracteres.");return;}
bloquearLogin(true);
operacaoManualDeConta=true;
mensagemDeLogin("Criando sua conta...",false);
let dadosIniciais={};
let legado=null;
try{legado=localStorage.getItem("mining_game_save");if(legado)dadosIniciais=JSON.parse(legado);}catch(e){dadosIniciais={};}
try{
await comTempoLimite(auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL),10000,"salvar a sessão neste aparelho");
const cred=await comTempoLimite(auth.createUserWithEmailAndPassword(usuarioEmail(nome),senha),20000,"criar a conta no Firebase");
await comTempoLimite(cred.user.updateProfile({displayName:nome}),15000,"salvar o nome da conta");
await comTempoLimite(db.collection("jogadores").doc(cred.user.uid).set({
nome,
dados:dadosIniciais,
criadoEm:firebase.firestore.FieldValue.serverTimestamp()
}),15000,"salvar os dados iniciais no Firestore");
if(legado){try{localStorage.removeItem("mining_game_save");}catch(e){}}
const entrou=await entrarNoJogo(cred.user,nome);
if(entrou)mensagemDeLogin("",false);
else mensagemDeLogin("Sua conta foi criada, mas não foi possível carregar os dados. Entre novamente ou verifique as regras do Firestore.");
}catch(error){
console.error("Erro ao criar conta:",error);
mensagemDeLogin(textoErroCriar(error));
}finally{
operacaoManualDeConta=false;
bloquearLogin(false);
}
}

botaoEntrar.addEventListener("click",fazerLogin);
botaoCriar.addEventListener("click",criarConta);
senhaLogin.addEventListener("keydown",e=>{if(e.key==="Enter")fazerLogin();});
mostrarContasSalvas();

function abrirTrocaSenha(){
if(!usuarioAtual){mostrarAviso("Entre em uma conta primeiro.","erro");return;}
senhaAtualInput.value="";
senhaNovaInput.value="";
senhaConfirmarInput.value="";
mensagemSenha.textContent="";
senhaModal.style.display="flex";
setTimeout(()=>senhaAtualInput.focus(),80);
}
function fecharTrocaSenha(){
senhaModal.style.display="none";
senhaAtualInput.value="";
senhaNovaInput.value="";
senhaConfirmarInput.value="";
}
async function atualizarSenhaDaConta(){
if(!usuarioAtual||!auth.currentUser){mensagemSenha.textContent="Nenhuma conta conectada.";return;}
const atual=senhaAtualInput.value;
const nova=senhaNovaInput.value;
const confirmar=senhaConfirmarInput.value;
if(!atual){mensagemSenha.textContent="Digite sua senha atual.";return;}
if(nova.length<6){mensagemSenha.textContent="A nova senha precisa ter pelo menos 6 caracteres.";return;}
if(nova!==confirmar){mensagemSenha.textContent="As novas senhas não coincidem.";return;}
if(nova===atual){mensagemSenha.textContent="Escolha uma senha diferente da atual.";return;}
botaoAtualizarSenha.disabled=true;
botaoAtualizarSenha.textContent="ATUALIZANDO...";
mensagemSenha.style.color="#bcd6ff";
mensagemSenha.textContent="Verificando sua senha atual...";
try{
const credencial=firebase.auth.EmailAuthProvider.credential(
auth.currentUser.email,atual
);
await comTempoLimite(auth.currentUser.reauthenticateWithCredential(credencial),20000,"confirmar a senha atual");
await comTempoLimite(auth.currentUser.updatePassword(nova),20000,"atualizar a senha");
mensagemSenha.style.color="#9dffb0";
mensagemSenha.textContent="Senha atualizada com sucesso!";
senhaAtualInput.value="";
senhaNovaInput.value="";
senhaConfirmarInput.value="";
setTimeout(fecharTrocaSenha,1200);
}catch(error){
console.error("Erro ao trocar senha:",error);
mensagemSenha.style.color="#ffb0b0";
if(error.code==="auth/wrong-password"||error.code==="auth/invalid-credential"){
mensagemSenha.textContent="A senha atual está incorreta.";
}else if(error.code==="auth/weak-password"){
mensagemSenha.textContent="A nova senha é fraca. Use pelo menos 6 caracteres.";
}else if(error.code==="auth/requires-recent-login"){
mensagemSenha.textContent="Por segurança, entre novamente na conta e tente trocar a senha.";
}else{
mensagemSenha.textContent="Não foi possível atualizar: "+(error.message||"erro desconhecido");
}
}finally{
botaoAtualizarSenha.disabled=false;
botaoAtualizarSenha.textContent="ATUALIZAR SENHA";
}
}
botaoAtualizarSenha.addEventListener("click",atualizarSenhaDaConta);
botaoCancelarSenha.addEventListener("click",fecharTrocaSenha);
senhaModal.addEventListener("pointerdown",e=>{if(e.target===senhaModal)fecharTrocaSenha();});
senhaConfirmarInput.addEventListener("keydown",e=>{if(e.key==="Enter")atualizarSenhaDaConta();});

async function sairDaConta(){
if(!usuarioAtual||saindoDaConta)return;
saindoDaConta=true;
let dadosSeguros=null;
try{
const usuarioId=usuarioAtual.uid;
if(timerSalvamentoNuvem){clearTimeout(timerSalvamentoNuvem);timerSalvamentoNuvem=null;}
if(cancelarMonitoramentoJogador){try{cancelarMonitoramentoJogador();}catch(e){}cancelarMonitoramentoJogador=null;}
if(dadosCarregados){
try{
dadosSeguros=limparDadosParaFirestore(dadosDoJogo());
await db.collection("jogadores").doc(usuarioId).set({
nome:usuarioAtual.displayName||usuarioAtual.email.split("@")[0],
dados:dadosSeguros,
ranking:{moedas:Number(dadosSeguros.moedas)||0,renascimentos:Number(dadosSeguros.renascimentos)||0},
atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()
},{merge:true});
}catch(error){mostrarAviso("Não foi possível salvar seu progresso: "+error.message);return;}
}
// Encerra também a sessão do Firebase. Antes, apenas escondíamos o jogo,
// deixando a conta anterior autenticada; isso podia fazer o Firebase
// reabrir a conta antiga automaticamente ao tentar trocar de usuário.
dadosCarregados=false;
try{if(dadosSeguros)await publicarResumoRanking(usuarioId,usuarioAtual.displayName||usuarioAtual.email.split("@")[0],dadosSeguros,false);}catch(e){}
pararPresenca(usuarioId);
try{
  await comTempoLimite(auth.signOut(),10000,"desconectar a conta atual");
}catch(erroSaida){
  mostrarAviso("Não foi possível desconectar a conta do Firebase. Verifique a conexão e tente novamente.","erro");
  dadosCarregados=true;
  return;
}
usuarioAtual=null;
codigoAdminSessao="";
adminDesbloqueado=false;
configuracoesAbertas=false;
lojaAberta=false;
melhoriasAbertas=false;
fecharAdmin();
carregandoDados=true;
aplicarDados({});
carregandoDados=false;
loginModal.style.display="flex";
nomeLogin.value="";
senhaLogin.value="";
mensagemDeLogin("Conta desconectada. As contas continuam salvas nesta lista. Para entrar novamente, selecione a conta e digite sua senha.",false);
}finally{
saindoDaConta=false;
}
}

async function iniciarSistemaLogin(){
try{
const user=auth.currentUser;
if(user){
const nome=user.displayName||user.email.split("@")[0]||"Jogador";
await entrarNoJogo(user,nome);
}
}catch(error){mensagemDeLogin("Erro de conexão com o Firebase. Atualize a página.");}
}
auth.onAuthStateChanged(async user=>{
if(user&&!usuarioAtual&&!operacaoManualDeConta){
const nome=user.displayName||user.email.split("@")[0]||"Jogador";
await entrarNoJogo(user,nome);
}
});

// Salva na nuvem na hora (aba escondida ou página fechando).
// Nunca salva antes do progresso carregar, para não apagar o save com valores zerados.
function salvarNuvemAgora(){
if(!jogoPronto()||carregandoDados||!usuarioAtual)return;
if(timerSalvamentoNuvem){clearTimeout(timerSalvamentoNuvem);timerSalvamentoNuvem=null;}
const id=usuarioAtual.uid;
const dados=limparDadosParaFirestore(dadosDoJogo());
// Guarda uma cópia local síncrona com inventário, pets equipados e preferências de venda.
dados._saveUpdatedAt=Date.now();
try{localStorage.setItem("mining_game_save_"+id,JSON.stringify(dados));}catch(error){console.warn("Não foi possível atualizar o salvamento local:",error);}
db.collection("jogadores").doc(id).set({
nome:usuarioAtual.displayName||usuarioAtual.email.split("@")[0],
dados,
ranking:{moedas:Number(moedas)||0,renascimentos:Number(renascimentos)||0},
atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()
},{merge:true}).then(()=>publicarResumoRanking(id,usuarioAtual&&usuarioAtual.uid===id?(usuarioAtual.displayName||usuarioAtual.email.split("@")[0]):"Jogador",dados,true)).catch(error=>console.error("Erro ao salvar:",error));
}

document.addEventListener("visibilitychange",()=>{
if(document.visibilityState==="hidden")salvarNuvemAgora();
});
window.addEventListener("pagehide",salvarNuvemAgora);

// DINHEIRO

function formatarDinheiro(valor){
const unidades=[
[1e33,"Dc"],[1e30,"No"],[1e27,"OC"],
[1e24,"Sp"],[1e21,"Sx"],[1e18,"Qi"],
[1e15,"Qa"],[1e12,"T"],[1e9,"B"],[1e6,"M"],[1e3,"K"]
];
for(const [limite,sufixo] of unidades){
if(valor>=limite)return(valor/limite).toFixed(1).replace(/\.0$/,"")+sufixo;
}
// Exibe até duas casas decimais para o valor ganho bater com o saldo recebido.
return Number(valor.toFixed(2)).toString();
}

function minerar(){
if(!jogoPronto())return;
const recompensaBase=picaretas[picaretaAtual][2]*minerios[minerioAtual][2];
const recompensa=recompensaBase*multiplicadorDinheiro()*multiplicadorEventoAtual()*multiplicadorMundo()*multiplicadorPets();

moedas+=recompensa;

somMinerar();

recompensaTexto="+"+formatarDinheiro(recompensa);
mostrarRecompensa=true;
tempoRecompensa=Date.now();

diagonal=true;
tempoGolpe=Date.now();

salvar();
}

// PAINEL DE ADMINISTRAÇÃO (HTML)

const adminModal=document.getElementById("adminModal");
const adminBox=document.getElementById("adminBox");
const admResumoJogador=document.getElementById("admResumoJogador");
const admValor=document.getElementById("admValor");
const admPicareta=document.getElementById("admPicareta");
const admMinerio=document.getElementById("admMinerio");
const admMult=document.getElementById("admMult");
const admJogador=document.getElementById("admJogador");
const admJogadorAbrir=document.getElementById("admJogadorAbrir");
const admJogadorSelecionado=document.getElementById("admJogadorSelecionado");
const admJogadorLista=document.getElementById("admJogadorLista");
const admCategoria=document.getElementById("admCategoria");
const admAcao=document.getElementById("admAcao");
const admRemotoValor=document.getElementById("admRemotoValor");
const admRemotoItem=document.getElementById("admRemotoItem");
const admCampoNivel=document.getElementById("admCampoNivel");
const admRemotoNivel=document.getElementById("admRemotoNivel");
const admDestinatario=document.getElementById("admDestinatario");
const admCampoValor=document.getElementById("admCampoValor");
const admCampoItem=document.getElementById("admCampoItem");
const admCampoDest=document.getElementById("admCampoDest");
const admCampoPet=document.getElementById("admCampoPet");
const admPetEscolhido=document.getElementById("admPetEscolhido");
const admPetMutacao=document.getElementById("admPetMutacao");
const admPetMutacoesEvento=document.getElementById("admPetMutacoesEvento");
if(admPetMutacoesEvento)admPetMutacoesEvento.querySelectorAll("input[type=checkbox]").forEach(ch=>{const atualizar=()=>ch.closest("label").classList.toggle("selecionada",ch.checked);ch.addEventListener("change",atualizar);atualizar();});
const admLogEl=document.getElementById("admLog");

const admHistorico=[];
let ultimaAtualizacaoAdmin=0;
let admExecutando=false;
let timerListaJogadoresAdmin=null;
let cancelarMonitoramentoJogadorAdmin=null;
let uidMonitoradoAdmin="";
let admCarregandoJogadores=false;

// Ações disponíveis para administrar outras contas pelo Firestore
const ACOES_REMOTAS={
addMoney:{rotulo:"Adicionar moedas",campo:"valor"},
removeMoney:{rotulo:"Remover quantidade de moedas",campo:"valor",perigo:true},
clearMoney:{rotulo:"Zerar todo o dinheiro",campo:"nenhum",perigo:true},
resetRebirths:{rotulo:"Zerar renascimentos",campo:"nenhum",perigo:true},
resetPickaxes:{rotulo:"Remover todas as picaretas (manter inicial)",campo:"nenhum",perigo:true},
resetOres:{rotulo:"Remover todos os minérios (manter inicial)",campo:"nenhum",perigo:true},
resetAll:{rotulo:"REDEFINIR TODO O PROGRESSO",campo:"nenhum",perigo:true},
givePickaxe:{rotulo:"Dar uma picareta",campo:"picareta"},
removePickaxe:{rotulo:"Remover uma picareta",campo:"picareta",perigo:true},
giveOre:{rotulo:"Dar um minério",campo:"minerio"},
removeOre:{rotulo:"Remover um minério",campo:"minerio",perigo:true},
giveWorld:{rotulo:"Desbloquear mundo para jogador",campo:"mundo"},
removeWorld:{rotulo:"Remover mundo de jogador",campo:"mundo",perigo:true},
giveAuto:{rotulo:"Liberar Auto Clicker",campo:"nenhum"},
removeAuto:{rotulo:"Remover Auto Clicker",campo:"nenhum",perigo:true},
givePro:{rotulo:"Liberar Auto Clicker Pro",campo:"nenhum"},
removePro:{rotulo:"Remover Auto Clicker Pro",campo:"nenhum",perigo:true},
setMultiplier:{rotulo:"Definir nível do multiplicador de dinheiro",campo:"nivel"},
setUpgradeLevel:{rotulo:"Definir nível de melhoria",campo:"melhoria",nivel:true},
givePet:{rotulo:"Dar pet para jogador",campo:"pet"},
viewInventory:{rotulo:"Ver inventário",campo:"inventario"}
};

// Categorias do gerenciamento remoto. As ações originais continuam disponíveis,
// apenas organizadas por tipo para facilitar o uso no painel.
const CATEGORIAS_ADMIN={
moedas:{rotulo:"Moedas",acoes:["addMoney","removeMoney","clearMoney"]},
picaretas:{rotulo:"Picaretas",acoes:["givePickaxe","removePickaxe","resetPickaxes"]},
minerios:{rotulo:"Minérios",acoes:["giveOre","removeOre","resetOres"]},
melhorias:{rotulo:"Melhorias",acoes:["giveAuto","removeAuto","givePro","removePro","setMultiplier","setUpgradeLevel"]},
renascimentos:{rotulo:"Renascimentos",acoes:["resetRebirths"]},
mundos:{rotulo:"Mundos",acoes:["giveWorld","removeWorld"]},
pets:{rotulo:"Pets",acoes:["givePet","viewInventory"]},
reset:{rotulo:"RESET",acoes:["resetAll"]}
};

function preencherAcoesCategoriaAdmin(){
const categoria=CATEGORIAS_ADMIN[admCategoria.value];
admAcao.textContent="";
if(!categoria)return;
for(const chave of categoria.acoes){
const def=ACOES_REMOTAS[chave];
if(!def)continue;
const opcao=document.createElement("option");
opcao.value=chave;
opcao.textContent=def.rotulo;
if(def.perigo||chave==="resetAll"){opcao.style.color="#ff5555";opcao.style.fontWeight="800";}
admAcao.appendChild(opcao);
}
admAcao.dispatchEvent(new Event("change",{bubbles:true}));
if(admAcao._renderSeletor)admAcao._renderSeletor();
}

function preencherLista(select,lista,inicio){
select.textContent="";
for(let i=inicio;i<lista.length;i++){
const opcao=document.createElement("option");
opcao.value=String(i);
opcao.textContent=i+" - "+lista[i][0];
select.appendChild(opcao);
}
}

function renderizarLogAdmin(){
admLogEl.textContent="";
for(const item of admHistorico.slice(0,10)){
const linha=document.createElement("div");
linha.className=item.tipo;
const hora=document.createElement("span");
hora.className="hora";
hora.textContent=item.hora;
linha.appendChild(hora);
linha.appendChild(document.createTextNode(item.texto));
admLogEl.appendChild(linha);
}
}

function admResultado(texto,tipo){
if(tipo==="ok"&&!String(texto).startsWith("O admin "))texto="O admin "+nomeDoAdminAtual()+": "+texto;
const hora=new Date().toLocaleTimeString("pt-BR",{hour12:false});
admHistorico.unshift({hora,texto,tipo});
if(admHistorico.length>40)admHistorico.pop();
renderizarLogAdmin();
mostrarAviso(texto,tipo);
}

function abrirResumoMundos(indices){
 const modal=document.getElementById("admMundosModal"),lista=document.getElementById("admMundosLista");
 if(!modal||!lista)return;
 const validos=[...new Set([0,...(Array.isArray(indices)?indices:[])].map(Number))].filter(i=>Number.isInteger(i)&&i>=0&&i<mundosJogo.length).sort((a,b)=>a-b);
 lista.textContent="";
 if(!validos.length){lista.textContent="Nenhum mundo liberado.";}
 validos.forEach(i=>{const linha=document.createElement("div");linha.className="adm-mundo-liberado";const nome=document.createElement("strong");nome.textContent="Mundo "+(i+1)+" — "+mundosJogo[i].nome;const status=document.createElement("small");status.textContent="LIBERADO";linha.append(nome,status);lista.appendChild(linha);});
 modal.style.display="flex";
}
function criarResumoAdmin(container,itens){
if(!container)return;
container.textContent="";
for(const [rotulo,valor,classe] of itens){
const chip=document.createElement("div");chip.className="adm-chip";
const r=document.createElement("span");r.textContent=rotulo;
if(classe==="mundos"){
 const b=document.createElement("button");b.type="button";b.className="adm-mundos-botao";
 const quantidade=Array.isArray(valor)?valor.length:0;
 b.textContent="Ver mundos liberados ("+quantidade+")  ⋯";
 b.addEventListener("click",()=>abrirResumoMundos(valor));
 chip.append(r,b);
}else{
 const v=document.createElement("strong");v.textContent=valor;if(classe)v.className=classe;
 chip.append(r,v);
}
container.appendChild(chip);
}
}
function estatisticasDadosAdmin(nome,dados,status){
const d=dados||{};
const pcs=Array.isArray(d.picaretasCompradas)?d.picaretasCompradas:[];
const mrs=Array.isArray(d.mineriosComprados)?d.mineriosComprados:[];
const pi=Math.max(0,Math.min(picaretas.length-1,Number(d.picaretaAtual)||0));
const mi=Math.max(0,Math.min(minerios.length-1,Number(d.minerioAtual)||0));
const ren=Math.max(0,Number(d.renascimentos)||0);
const nivel=Math.max(0,Number(d.multiplicadorCompras)||0);
const bonus=1+ren;
const melhoria=1+nivel;
return [
["Jogador",nome||"Jogador"],
["Status",status==="ONLINE"?"ON":(status==="OFFLINE"?"OFF":(status||"OFF")),status==="ONLINE"?"adm-presenca-online":"adm-presenca-offline"],
["Dinheiro","$ "+formatarDinheiro(Math.max(0,Number(d.moedas)||0))],
["Renascimentos",String(ren)],
["Bônus de renascimento",bonus.toFixed(1)+"x"],
["Nível da melhoria",String(nivel)],
["Melhoria de dinheiro",melhoria.toFixed(1)+"x"],
["Multiplicador final",(bonus*melhoria).toFixed(1)+"x"],
["Auto Clicker",d.autoClickerComprado?"Liberado":"Bloqueado"],
["Auto Clicker Pro",d.autoClickerProComprado?"Liberado":"Bloqueado"],
["Auto Ovo",d.autoOvoComprado?"Liberado":"Bloqueado"],
["Triplo Ovo",d.triploOvoComprado?"Liberado":"Bloqueado"],
["Sorte dos ovos",String(Math.max(0,Number(d.sorteOvoNivel)||0))],
["Impulso dos pets",String(Math.max(0,Number(d.impulsoPetsNivel)||0))],
["Espaço do inventário",String(Math.max(0,Number(d.melhoriaInventarioPets)||0))],
["Espaços para equipar pets",String(Math.max(0,Number(d.melhoriaPetsEquipados)||0))],
["Picareta atual",picaretas[pi][0]],
["Picaretas liberadas",pcs.length+"/"+picaretas.length],
["Minério atual",minerios[mi][0]],
["Minérios liberados",mrs.length+"/"+minerios.length],
["Mundo atual","Mundo "+(Math.max(0,Math.min(mundosJogo.length-1,Number(d.mundoAtual)||0))+1)+" — "+(mundosJogo[Math.max(0,Math.min(mundosJogo.length-1,Number(d.mundoAtual)||0))]?.nome||"Superfície")],
["Mundos desbloqueados",(Array.isArray(d.mundosDesbloqueados)?[...new Set([0,...d.mundosDesbloqueados.map(Number)])].filter(i=>Number.isInteger(i)&&i>=0&&i<mundosJogo.length).length:1)+"/"+mundosJogo.length],
["Mundos liberados",(Array.isArray(d.mundosDesbloqueados)?[...new Set([0,...d.mundosDesbloqueados.map(Number)])].filter(i=>Number.isInteger(i)&&i>=0&&i<mundosJogo.length).sort((a,b)=>a-b):[0]),"mundos"],
["Auto clicker",d.autoClickerProComprado?"Pro":(d.autoClickerComprado?"Normal":"Nenhum")]
];
}
function atualizarAdmin(){
ultimaAtualizacaoAdmin=Date.now();
if(!adminAberto)return;
// Os dados do jogador selecionado são atualizados pelo onSnapshot dedicado.
// Não reconstruir o painel a partir da lista antiga, para não sobrescrever valores recentes.
}

function pararMonitoramentoJogadorSelecionadoAdmin(){
if(cancelarMonitoramentoJogadorAdmin){
try{cancelarMonitoramentoJogadorAdmin();}catch(e){}
}
cancelarMonitoramentoJogadorAdmin=null;
uidMonitoradoAdmin="";
}

function iniciarMonitoramentoJogadorSelecionadoAdmin(uid){
if(!uid||!adminAberto||!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID)return;
if(uidMonitoradoAdmin===uid&&cancelarMonitoramentoJogadorAdmin)return;
pararMonitoramentoJogadorSelecionadoAdmin();
uidMonitoradoAdmin=uid;
const ref=db.collection("jogadores").doc(uid);
cancelarMonitoramentoJogadorAdmin=ref.onSnapshot(snapshot=>{
if(!adminAberto||admJogador.value!==uid||!snapshot.exists)return;
const registro=snapshot.data()||{};
const jogador=jogadoresAdmin.find(j=>j.uid===uid);
if(!jogador)return;
jogador.nome=String(registro.nome||jogador.nome||"Jogador");
jogador.dados=registro.dados&&typeof registro.dados==="object"?registro.dados:{};
jogador.online=jogadorEstaOnline(registro);
criarResumoAdmin(admResumoJogador,estatisticasDadosAdmin(jogador.nome,jogador.dados,jogador.online?"ONLINE":"OFFLINE"));
// Atualiza também a etiqueta e os dados usados pelo restante do painel sem recarregar a página.
atualizarSeletorVisualJogadores();
},error=>{
console.error("Erro ao acompanhar jogador selecionado em tempo real:",error);
});
}

function abrirAdmin(){
if(!adminDesbloqueado||!jogoPronto()||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID)return;
adminAberto=true;
adminModal.style.display="flex";
trocarAbaAdmin("outro");
atualizarAdmin();
carregarJogadoresAdmin();
if(timerListaJogadoresAdmin){clearInterval(timerListaJogadoresAdmin);timerListaJogadoresAdmin=null;}
if(admJogador.value)iniciarMonitoramentoJogadorSelecionadoAdmin(admJogador.value);
somAbrirLoja();
}

function fecharAdmin(){
adminAberto=false;
if(timerListaJogadoresAdmin){clearInterval(timerListaJogadoresAdmin);timerListaJogadoresAdmin=null;}
pararMonitoramentoJogadorSelecionadoAdmin();
adminModal.style.display="none";
 fecharInventarioRemoto();
}

function trocarAbaAdmin(aba){
if(aba==="eu")aba="outro";
const abaEu=document.getElementById("abaEu");if(abaEu)abaEu.hidden=true;
document.getElementById("abaOutro").hidden=aba!=="outro";
document.getElementById("abaEvento").hidden=aba!=="evento";
if(aba==="evento"){atualizarStatusEventoAdmin();atualizarStatusMutacoesAdmin();if(admEventoSorteStatus)admEventoSorteStatus.textContent=eventoSorteGlobal.ativo?"Evento de sorte ativo: "+eventoSorteGlobal.multiplicador+"x.":"Nenhum evento de sorte ativo.";}
if(aba==="outro")atualizarAdmin();
for(const botao of adminBox.querySelectorAll(".adm-abas button"))botao.classList.toggle("ativa",botao.dataset.aba===aba);
}

// Botão que pede um segundo clique para ações destrutivas
function confirmarClique(botao){
if(botao.dataset.aguardando==="1"){
clearTimeout(botao._timerConfirmar);
botao.dataset.aguardando="";
botao.textContent=botao.dataset.rotulo;
botao.classList.remove("aguardando");
return true;
}
botao.dataset.rotulo=botao.textContent;
botao.dataset.aguardando="1";
botao.textContent="Clique de novo para confirmar";
botao.classList.add("aguardando");
botao._timerConfirmar=setTimeout(()=>{
botao.dataset.aguardando="";
botao.textContent=botao.dataset.rotulo;
botao.classList.remove("aguardando");
},3500);
return false;
}

// MINHA CONTA

function lerValorAdmin(campo,permitirZero){
const v=lerNumero(campo.value);
if(!Number.isFinite(v)||v<0||(v===0&&!permitirZero)){
admResultado("Digite uma quantidade válida, como 5000, 2,5M ou 10K.","erro");
return null;
}
return Math.min(v,MAX_MOEDAS);
}

function admMoedas(modo){
if(modo==="zerar"){
moedas=0;
salvar();
somClique();
admResultado("Dinheiro zerado.","ok");
atualizarAdmin();
return;
}
const v=lerValorAdmin(admValor,modo==="definir");
if(v===null)return;
if(modo==="add"){
moedas=Math.min(MAX_MOEDAS,moedas+v);
somCompra();
admResultado("Adicionado $ "+formatarDinheiro(v)+".","ok");
}else if(modo==="remover"){
if(v>moedas){
admResultado("Você só tem $ "+formatarDinheiro(moedas)+".","erro");
return;
}
moedas-=v;
somClique();
admResultado("Removido $ "+formatarDinheiro(v)+".","ok");
}else{
moedas=v;
somClique();
admResultado("Dinheiro definido em $ "+formatarDinheiro(v)+".","ok");
}
salvar();
atualizarAdmin();
}

function admItens(tipo,modo){
const pick=tipo==="picareta";
const lista=pick?picaretas:minerios;
const indice=Number(pick?admPicareta.value:admMinerio.value);
let comprados=(pick?picaretasCompradas:mineriosComprados).slice();
let atual=pick?picaretaAtual:minerioAtual;
let msg="";

if(modo==="dar"){
if(!Number.isInteger(indice)||indice<0||indice>=lista.length)return;
if(!comprados.includes(indice))comprados.push(indice);
msg="Liberado: "+lista[indice][0]+".";
somRaro();
}else if(modo==="remover"){
if(!Number.isInteger(indice)||indice<=0||indice>=lista.length){
admResultado("Escolha um item da lista para remover.","erro");
return;
}
comprados=comprados.filter(i=>i!==indice);
if(atual===indice)atual=0;
msg="Removido: "+lista[indice][0]+".";
somClique();
}else if(modo==="todos"){
comprados=lista.map((item,i)=>i);
msg=pick?"Todas as picaretas liberadas.":"Todos os minérios liberados.";
somRaro();
}else{
comprados=[0];
atual=0;
msg=pick?"Picaretas resetadas (ficou só a inicial).":"Minérios resetados (ficou só o inicial).";
somClique();
}

comprados.sort((a,b)=>a-b);
if(pick){
picaretasCompradas=comprados;
picaretaAtual=atual;
}else{
mineriosComprados=comprados;
minerioAtual=atual;
}
salvar();
admResultado(msg,"ok");
atualizarAdmin();
}

function admMelhoria(qual,ligar){
if(qual==="auto"){
autoClickerComprado=ligar;
if(!ligar)autoClickerAtivo=false;
}else{
autoClickerProComprado=ligar;
if(!ligar)autoClickerProAtivo=false;
}
salvar();
somClique();
admResultado((qual==="auto"?"Auto clicker ":"Auto clicker Pro ")+(ligar?"liberado.":"removido."),"ok");
atualizarAdmin();
}

function admMultiplicador(){
const n=lerNumero(admMult.value);
if(!Number.isInteger(n)||n<0||n>500){
admResultado("Digite um nível inteiro de 0 a 500.","erro");
return;
}
multiplicadorCompras=n;
precoMultiplicador=100*Math.pow(3,n);
salvar();
somClique();
admResultado("Melhoria de dinheiro no nível "+n+" ("+multiplicadorMelhoria().toFixed(1)+"x). Bônus de renascimento: "+multiplicadorRenascimento().toFixed(1)+"x.","ok");
atualizarAdmin();
}

// OUTRO JOGADOR (Firestore, autorizado pelas regras do projeto)
let jogadoresAdmin=[];

function fecharListaJogadoresAdmin(){
admJogadorLista.hidden=true;
admJogadorAbrir.setAttribute("aria-expanded","false");
}
function atualizarSeletorVisualJogadores(){
const atual=jogadoresAdmin.find(j=>j.uid===admJogador.value);
admJogadorSelecionado.textContent="";
if(atual){
 admJogadorSelecionado.appendChild(document.createTextNode(atual.nome+(atual.uid===ADMIN_UID?" (sua conta)":"")+" "));
 admJogadorSelecionado.appendChild(criarEtiquetaPresenca(atual.online));
 criarResumoAdmin(admResumoJogador,estatisticasDadosAdmin(atual.nome,atual.dados,atual.online?"ONLINE":"OFFLINE"));
}else{
 admJogadorSelecionado.textContent=admJogador.options.length?"Selecione um jogador":"Nenhum jogador carregado";
}
admJogadorLista.textContent="";
if(!jogadoresAdmin.length){
const vazio=document.createElement("div");vazio.className="adm-seletor-vazio";vazio.textContent="Nenhum jogador encontrado";admJogadorLista.appendChild(vazio);return;
}
for(const jogador of jogadoresAdmin){
const opcao=document.createElement("button");
opcao.type="button";opcao.className="adm-seletor-opcao"+(jogador.uid===admJogador.value?" selecionada":"");
opcao.setAttribute("role","option");opcao.setAttribute("aria-selected",jogador.uid===admJogador.value?"true":"false");
opcao.dataset.uid=jogador.uid;
opcao.appendChild(document.createTextNode(jogador.nome+(jogador.uid===ADMIN_UID?" (sua conta)":"")+" "));
opcao.appendChild(criarEtiquetaPresenca(jogador.online));
admJogadorLista.appendChild(opcao);
}
}
admJogadorAbrir.addEventListener("click",()=>{
if(admJogador.disabled)return;
const abrir=admJogadorLista.hidden;
admJogadorLista.hidden=!abrir;
admJogadorAbrir.setAttribute("aria-expanded",abrir?"true":"false");
if(abrir){const selecionado=admJogadorLista.querySelector(".selecionada");if(selecionado)selecionado.scrollIntoView({block:"nearest"});}
});
admJogadorLista.addEventListener("click",evento=>{
const opcao=evento.target.closest("button[data-uid]");if(!opcao)return;
admJogador.value=opcao.dataset.uid;
admJogador.dispatchEvent(new Event("change",{bubbles:true}));
atualizarSeletorVisualJogadores();
fecharListaJogadoresAdmin();
});
document.addEventListener("click",evento=>{
if(!evento.target.closest(".adm-seletor-wrap"))fecharListaJogadoresAdmin();
});
admJogador.addEventListener("change",()=>{
atualizarSeletorVisualJogadores();
iniciarMonitoramentoJogadorSelecionadoAdmin(admJogador.value);
});

async function carregarJogadoresAdmin(silencioso){
if(admCarregandoJogadores)return;
if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID)return;
admCarregandoJogadores=true;
const select=admJogador;
const valorAnterior=select.value;
select.disabled=true;
admJogadorAbrir.disabled=true;
admJogadorSelecionado.textContent="Carregando jogadores...";
fecharListaJogadoresAdmin();
select.textContent="";
const carregando=document.createElement("option");
carregando.value="";carregando.textContent="Carregando jogadores...";
select.appendChild(carregando);
try{
// Presença é independente da listagem: nunca espere a gravação de heartbeat
// para buscar os jogadores. Uma falha nas gravações de ON/OFF não pode travar
// o seletor administrativo.
atualizarPresenca(true,usuarioAtual.uid).catch(error=>console.warn("Falha ao atualizar presença antes da lista:",error));
const snapshot=await comTempoLimite(db.collection("jogadores").get(),15000,"listar jogadores");
jogadoresAdmin=snapshot.docs.map(doc=>{
const registro=doc.data()||{};
const online=jogadorEstaOnline(registro);
return {uid:doc.id,nome:String(registro.nome||"Jogador"),dados:registro.dados||{},online};
}).sort((a,b)=>a.nome.localeCompare(b.nome,"pt-BR"));
select.textContent="";
for(const jogador of jogadoresAdmin){
const op=document.createElement("option");
op.value=jogador.uid;
op.textContent=jogador.nome+(jogador.uid===ADMIN_UID?" (sua conta)":"")+" • "+(jogador.online?"🟢 ON":"🔴 OFF");
select.appendChild(op);
}
if(!jogadoresAdmin.length){const op=document.createElement("option");op.value="";op.textContent="Nenhum jogador encontrado";select.appendChild(op);}
if(jogadoresAdmin.some(j=>j.uid===valorAnterior))select.value=valorAnterior;
else if(jogadoresAdmin.length)select.selectedIndex=0;
atualizarSeletorVisualJogadores();
if(admJogador.value)iniciarMonitoramentoJogadorSelecionadoAdmin(admJogador.value);
if(!silencioso)admResultado("Lista carregada: "+jogadoresAdmin.length+" conta(s).","ok");
}catch(error){
console.error("Erro ao listar jogadores:",error);
select.textContent="";
const op=document.createElement("option");op.value="";op.textContent="Erro ao carregar jogadores";select.appendChild(op);
atualizarSeletorVisualJogadores();
if(!silencioso)admResultado("Não foi possível listar jogadores. Confira as regras do Firestore: "+(error.message||"erro"),"erro");
}finally{select.disabled=false;admJogadorAbrir.disabled=false;admCarregandoJogadores=false;}
}

let adminInventarioUid=null;
let adminInventarioNome="";
let adminInventarioPets=[];
let adminInventarioEquipados=[];
let adminPetsSelecao=new Set();
let adminModoSelecaoMultipla=false;

function fecharInventarioRemoto(){
 const modal=document.getElementById("adminInventarioModal");if(modal)modal.style.display="none";
 adminInventarioUid=null;adminPetsSelecao.clear();adminModoSelecaoMultipla=false;
}

async function abrirInventarioRemoto(uid,nome){
 if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID){admResultado("Acesso administrativo não autorizado.","erro");return;}
 const modal=document.getElementById("adminInventarioModal"),lista=document.getElementById("adminInventarioLista");
 adminInventarioUid=uid;adminInventarioNome=nome||"Jogador";adminPetsSelecao.clear();adminModoSelecaoMultipla=false;
 document.getElementById("adminInventarioTitulo").textContent="PETS DE "+adminInventarioNome;
 document.getElementById("adminInventarioDescricao").textContent="Carregando inventário e pets equipados...";
 document.getElementById("adminSelecionarMultiplos").textContent="SELECIONAR MÚLTIPLOS";
 lista.innerHTML="<div class='novo-vazio'>Carregando pets...</div>";
 modal.style.display="flex";
 try{
  const snap=await comTempoLimite(db.collection("jogadores").doc(uid).get(),15000,"carregar inventário do jogador");
  if(!snap.exists)throw new Error("Jogador não encontrado.");
  const dados=snap.data()?.dados||{};
  adminInventarioPets=Array.isArray(dados.petsInventario)?dados.petsInventario.filter(p=>p&&typeof p.id==="string"):[];
  adminInventarioEquipados=Array.isArray(dados.petsEquipados)?dados.petsEquipados.slice():[];
  renderizarInventarioRemoto();
 }catch(e){console.error("Erro ao abrir inventário remoto:",e);lista.innerHTML="<div class='novo-vazio'>Não foi possível carregar o inventário: "+String(e.message||e)+"</div>";}
}

function renderizarInventarioRemoto(){
 const lista=document.getElementById("adminInventarioLista"),botao=document.getElementById("adminExcluirPetsSelecionados");
 lista.innerHTML="";
 document.getElementById("adminInventarioDescricao").textContent=adminInventarioPets.length+" pet(s) no inventário • "+adminInventarioEquipados.length+" equipado(s).";
 if(!adminInventarioPets.length){lista.className="pet-grade admin-inventario-grade novo-vazio";lista.textContent="Este jogador não possui pets.";botao.disabled=true;botao.textContent="EXCLUIR SELECIONADOS (0)";return;}
 lista.className="pet-grade admin-inventario-grade";
 adminInventarioPets.forEach(p=>{
  const equipado=adminInventarioEquipados.includes(p.id),marcado=adminPetsSelecao.has(p.id);
  const card=document.createElement("button");card.type="button";card.className="pet-slot admin-pet-remoto"+(equipado?" equipado":"")+(marcado?" marcado":"");
  card.style.borderColor=equipado?"#35e879":(p.void?"#b58aff":p.rainbow?"#ff75e8":p.diamante?"#55dfff":p.dourado?"#f4cf55":(p.cor||"#66758b"));
  const iniciais=document.createElement("span");iniciais.className="pet-iniciais";iniciais.textContent=String(p.sigla||p.nome||"PET").slice(0,4);
  const nome=document.createElement("strong");nome.textContent=String(p.nome||"Pet");
  const rar=document.createElement("small");const mut=p.void?"Void":p.rainbow?"Rainbow":p.diamante?"Diamante":p.dourado?"Dourado":"Normal";rar.textContent=String(p.raridade||"")+" • "+mut;
  card.append(iniciais,nome,rar);
  if(equipado){const eq=document.createElement("small");eq.className="admin-pet-equipado";eq.textContent="EQUIPADO";card.appendChild(eq);}
  if(marcado){const x=document.createElement("span");x.className="admin-pet-x";x.textContent="×";card.appendChild(x);}
  card.addEventListener("click",()=>{
   if(adminModoSelecaoMultipla){if(adminPetsSelecao.has(p.id))adminPetsSelecao.delete(p.id);else adminPetsSelecao.add(p.id);}
   else{adminPetsSelecao.clear();adminPetsSelecao.add(p.id);}
   renderizarInventarioRemoto();
  });
  lista.appendChild(card);
 });
 botao.disabled=adminPetsSelecao.size===0;botao.textContent="EXCLUIR SELECIONADOS ("+adminPetsSelecao.size+")";
}

async function excluirPetsRemotosSelecionados(){
 if(!adminInventarioUid||!adminPetsSelecao.size)return;
 const ids=[...adminPetsSelecao];
 if(!confirm("Tem certeza que deseja excluir "+ids.length+" pet(s) deste jogador? Esta ação não pode ser desfeita."))return;
 const botao=document.getElementById("adminExcluirPetsSelecionados");botao.disabled=true;botao.textContent="EXCLUINDO...";
 try{
  const ref=db.collection("jogadores").doc(adminInventarioUid);
  let dadosAtualizados=null;
  await db.runTransaction(async tx=>{
   const snap=await tx.get(ref);if(!snap.exists)throw new Error("Jogador não encontrado.");
   const registro=snap.data()||{},dados=Object.assign({},dadosOriginais);
   const inventario=Array.isArray(dados.petsInventario)?dados.petsInventario:[];
   const idsValidos=new Set(ids);
   dados.petsInventario=inventario.filter(p=>!p||!idsValidos.has(p.id));
   dados.petsEquipados=(Array.isArray(dados.petsEquipados)?dados.petsEquipados:[]).filter(id=>!idsValidos.has(id));
   dadosAtualizados=dados;
   tx.set(ref,{dados,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
  });
  adminInventarioPets=Array.isArray(dadosAtualizados.petsInventario)?dadosAtualizados.petsInventario:[];
  adminInventarioEquipados=Array.isArray(dadosAtualizados.petsEquipados)?dadosAtualizados.petsEquipados:[];
  adminPetsSelecao.clear();renderizarInventarioRemoto();
  const jogador=jogadoresAdmin.find(j=>j.uid===adminInventarioUid);if(jogador)jogador.dados=dadosAtualizados;
  if(usuarioAtual&&adminInventarioUid===usuarioAtual.uid)aplicarDadosDoServidor(dadosAtualizados);
  admResultado(ids.length+" pet(s) excluído(s) do inventário de "+adminInventarioNome+".","ok");
 }catch(e){console.error("Erro ao excluir pets remotos:",e);admResultado("Não foi possível excluir os pets: "+(e.message||"erro no Firebase"),"erro");}
 finally{botao.disabled=adminPetsSelecao.size===0;botao.textContent="EXCLUIR SELECIONADOS ("+adminPetsSelecao.size+")";}
}

document.getElementById("fecharAdminInventario").addEventListener("click",fecharInventarioRemoto);
document.getElementById("adminInventarioModal").addEventListener("click",e=>{if(e.target.id==="adminInventarioModal")fecharInventarioRemoto();});
document.getElementById("adminSelecionarMultiplos").addEventListener("click",()=>{adminModoSelecaoMultipla=!adminModoSelecaoMultipla;adminPetsSelecao.clear();document.getElementById("adminSelecionarMultiplos").textContent=adminModoSelecaoMultipla?"MODO MÚLTIPLO ATIVO":"SELECIONAR MÚLTIPLOS";renderizarInventarioRemoto();});
document.getElementById("adminLimparSelecaoPets").addEventListener("click",()=>{adminPetsSelecao.clear();renderizarInventarioRemoto();});
document.getElementById("adminExcluirPetsSelecionados").addEventListener("click",excluirPetsRemotosSelecionados);

function atualizarCamposRemotos(){
const def=ACOES_REMOTAS[admAcao.value];
if(!def)return;
admCampoValor.hidden=def.campo!=="valor";
admCampoItem.hidden=!(def.campo==="picareta"||def.campo==="minerio"||def.campo==="mundo"||def.campo==="melhoria");
admCampoNivel.hidden=!(def.campo==="nivel"||def.campo==="melhoria");
if(def.campo==="melhoria"){const opcoes=[ ["multiplicadorCompras","Multiplicador de dinheiro (0–500)"],["autoClickerComprado","Auto Clicker (0–1)"],["autoClickerProComprado","Auto Clicker Pro (0–1)"],["autoOvoComprado","Auto Ovo (0–1)"],["triploOvoComprado","Triplo Ovo (0–1)"],["sorteOvoNivel","Sorte dos ovos (0–20)"],["impulsoPetsNivel","Impulso dos pets (0–20)"],["melhoriaInventarioPets","Espaço do inventário de pets (0–6)"],["melhoriaPetsEquipados","Espaços para equipar pets (0–3)"]];admRemotoItem.textContent="";for(const [v,t] of opcoes){const o=document.createElement("option");o.value=v;o.textContent=t;admRemotoItem.appendChild(o);}document.getElementById("admRemotoNivel").placeholder="Nível conforme o limite da melhoria";}
admCampoDest.hidden=true;
admCampoPet.hidden=def.campo!=="pet";
const botaoExecutar=document.getElementById("admExecutar");if(botaoExecutar)botaoExecutar.textContent=def.campo==="inventario"?"VER INVENTÁRIO":"Executar";
if(def.campo==="picareta")preencherLista(admRemotoItem,picaretas,0);
else if(def.campo==="minerio")preencherLista(admRemotoItem,minerios,0);
else if(def.campo==="melhoria"){ /* opções preenchidas acima */ }
else if(def.campo==="mundo"){
 admRemotoItem.textContent="";
 mundosJogo.forEach((m,i)=>{if(i===0)return;const op=document.createElement("option");op.value=String(i);op.textContent="Mundo "+(i+1)+" — "+m.nome;admRemotoItem.appendChild(op);});
}
else if(def.campo==="pet"){
 admPetEscolhido.textContent="";
 catalogoPets.forEach((pet,i)=>{const op=document.createElement("option");op.value=String(i);op.textContent=pet.nome+" — "+pet.raridade;admPetEscolhido.appendChild(op);});
}
}

async function admExecutarRemoto(botao){
if(admExecutando)return;
if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID){admResultado("Acesso administrativo não autorizado.","erro");return;}
const uid=admJogador.value;
const jogador=jogadoresAdmin.find(j=>j.uid===uid);
if(!jogador){admResultado("Selecione um jogador da lista.","erro");return;}
const acao=admAcao.value;
const def=ACOES_REMOTAS[acao];
if(!def){admResultado("Escolha uma ação válida.","erro");return;}
if(acao==="viewInventory"){abrirInventarioRemoto(uid,jogador.nome);return;}
let valor=0;
if(def.campo==="valor"){
valor=lerNumero(admRemotoValor.value);
if(!Number.isFinite(valor)||valor<=0){admResultado("Digite uma quantidade válida, como 5000, 2,5M ou 10K.","erro");return;}
valor=Math.min(valor,MAX_MOEDAS);
}else if(def.campo==="picareta"||def.campo==="minerio"||def.campo==="mundo"){
valor=Number(admRemotoItem.value);
const total=def.campo==="picareta"?picaretas.length:(def.campo==="minerio"?minerios.length:mundosJogo.length);
if(!Number.isInteger(valor)||valor<0||valor>=total||(def.campo==="mundo"&&valor===0)){admResultado("Escolha um item válido da lista.","erro");return;}
}else if(def.campo==="pet"){
valor=Number(admPetEscolhido.value);
if(!Number.isInteger(valor)||!catalogoPets[valor]){admResultado("Escolha um pet válido.","erro");return;}
}else if(def.campo==="nivel"||def.campo==="melhoria"){
valor=Number(admRemotoNivel.value);
const limites=def.campo==="melhoria"?({multiplicadorCompras:500,autoClickerComprado:1,autoClickerProComprado:1,autoOvoComprado:1,triploOvoComprado:1,sorteOvoNivel:20,impulsoPetsNivel:20,melhoriaInventarioPets:6,melhoriaPetsEquipados:3}):null;
const maximo=def.campo==="melhoria"?(limites[admRemotoItem.value]??-1):500;
if(!Number.isInteger(valor)||valor<0||valor>maximo){admResultado("Digite um nível inteiro entre 0 e "+maximo+" para essa melhoria.","erro");return;}
}
if(def.perigo&&!confirmarClique(botao))return;
admExecutando=true;
const comandoNaPropriaConta=uid===usuarioAtual.uid;
if(comandoNaPropriaConta){bloqueandoSalvamentoAdmin=true;if(timerSalvamentoNuvem){clearTimeout(timerSalvamentoNuvem);timerSalvamentoNuvem=null;}}
botao.disabled=true;botao.textContent="Salvando...";
try{
const ref=db.collection("jogadores").doc(uid);
const snap=await comTempoLimite(ref.get(),15000,"consultar jogador selecionado");
if(!snap.exists)throw new Error("Essa conta não existe mais.");
const registro=snap.data()||{};
const dadosOriginais=registro.dados&&typeof registro.dados==="object"?JSON.parse(JSON.stringify(registro.dados)):{};
const dados=Object.assign({
moedas:0,renascimentos:0,picaretasCompradas:[0],mineriosComprados:[0],picaretaAtual:0,minerioAtual:0,
volumeGeral:1,codigosUsados:[],multiplicadorCompras:0,precoMultiplicador:100,
mundoAtual:0,mundosDesbloqueados:[0],
autoClickerComprado:false,autoClickerProComprado:false,autoClickerAtivo:false,autoClickerProAtivo:false,petsInventario:[],petsEquipados:[]
},registro.dados||{});
dados.moedas=Math.max(0,Number(dados.moedas)||0);
dados.picaretasCompradas=Array.isArray(dados.picaretasCompradas)?dados.picaretasCompradas.map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<picaretas.length):[0];
dados.mineriosComprados=Array.isArray(dados.mineriosComprados)?dados.mineriosComprados.map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<minerios.length):[0];
dados.picaretasCompradas=[...new Set(dados.picaretasCompradas)];
dados.mineriosComprados=[...new Set(dados.mineriosComprados)];
dados.mundosDesbloqueados=Array.isArray(dados.mundosDesbloqueados)?dados.mundosDesbloqueados.map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<mundosJogo.length):[0];
dados.mundosDesbloqueados=[...new Set([0,...dados.mundosDesbloqueados])];
dados.mundoAtual=Math.max(0,Math.min(mundosJogo.length-1,Math.floor(Number(dados.mundoAtual)||0)));
if(!dados.mundosDesbloqueados.includes(dados.mundoAtual))dados.mundoAtual=0;
if(!dados.picaretasCompradas.includes(0))dados.picaretasCompradas.push(0);
if(!dados.mineriosComprados.includes(0))dados.mineriosComprados.push(0);
dados.picaretaAtual=Number(dados.picaretaAtual)||0;
dados.minerioAtual=Number(dados.minerioAtual)||0;
if(!dados.picaretasCompradas.includes(dados.picaretaAtual))dados.picaretaAtual=0;
if(!dados.mineriosComprados.includes(dados.minerioAtual))dados.minerioAtual=0;
if(acao==="addMoney")dados.moedas=Math.min(MAX_MOEDAS,Math.max(0,Number(dados.moedas)||0)+valor);
if(acao==="removeMoney")dados.moedas=Math.max(0,(Number(dados.moedas)||0)-valor);
if(acao==="clearMoney")dados.moedas=0;
if(acao==="resetRebirths")dados.renascimentos=0;
if(acao==="resetPickaxes"){dados.picaretasCompradas=[0];dados.picaretaAtual=0;}
if(acao==="resetOres"){dados.mineriosComprados=[0];dados.minerioAtual=0;}
if(acao==="resetAll"){
 dados.moedas=0;dados.renascimentos=0;
 dados.picaretasCompradas=[0];dados.picaretaAtual=0;
 dados.mineriosComprados=[0];dados.minerioAtual=0;
 dados.multiplicadorCompras=0;dados.precoMultiplicador=100;
 dados.autoClickerComprado=false;dados.autoClickerProComprado=false;
 dados.autoClickerAtivo=false;dados.autoClickerProAtivo=false;
 dados.autoOvoComprado=false;dados.autoOvoAtivo=false;dados.triploOvoComprado=false;
 dados.sorteOvoNivel=0;dados.precoSorteOvo=200;dados.impulsoPetsNivel=0;dados.precoImpulsoPets=500000;dados.petsVendaAutomatica=[];
 dados.mundoAtual=0;dados.mundosDesbloqueados=[0];
 dados.petsInventario=[];dados.petsEquipados=[];dados.melhoriaInventarioPets=0;dados.melhoriaPetsEquipados=0;dados.ovosAbertos=0;
 dados.codigosUsados=[];
}
if(acao==="givePickaxe"){
dados.picaretasCompradas=Array.isArray(dados.picaretasCompradas)?dados.picaretasCompradas:[0];
if(!dados.picaretasCompradas.includes(valor))dados.picaretasCompradas.push(valor);
dados.picaretasCompradas.sort((a,b)=>a-b);
}
if(acao==="removePickaxe"){
if(valor===0)throw new Error("A picareta inicial não pode ser removida.");
dados.picaretasCompradas=(Array.isArray(dados.picaretasCompradas)?dados.picaretasCompradas:[0]).filter(i=>i!==valor);
if(dados.picaretaAtual===valor)dados.picaretaAtual=0;
}
if(acao==="giveOre"){
dados.mineriosComprados=Array.isArray(dados.mineriosComprados)?dados.mineriosComprados:[0];
if(!dados.mineriosComprados.includes(valor))dados.mineriosComprados.push(valor);
dados.mineriosComprados.sort((a,b)=>a-b);
}
if(acao==="removeOre"){
if(valor===0)throw new Error("O minério inicial não pode ser removido.");
dados.mineriosComprados=dados.mineriosComprados.filter(i=>i!==valor);
if(dados.minerioAtual===valor)dados.minerioAtual=0;
}
if(acao==="giveWorld"||acao==="removeWorld"){
 dados.mundosDesbloqueados=Array.isArray(dados.mundosDesbloqueados)?dados.mundosDesbloqueados.map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<mundosJogo.length):[0];
 dados.mundosDesbloqueados=[...new Set([0,...dados.mundosDesbloqueados])];
 if(acao==="giveWorld"&&!dados.mundosDesbloqueados.includes(valor))dados.mundosDesbloqueados.push(valor);
 if(acao==="removeWorld"){
  if(valor===0)throw new Error("O mundo inicial não pode ser removido.");
  dados.mundosDesbloqueados=dados.mundosDesbloqueados.filter(i=>i!==valor);
  if(Number(dados.mundoAtual)===valor)dados.mundoAtual=0;
 }
}
// Concede ou remove os auto clickers na conta escolhida.
if(acao==="giveAuto"){
// Libera e ativa imediatamente o Auto Clicker normal no jogador online.
dados.autoClickerComprado=true;
dados.autoClickerAtivo=true;
dados.autoClickerProAtivo=false;
}
if(acao==="removeAuto"){
dados.autoClickerComprado=false;
dados.autoClickerAtivo=false;
}
if(acao==="givePro"){
// Libera e ativa imediatamente o Auto Clicker Pro no jogador online.
dados.autoClickerProComprado=true;
dados.autoClickerProAtivo=true;
dados.autoClickerAtivo=false;
}
if(acao==="removePro"){
dados.autoClickerProComprado=false;
dados.autoClickerProAtivo=false;
}
// Define a melhoria de multiplicador do jogador remoto sem apagar os renascimentos.
if(acao==="setMultiplier"){
dados.multiplicadorCompras=valor;
dados.precoMultiplicador=100*Math.pow(3,valor);
}
if(acao==="setUpgradeLevel"){
 const chave=String(admRemotoItem.value);
 const permitido={multiplicadorCompras:500,autoClickerComprado:1,autoClickerProComprado:1,autoOvoComprado:1,triploOvoComprado:1,sorteOvoNivel:20,impulsoPetsNivel:20,melhoriaInventarioPets:6,melhoriaPetsEquipados:3};
 if(!Object.prototype.hasOwnProperty.call(permitido,chave)||valor>permitido[chave])throw new Error("Melhoria ou nível inválido.");
 if(chave==="multiplicadorCompras"){dados.multiplicadorCompras=valor;dados.precoMultiplicador=100*Math.pow(3,valor);}
 else if(chave==="autoClickerComprado"){dados.autoClickerComprado=valor===1;dados.autoClickerAtivo=valor===1;if(valor===1)dados.autoClickerProAtivo=false;}
 else if(chave==="autoClickerProComprado"){dados.autoClickerProComprado=valor===1;dados.autoClickerProAtivo=valor===1;if(valor===1)dados.autoClickerAtivo=false;}
 else if(chave==="autoOvoComprado"){dados.autoOvoComprado=valor===1;dados.autoOvoAtivo=valor===1;}
 else if(chave==="triploOvoComprado")dados.triploOvoComprado=valor===1;
 else if(chave==="sorteOvoNivel"){dados.sorteOvoNivel=valor;dados.precoSorteOvo=200*Math.pow(3,valor);}
 else if(chave==="impulsoPetsNivel"){dados.impulsoPetsNivel=valor;dados.precoImpulsoPets=500000*Math.pow(2,valor);}
 else if(chave==="melhoriaInventarioPets")dados.melhoriaInventarioPets=valor;
 else if(chave==="melhoriaPetsEquipados")dados.melhoriaPetsEquipados=valor;
}
if(acao==="givePet"){
 const base=catalogoPets[valor];
 const mutacao=Math.max(0,Math.min(4,Number(admPetMutacao.value)||0));
 const mutacoesEvento=[...new Set(Array.from(admPetMutacoesEvento.querySelectorAll("input[type=checkbox]:checked")).map(el=>el.value).filter(k=>["anjo","hacker","galaxia"].includes(k)))];
 const inventario=Array.isArray(dados.petsInventario)?dados.petsInventario.slice():[];
 if(inventario.length>=50)throw new Error("O inventário do jogador está cheio (50 pets).");
 const pet={id:"pet_admin_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,9),nome:base.nome,sigla:base.sigla,raridade:base.raridade,peso:base.peso,mult:multiplicadorNivelPet(base,mutacao)*multiplicadorBonusMutacoes(mutacoesEvento),cor:base.cor,borda:base.borda||"",dourado:mutacao>=1,diamante:mutacao>=2,rainbow:mutacao>=3,void:mutacao>=4,mutacoesEvento};
 inventario.push(pet);dados.petsInventario=inventario;
 dados.petsEquipados=Array.isArray(dados.petsEquipados)?dados.petsEquipados:[];
}
// Impede que os dois auto clickers fiquem ativos ao mesmo tempo.
if(dados.autoClickerAtivo&&dados.autoClickerProAtivo)dados.autoClickerAtivo=false;
dados.picaretasCompradas.sort((a,b)=>a-b);
dados.mineriosComprados.sort((a,b)=>a-b);
const nome=String(registro.nome||jogador.nome);
const itemNome=def.campo==="picareta"?picaretas[valor][0]:def.campo==="minerio"?minerios[valor][0]:def.campo==="melhoria"?admRemotoItem.options[admRemotoItem.selectedIndex].text:def.campo==="pet"?(catalogoPets[valor].nome+" ("+["Normal","Gold","Diamante","Rainbow","Void"][Number(admPetMutacao.value)||0]+(admPetMutacoesEvento.querySelectorAll("input[type=checkbox]:checked").length?" + "+Array.from(admPetMutacoesEvento.querySelectorAll("input[type=checkbox]:checked")).map(el=>nomesMutacaoEvento[el.value]).join(" + "):"")+")"):def.campo==="nivel"?(valor+" ("+(Math.pow(2,Number(dados.renascimentos)||0)*(1+valor)).toFixed(1)+"x)"):def.campo==="mundo"?("Mundo "+(valor+1)+" — "+mundosJogo[valor].nome):"";
let textoAviso="O admin "+nomeDoAdminAtual()+" alterou sua conta: "+def.rotulo.toLowerCase();
if(acao==="addMoney")textoAviso="O admin "+nomeDoAdminAtual()+" te deu $"+formatarDinheiro(valor)+".";
else if(acao==="removeMoney")textoAviso="O admin "+nomeDoAdminAtual()+" removeu $"+formatarDinheiro(valor)+" da sua conta.";
else if(acao==="clearMoney")textoAviso="O admin "+nomeDoAdminAtual()+" zerou todo o seu dinheiro.";
else if(acao==="resetRebirths")textoAviso="O admin "+nomeDoAdminAtual()+" zerou seus renascimentos.";
else if(acao==="resetPickaxes")textoAviso="O admin "+nomeDoAdminAtual()+" removeu todas as suas picaretas, exceto a inicial.";
else if(acao==="resetOres")textoAviso="O admin "+nomeDoAdminAtual()+" removeu todos os seus minérios, exceto o inicial.";
else if(acao==="resetAll")textoAviso="O admin "+nomeDoAdminAtual()+" redefiniu todo o seu progresso. Sua conta foi mantida.";
else if(acao==="givePickaxe")textoAviso="O admin "+nomeDoAdminAtual()+" te deu a picareta "+itemNome+".";
else if(acao==="removePickaxe")textoAviso="O admin "+nomeDoAdminAtual()+" removeu a picareta "+itemNome+" da sua conta.";
else if(acao==="giveOre")textoAviso="O admin "+nomeDoAdminAtual()+" te deu o minério "+itemNome+".";
else if(acao==="removeOre")textoAviso="O admin "+nomeDoAdminAtual()+" removeu o minério "+itemNome+" da sua conta.";
else if(acao==="giveWorld")textoAviso="O admin "+nomeDoAdminAtual()+" desbloqueou o Mundo "+(valor+1)+" — "+mundosJogo[valor].nome+" para você.";
else if(acao==="removeWorld")textoAviso="O admin "+nomeDoAdminAtual()+" removeu o Mundo "+(valor+1)+" — "+mundosJogo[valor].nome+" da sua conta.";
else if(acao==="giveAuto")textoAviso="O admin "+nomeDoAdminAtual()+" liberou o Auto Clicker para você.";
else if(acao==="removeAuto")textoAviso="O admin "+nomeDoAdminAtual()+" removeu o Auto Clicker da sua conta.";
else if(acao==="givePro")textoAviso="O admin "+nomeDoAdminAtual()+" liberou o Auto Clicker Pro para você.";
else if(acao==="removePro")textoAviso="O admin "+nomeDoAdminAtual()+" removeu o Auto Clicker Pro da sua conta.";
else if(acao==="setMultiplier")textoAviso="O admin "+nomeDoAdminAtual()+" definiu sua melhoria de dinheiro no nível "+valor+".";
else if(acao==="setUpgradeLevel")textoAviso="O admin "+nomeDoAdminAtual()+" definiu "+itemNome+" no nível "+valor+".";
else if(acao==="givePet")textoAviso="O admin "+nomeDoAdminAtual()+" te deu o pet "+itemNome+".";
const avisoRemoto={id:String(Date.now())+"-"+uid,texto:textoAviso,criadoEm:Date.now()};
if(acao==="giveWorld"||acao==="removeWorld"){
 await comTempoLimite(db.runTransaction(async tx=>{
  const atualSnap=await tx.get(ref);
  if(!atualSnap.exists)throw new Error("Essa conta não existe mais.");
  const registroAtual=atualSnap.data()||{};
  const dadosAtuais=Object.assign({},registroAtual.dados||{});
  let listaAtual=Array.isArray(dadosAtuais.mundosDesbloqueados)?dadosAtuais.mundosDesbloqueados.map(Number).filter(i=>Number.isInteger(i)&&i>=0&&i<mundosJogo.length):[0];
  listaAtual=[...new Set([0,...listaAtual])];
  if(acao==="giveWorld"){
   if(!listaAtual.includes(valor))listaAtual.push(valor);
  }else{
   if(valor===0)throw new Error("O mundo inicial não pode ser removido.");
   listaAtual=listaAtual.filter(i=>i!==valor);
   if(Number(dadosAtuais.mundoAtual)===valor)dadosAtuais.mundoAtual=0;
  }
  dadosAtuais.mundosDesbloqueados=listaAtual.sort((a,b)=>a-b);
  Object.assign(dados,dadosAtuais);
  tx.set(ref,{dados:dadosAtuais,avisoAdmin:avisoRemoto,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
 }),20000,"salvar mundo do jogador");
}else{
 // Atualiza somente os campos que mudaram. Isso evita reenviar inventários
 // grandes e reduz conflitos com salvamentos simultâneos do próprio jogador.
 const atualizacao={avisoAdmin:avisoRemoto,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()};
 const chaves=new Set([...Object.keys(dadosOriginais),...Object.keys(dados)]);
 for(const chave of chaves){
  const antes=JSON.stringify(dadosOriginais[chave]);
  const depois=JSON.stringify(dados[chave]);
  if(antes!==depois){
   atualizacao["dados."+chave]=dados[chave]===undefined?firebase.firestore.FieldValue.delete():dados[chave];
  }
 }
 await comTempoLimite(ref.update(atualizacao),20000,"salvar alteração do jogador");
}
publicarResumoRanking(uid,nome,dados,jogadorEstaOnline(registro)).catch(error=>console.warn("Falha secundária ao atualizar ranking após ação administrativa:",error));
admResultado(def.rotulo+" para "+nome+(itemNome?" ("+itemNome+")":"")+" salvo com sucesso!","ok");
if(uid===usuarioAtual.uid){
aplicarDadosDoServidor(dados);
atualizarAdmin();
}
jogador.dados=dados;
atualizarSeletorVisualJogadores();
atualizarAdmin();
}catch(error){
console.error("Erro ao gerenciar jogador:",error);
admResultado("Não foi possível alterar a conta: "+(error.message||"erro no Firestore"),"erro");
}finally{
bloqueandoSalvamentoAdmin=false;
admExecutando=false;botao.disabled=false;botao.textContent=admAcao.value==="viewInventory"?"VER INVENTÁRIO":"Executar";
}
}

document.getElementById("admMundosFechar").addEventListener("click",()=>{document.getElementById("admMundosModal").style.display="none";});
document.getElementById("admMundosModal").addEventListener("click",e=>{if(e.target.id==="admMundosModal")e.currentTarget.style.display="none";});

// EVENTOS GLOBAIS
const admEventoMultiplicador=document.getElementById("admEventoMultiplicador");
const admEventoMinutos=document.getElementById("admEventoMinutos");
const admEventoStatus=document.getElementById("admEventoStatus");
function atualizarStatusEventoAdmin(){
if(!admEventoStatus)return;
if(eventoGlobal.ativo&&(eventoGlobal.permanente===true||eventoGlobal.expiraEm>Date.now())){
const falta=Math.max(0,Math.ceil((eventoGlobal.expiraEm-Date.now())/60000));
admEventoStatus.textContent=eventoGlobal.permanente?"Evento ativo: "+eventoGlobal.multiplicador+"x de dinheiro (permanente).":"Evento ativo: "+eventoGlobal.multiplicador+"x de dinheiro. Restam aproximadamente "+falta+" minuto(s).";
}else admEventoStatus.textContent="Nenhum evento ativo.";
}
async function ativarEventoGlobal(){
if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID){admResultado("Acesso administrativo não autorizado.","erro");return;}
const mult=Number(admEventoMultiplicador.value),minutos=Number(admEventoMinutos.value);
if(!Number.isInteger(mult)||mult<2||mult>1000000){admResultado("Digite um multiplicador inteiro entre 2x e 1.000.000x.","erro");return;}
const adminNome=nomeDoAdminAtual();
const agora=Date.now();
const expiraEm=new Date(agora+minutos*60000);
const id=String(agora)+"-"+usuarioAtual.uid;
try{
await comTempoLimite(db.collection("eventos").doc("multiplicadorGlobal").set({ativo:true,permanente:false,multiplicador:mult,expiraEm:firebase.firestore.Timestamp.fromDate(expiraEm),duracaoMinutos:minutos,admin:adminNome,id,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true}),20000,"ativar evento global");
admResultado("Evento global de "+mult+"x ativado por "+minutos+" minuto(s)!","ok");
}catch(error){admResultado("Não foi possível ativar o evento global: "+(error.message||"erro no Firestore"),"erro");}
atualizarStatusEventoAdmin();
}
async function encerrarEventoGlobal(){
if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID){admResultado("Acesso administrativo não autorizado.","erro");return;}
try{
await comTempoLimite(db.collection("eventos").doc("multiplicadorGlobal").set({ativo:false,multiplicador:Math.max(1,Number(eventoGlobal.multiplicador)||1),permanente:false,expiraEm:firebase.firestore.Timestamp.fromDate(new Date()),admin:nomeDoAdminAtual(),motivo:"desativado-pelo-admin",id:"desativado-"+Date.now()+"-"+usuarioAtual.uid,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true}),20000,"encerrar evento global");
admResultado("Evento global encerrado.","ok");
}catch(error){admResultado("Não foi possível encerrar o evento: "+(error.message||"erro no Firestore"),"erro");}
atualizarStatusEventoAdmin();
}
const admEventoSorteMultiplicador=document.getElementById("admEventoSorteMultiplicador");
const admEventoSorteMinutos=document.getElementById("admEventoSorteMinutos");
const admEventoSorteStatus=document.getElementById("admEventoSorteStatus");
let cancelarMonitoramentoSorte=null;
function atualizarBadgeEventoSorte(){
 const badge=document.getElementById("eventoSorteBadge");if(!badge)return;
 const restante=(Number(eventoSorteGlobal.expiraEm)||0)-Date.now();
 const ativo=eventoSorteGlobal.ativo&&(eventoSorteGlobal.permanente===true||restante>0);badge.style.display=ativo?"flex":"none";if(!ativo)return;
 document.getElementById("eventoSorteMultiplicador").textContent=eventoSorteGlobal.multiplicador+"x";
 document.getElementById("eventoSorteTempo").textContent=eventoSorteGlobal.permanente?"SORTE PERMANENTE":"SORTE "+formatarTempoEvento(restante);
}
function atualizarBadgesMutacao(){
 const cfg={anjo:{id:"eventoAnjoBadge",tempo:"eventoAnjoTempo",rotulo:"ANJO"},hacker:{id:"eventoHackerBadge",tempo:"eventoHackerTempo",rotulo:"HACKER"},galaxia:{id:"eventoGalaxiaBadge",tempo:"eventoGalaxiaTempo",rotulo:"GALÁXIA"}};
 const momentoAtivacao=k=>{const ev=eventosMutacao[k]||{};const direto=Number(ev.ativadoEm)||0;if(direto>0)return direto;const doId=Number((String(ev.id||"").match(/-(\d{10,})-/)||[])[1])||0;if(doId>0)return doId;return Math.max(0,(Number(ev.expiraEm)||0)-(Number(ev.duracaoMinutos)||0)*60000);};
 const ativos=Object.keys(cfg).filter(k=>eventosMutacao[k].ativo&&(eventosMutacao[k].permanente===true||Number(eventosMutacao[k].expiraEm)>Date.now())).sort((a,b)=>momentoAtivacao(a)-momentoAtivacao(b)||a.localeCompare(b));
 Object.keys(cfg).forEach(k=>{const c=cfg[k],ev=eventosMutacao[k],badge=document.getElementById(c.id);if(!badge)return;const restante=(Number(ev.expiraEm)||0)-Date.now(),ativo=!!ev.ativo&&(ev.permanente===true||restante>0);badge.style.display=ativo?"flex":"none";if(ativo){const pos=ativos.indexOf(k);badge.style.top=(116+Math.max(0,pos)*52)+"px";document.getElementById(c.tempo).textContent=ev.permanente?c.rotulo+" PERMANENTE":c.rotulo+" "+formatarTempoEvento(restante);}});
}
function iniciarMonitoramentoEventoSorte(){
 if(cancelarMonitoramentoSorte){try{cancelarMonitoramentoSorte();}catch(e){}}
 cancelarMonitoramentoSorte=db.collection("eventos").doc("sorteGlobal").onSnapshot(snap=>{
  const estavaAtivo=eventoSorteGlobal.ativo&&(eventoSorteGlobal.permanente===true||eventoSorteGlobal.expiraEm>Date.now());
  const ev=snap.exists?(snap.data()||{}):{};
  const expira=ev.expiraEm&&typeof ev.expiraEm.toMillis==="function"?ev.expiraEm.toMillis():Number(ev.expiraEm)||0;
  const permanente=ev.permanente===true;
  const ativo=ev.ativo===true&&(permanente||expira>Date.now());
  const id=String(ev.id||"");
  const novo=ativo&&(!eventoSorteGlobal.ativo||eventoSorteGlobal.id!==id);
  eventoSorteGlobal={ativo,multiplicador:Math.max(1,Number(ev.multiplicador)||1),expiraEm:expira,permanente,admin:String(ev.admin||"Admin"),id};
  if(novo)mostrarAviso("Evento global de SORTE ativado: "+eventoSorteGlobal.multiplicador+"x!","ok");
  if(estavaAtivo&&!ativo)mostrarAviso("O evento global de sorte terminou.","info");
  atualizarBadgeEventoSorte();
  if(admEventoSorteStatus)admEventoSorteStatus.textContent=ativo?(eventoSorteGlobal.permanente?"Evento de sorte permanente ativo: "+eventoSorteGlobal.multiplicador+"x.":"Evento de sorte ativo: "+eventoSorteGlobal.multiplicador+"x. Restam "+formatarTempoEvento(eventoSorteGlobal.expiraEm-Date.now())+"."):"Nenhum evento de sorte ativo.";
 },err=>console.error("Erro ao acompanhar evento global de sorte:",err));
}
async function ativarEventoSorteGlobal(){
 if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID){admResultado("Acesso administrativo não autorizado.","erro");return;}
 const mult=Number(admEventoSorteMultiplicador.value),minutos=Number(admEventoSorteMinutos.value);
 if(!Number.isInteger(mult)||mult<2||mult>1000000){admResultado("Informe sorte de 2x a 1.000.000x.","erro");return;}
 if(!Number.isInteger(minutos)||minutos<1||minutos>10080){admResultado("Informe uma duração entre 1 e 10080 minutos.","erro");return;}
 const agora=Date.now(),expiraEm=new Date(agora+minutos*60000),id="sorte-"+agora+"-"+usuarioAtual.uid;
 try{await comTempoLimite(db.collection("eventos").doc("sorteGlobal").set({ativo:true,permanente:false,multiplicador:mult,expiraEm:firebase.firestore.Timestamp.fromDate(expiraEm),duracaoMinutos:minutos,admin:nomeDoAdminAtual(),id,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true}),20000,"ativar evento global de sorte");admResultado("Evento global de sorte de "+mult+"x ativado por "+minutos+" minuto(s)!","ok");}
 catch(error){admResultado("Não foi possível ativar o evento de sorte: "+(error.message||"erro no Firestore"),"erro");}
}
async function encerrarEventoSorteGlobal(){
 if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID)return;
 try{await comTempoLimite(db.collection("eventos").doc("sorteGlobal").set({ativo:false,multiplicador:Math.max(1,Number(eventoSorteGlobal.multiplicador)||1),permanente:false,expiraEm:firebase.firestore.Timestamp.fromDate(new Date()),admin:nomeDoAdminAtual(),id:"sorte-off-"+Date.now()+"-"+usuarioAtual.uid,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true}),20000,"encerrar evento de sorte");admResultado("Evento global de sorte encerrado.","ok");}
 catch(error){admResultado("Não foi possível encerrar o evento de sorte: "+(error.message||"erro no Firestore"),"erro");}
}

// Ativa todos os cinco eventos com um único lote no Firestore.
async function ativarTodosEventos(){
 if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID){admResultado("Acesso administrativo não autorizado.","erro");return;}
 const dinheiro=Number(admEventoMultiplicador.value);
 const sorte=Number(admEventoSorteMultiplicador.value);
 const minutos=Number(document.getElementById("admTodosEventosMinutos").value);
 if(!Number.isInteger(dinheiro)||dinheiro<2||dinheiro>1000000||!Number.isInteger(sorte)||sorte<2||sorte>1000000){admResultado("Confira os multiplicadores de dinheiro e sorte.","erro");return;}
 if(!Number.isInteger(minutos)||minutos<1||minutos>10080){admResultado("Informe uma duração entre 1 e 10080 minutos.","erro");return;}
 const agora=Date.now(),expiraEm=new Date(agora+minutos*60000),admin=nomeDoAdminAtual(),batch=db.batch();
 const adicionar=(id,dados)=>batch.set(db.collection("eventos").doc(id),dados,{merge:true});
 adicionar("multiplicadorGlobal",{ativo:true,permanente:false,multiplicador:dinheiro,expiraEm:firebase.firestore.Timestamp.fromDate(expiraEm),duracaoMinutos:minutos,admin,id:"todos-dinheiro-"+agora+"-"+usuarioAtual.uid,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()});
 adicionar("sorteGlobal",{ativo:true,permanente:false,multiplicador:sorte,expiraEm:firebase.firestore.Timestamp.fromDate(expiraEm),duracaoMinutos:minutos,admin,id:"todos-sorte-"+agora+"-"+usuarioAtual.uid,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()});
 for(const chave of Object.keys(eventosMutacao)){
  adicionar("mutacao_"+chave,{ativo:true,permanente:false,mutacao:chave,ativadoEm:agora,expiraEm:firebase.firestore.Timestamp.fromDate(expiraEm),duracaoMinutos:minutos,admin,id:"mutacao-"+chave+"-"+agora+"-"+usuarioAtual.uid,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()});
 }
 try{await batch.commit();admResultado("Todos os eventos foram ativados com sucesso!","ok");atualizarStatusEventoAdmin();atualizarStatusMutacoesAdmin();}
 catch(error){console.error("Erro ao ativar todos os eventos:",error);admResultado("Não foi possível ativar todos os eventos: "+(error.message||"erro no Firestore"),"erro");}
}

// Eventos globais de mutação: cada um usa seu próprio documento no Firestore.
function atualizarStatusMutacoesAdmin(){
 Object.keys(eventosMutacao).forEach(chave=>{const el=document.getElementById("admMutacao"+chave[0].toUpperCase()+chave.slice(1)+"Status");if(!el)return;const ev=eventosMutacao[chave];const ativo=ev.ativo&&(ev.permanente===true||ev.expiraEm>Date.now());el.textContent=ativo?(ev.permanente?"Evento "+nomesMutacaoEvento[chave]+" ativo permanentemente.":"Evento "+nomesMutacaoEvento[chave]+" ativo. Restam "+formatarTempoEvento(ev.expiraEm-Date.now())+"."):"Nenhum evento ativo.";});
}
function iniciarMonitoramentoMutacoes(){
 Object.keys(eventosMutacao).forEach(chave=>{
  db.collection("eventos").doc("mutacao_"+chave).onSnapshot(snap=>{
   const dados=snap.exists?(snap.data()||{}):{};const exp=dados.expiraEm&&typeof dados.expiraEm.toMillis==="function"?dados.expiraEm.toMillis():Number(dados.expiraEm)||0;const permanente=dados.permanente===true;const ativo=dados.ativo===true&&(permanente||exp>Date.now());const mudou=ativo&&(!eventosMutacao[chave].ativo||eventosMutacao[chave].id!==String(dados.id||""));
   const idEvento=String(dados.id||"");const ativadoEm=Number(dados.ativadoEm)||Number((idEvento.match(/-(\d{10,})-/)||[])[1])||0;
   eventosMutacao[chave]={ativo,expiraEm:exp,permanente,id:idEvento,ativadoEm,duracaoMinutos:Number(dados.duracaoMinutos)||0};
   if(mudou)mostrarAviso("EVENTO "+nomesMutacaoEvento[chave].toUpperCase()+" ATIVADO! Todos os pets dos ovos receberão essa mutação.","ok");
   atualizarStatusMutacoesAdmin();atualizarBadgesMutacao();
  },err=>console.error("Erro ao acompanhar evento de mutação "+chave,err));
 });
}
async function controlarEventoMutacao(chave,ativar){
 if(!adminDesbloqueado||!usuarioAtual||usuarioAtual.uid!==ADMIN_UID){admResultado("Acesso administrativo não autorizado.","erro");return;}
 const nome=chave[0].toUpperCase()+chave.slice(1),minutosEl=document.getElementById("admMutacao"+nome+"Minutos");
 const minutos=Number(minutosEl&&minutosEl.value);
 
 const agora=Date.now();
 if(ativar&&(!Number.isFinite(minutos)||minutos<1||minutos>10080)){admResultado("Informe uma duração entre 1 e 10080 minutos.","erro");return;}
 const expiraEm=ativar?new Date(agora+minutos*60000):new Date();
 const id="mutacao-"+chave+"-"+agora+"-"+usuarioAtual.uid;
 try{await comTempoLimite(db.collection("eventos").doc("mutacao_"+chave).set({ativo:ativar,permanente:false,mutacao:chave,ativadoEm:ativar?agora:0,expiraEm:firebase.firestore.Timestamp.fromDate(expiraEm),duracaoMinutos:ativar?minutos:0,admin:nomeDoAdminAtual(),id,atualizadoEm:firebase.firestore.FieldValue.serverTimestamp()},{merge:true}),20000,(ativar?"ativar":"encerrar")+" evento "+nome);admResultado(ativar?"Evento "+nomesMutacaoEvento[chave]+" ativado por "+minutos+" minuto(s)!":"Evento "+nomesMutacaoEvento[chave]+" encerrado.","ok");}
 catch(error){admResultado("Não foi possível alterar o evento "+nome+": "+(error.message||"erro no Firestore"),"erro");}
}
Object.keys(eventosMutacao).forEach(chave=>{const nome=chave[0].toUpperCase()+chave.slice(1);document.getElementById("admMutacao"+nome+"Ativar").addEventListener("click",()=>controlarEventoMutacao(chave,true));document.getElementById("admMutacao"+nome+"Encerrar").addEventListener("click",()=>controlarEventoMutacao(chave,false));});
iniciarMonitoramentoMutacoes();
setInterval(atualizarStatusMutacoesAdmin,1000);

document.getElementById("admEventoSorteAtivar").addEventListener("click",ativarEventoSorteGlobal);
document.getElementById("admEventoSorteEncerrar").addEventListener("click",encerrarEventoSorteGlobal);
document.getElementById("admEventoSortePresets").addEventListener("click",e=>{const b=e.target.closest("button[data-sorte-mult]");if(b)admEventoSorteMultiplicador.value=b.dataset.sorteMult;});
document.getElementById("admEventoAtivar").addEventListener("click",ativarEventoGlobal);
document.getElementById("admEventoEncerrar").addEventListener("click",encerrarEventoGlobal);
document.getElementById("admAtivarTodosEventos").addEventListener("click",ativarTodosEventos);
document.getElementById("admEventoPresets").addEventListener("click",e=>{const b=e.target.closest("button[data-evento-mult]");if(b)admEventoMultiplicador.value=b.dataset.eventoMult;});

// Transforma selects do painel em menus suspensos internos, sem abrir a interface nativa do celular.
function instalarSeletorPersonalizado(select,opcoes){
if(!select||select.dataset.customizado==="1")return;
select.dataset.customizado="1";
const wrap=document.createElement("div");wrap.className="adm-select-wrap";
select.parentNode.insertBefore(wrap,select);wrap.appendChild(select);select.classList.add("adm-select-original");
const botao=document.createElement("button");botao.type="button";botao.className="adm-select-trigger";botao.setAttribute("aria-haspopup","listbox");botao.setAttribute("aria-expanded","false");
botao.innerHTML='<span></span><span class="adm-seta">▾</span>';
const label=botao.querySelector("span");const lista=document.createElement("div");lista.className="adm-select-list";lista.setAttribute("role","listbox");lista.hidden=true;
wrap.appendChild(botao);wrap.appendChild(lista);
function fechar(){lista.hidden=true;botao.setAttribute("aria-expanded","false");}
function render(){
const selecionada=select.selectedOptions&&select.selectedOptions[0]?select.selectedOptions[0]:select.options[0];
label.textContent=selecionada?selecionada.textContent:"Selecione";
label.style.color=selecionada&&selecionada.style.color?selecionada.style.color:"";
lista.textContent="";
Array.from(select.options).forEach(opt=>{
const item=document.createElement("button");item.type="button";item.className="adm-select-option"+(opt.value===select.value?" selecionada":"");item.setAttribute("role","option");item.setAttribute("aria-selected",opt.value===select.value?"true":"false");item.textContent=opt.textContent;if(opt.style.color)item.style.color=opt.style.color;if(opt.style.fontWeight)item.style.fontWeight=opt.style.fontWeight;item.disabled=opt.disabled;item.addEventListener("click",()=>{select.value=opt.value;select.dispatchEvent(new Event("change",{bubbles:true}));render();fechar();});lista.appendChild(item);
});
}
botao.addEventListener("click",()=>{if(select.disabled||botao.disabled)return;const abrir=lista.hidden;lista.hidden=!abrir;botao.setAttribute("aria-expanded",abrir?"true":"false");if(abrir){const atual=lista.querySelector(".selecionada");if(atual)atual.scrollIntoView({block:"nearest"});}});
select.addEventListener("change",render);
new MutationObserver(render).observe(select,{childList:true,subtree:true,attributes:true});
select._renderSeletor=render;select._fecharSeletor=fechar;
if(opcoes&&opcoes.recarregar)select.addEventListener("adm:refresh",render);
render();
return {render,fechar,wrap,botao,lista};
}
document.addEventListener("click",e=>{document.querySelectorAll(".adm-select-wrap").forEach(w=>{if(!w.contains(e.target)){const l=w.querySelector(".adm-select-list"),b=w.querySelector(".adm-select-trigger");if(l)l.hidden=true;if(b)b.setAttribute("aria-expanded","false");}});});

// INICIALIZAÇÃO E EVENTOS

preencherLista(admPicareta,picaretas,1);
preencherLista(admMinerio,minerios,1);
instalarSeletorPersonalizado(admPicareta);
instalarSeletorPersonalizado(admMinerio);
instalarSeletorPersonalizado(admRemotoItem);
for(const [chave,def] of Object.entries(CATEGORIAS_ADMIN)){
const opcao=document.createElement("option");
opcao.value=chave;
opcao.textContent=def.rotulo;
if(chave==="reset"){opcao.style.color="#ff4444";opcao.style.fontWeight="900";}
admCategoria.appendChild(opcao);
}
admCategoria.addEventListener("change",preencherAcoesCategoriaAdmin);
admAcao.addEventListener("change",atualizarCamposRemotos);
preencherAcoesCategoriaAdmin();
instalarSeletorPersonalizado(admCategoria);
instalarSeletorPersonalizado(admAcao);
document.getElementById("admAtualizarJogadores").addEventListener("click",carregarJogadoresAdmin);
atualizarCamposRemotos();

adminBox.addEventListener("click",evento=>{
const botao=evento.target.closest("button");
if(!botao||!adminBox.contains(botao))return;

if(botao.id==="adminFechar"){
fecharAdmin();
somFecharLoja();
return;
}
if(botao.dataset.aba){
trocarAbaAdmin(botao.dataset.aba);
return;
}

const acao=botao.dataset.acao;
if(!acao)return;
if(botao.hasAttribute("data-perigo")&&!confirmarClique(botao))return;
if(!jogoPronto()){
admResultado("Entre na sua conta antes de usar o painel.","erro");
return;
}

switch(acao){
case "moedas-add":admMoedas("add");break;
case "moedas-remover":admMoedas("remover");break;
case "moedas-definir":admMoedas("definir");break;
case "moedas-zerar":admMoedas("zerar");break;
case "picareta-dar":admItens("picareta","dar");break;
case "picareta-remover":admItens("picareta","remover");break;
case "picareta-todas":admItens("picareta","todos");break;
case "picareta-resetar":admItens("picareta","resetar");break;
case "minerio-dar":admItens("minerio","dar");break;
case "minerio-remover":admItens("minerio","remover");break;
case "minerio-todos":admItens("minerio","todos");break;
case "minerio-resetar":admItens("minerio","resetar");break;
case "auto-liberar":admMelhoria("auto",true);break;
case "auto-remover":admMelhoria("auto",false);break;
case "pro-liberar":admMelhoria("pro",true);break;
case "pro-remover":admMelhoria("pro",false);break;
case "mult-definir":admMultiplicador();break;
case "tudo":
admItens("picareta","todos");
admItens("minerio","todos");
break;
case "remoto":admExecutarRemoto(botao);break;
}
});

// Mudou algum campo: cancela qualquer confirmação pendente para não confirmar outra ação por engano
function cancelarConfirmacoes(){
for(const botao of adminBox.querySelectorAll("button[data-aguardando='1']")){
clearTimeout(botao._timerConfirmar);
botao.dataset.aguardando="";
botao.textContent=botao.dataset.rotulo;
botao.classList.remove("aguardando");
}
}
adminBox.addEventListener("input",cancelarConfirmacoes);
adminBox.addEventListener("change",cancelarConfirmacoes);

adminModal.addEventListener("pointerdown",evento=>{
if(evento.target===adminModal){
fecharAdmin();
somFecharLoja();
}
});

document.addEventListener("keydown",evento=>{
if(evento.key!=="Escape")return;
if(adminAberto){
fecharAdmin();
somFecharLoja();
}else if(codigoModalAberto){
fecharResgate();
}
});


// CÓDIGOS

function abrirResgate(){
codigoModalAberto=true;
modal.style.display="flex";
codeInput.value="";
setTimeout(()=>codeInput.focus(),100);
}

function fecharResgate(){
codigoModalAberto=false;
modal.style.display="none";
}

function resgatarCodigo(){
const codigo=codeInput.value.trim().toUpperCase();

if(!codigo){
mostrarAviso("Digite um código!");
return;
}

if(!jogoPronto()){
mostrarAviso("Entre na sua conta antes de resgatar códigos.");
return;
}

if(codigosUsados.includes(codigo)){
mostrarAviso("Você já utilizou esse código!");
return;
}

if(codigo==="BETA"){
moedas+=10000;
codigosUsados.push(codigo);
salvar();
somRaro();
fecharResgate();
mostrarAviso("Código resgatado! Você recebeu $10.000!","ok");
return;
}

mostrarAviso("Código inválido!");
}

document.getElementById("redeemButton").addEventListener("click",resgatarCodigo);
document.getElementById("cancelButton").addEventListener("click",fecharResgate);

codeInput.addEventListener("keydown",e=>{
if(e.key==="Enter")resgatarCodigo();
});

// LOJA

function limitarScroll(){
const total=categoria==="picaretas"?picaretas.length-1:minerios.length-1;
scroll=Math.max(0,Math.min(scroll,total-3));
}

function selecionarItem(linha){
const indice=scroll+linha;
if(linha<0||linha>=3)return;

if(categoria==="picaretas"){
const real=indice+1;
if(real>=picaretas.length)return;

const item=picaretas[real];

if(picaretasCompradas.includes(real)){
if(picaretaAtual!==real){
picaretaAtual=real;
somEquipar();
}
}else if(moedas>=item[1]){
moedas-=item[1];
picaretasCompradas.push(real);
picaretaAtual=real;
somCompra();
if(real>=6)somRaro();
}else{
mostrarAviso("SALDO INSUFICIENTE");
}
}else{
const real=indice+1;
if(real>=minerios.length)return;

const item=minerios[real];

if(mineriosComprados.includes(real)){
if(minerioAtual!==real){
minerioAtual=real;
somEquipar();
}
}else if(moedas>=item[1]){
moedas-=item[1];
mineriosComprados.push(real);
minerioAtual=real;
somCompra();
if(real>=6)somRaro();
}else{
mostrarAviso("SALDO INSUFICIENTE");
}
}

salvar();
}

// DESENHO

function retangulo(x,y,w,h,cor,raio=0){
ctx.fillStyle=cor;
ctx.beginPath();
ctx.roundRect(x,y,w,h,raio);
ctx.fill();
}

function texto(txt,x,y,tamanho,cor="#fff",alinhamento="left"){
ctx.fillStyle=cor;
ctx.font="bold "+tamanho+"px Arial";
ctx.textAlign=alinhamento;
ctx.fillText(txt,x,y);
ctx.textAlign="left";
}

function linha(x1,y1,x2,y2,cor,largura){
ctx.strokeStyle=cor;
ctx.lineWidth=largura;
ctx.lineCap="round";
ctx.beginPath();
ctx.moveTo(x1,y1);
ctx.lineTo(x2,y2);
ctx.stroke();
}

function brilho(x,y,raio,cor){
ctx.save();
ctx.shadowColor=cor;
ctx.shadowBlur=raio;
ctx.fillStyle=cor;
ctx.beginPath();
ctx.arc(x,y,raio/4,0,Math.PI*2);
ctx.fill();
ctx.restore();
}

function desenharPicaretaPequena(x,y,tamanho,cor,indice){
const c=`rgb(${cor.join(",")})`;

ctx.save();
ctx.translate(x,y);
ctx.scale(tamanho/100,tamanho/100);

ctx.shadowColor=c;
ctx.shadowBlur=indice>=5?12:3;

linha(0,48,0,-25,"#75421f",10);
linha(0,48,0,-25,"#d29a63",3);
linha(-38,-25,38,-25,c,indice>=5?13:10);
linha(-38,-25,-48,-10,c,indice>=5?12:8);
linha(38,-25,48,-10,c,indice>=5?12:8);
linha(-38,-29,38,-29,"rgba(255,255,255,0.7)",2);

if(indice>=6){
linha(-25,-35,-15,-44,c,3);
linha(25,-35,15,-44,c,3);
brilho(0,-25,10,"#fff");
}

if(indice>=15){
linha(-45,-25,-35,-42,"#fff",2);
linha(45,-25,35,-42,"#fff",2);
}

if(indice>=26){
linha(-30,-40,-20,-52,c,4);
linha(30,-40,20,-52,c,4);
brilho(0,-25,18,c);
}

ctx.restore();
}

function desenharPicareta(){
const item=picaretas[picaretaAtual],cor=item[3];
const corCSS=`rgb(${cor.join(",")})`,nivel=picaretaAtual;

ctx.save();
ctx.translate(250,250);

if(diagonal)ctx.rotate(0.78);

ctx.translate(-250,-250);

ctx.shadowColor=corCSS;
ctx.shadowBlur=nivel>=5?18:5;

linha(250,250,250,100,"#533018",19);
linha(246,248,246,104,"#c28b59",5);
linha(254,248,254,104,"#8a522d",3);

retangulo(239,145,22,9,"#d6b477",3);
retangulo(239,190,22,9,"#d6b477",3);
retangulo(241,220,18,7,"#d6b477",3);

linha(190,100,310,100,corCSS,nivel>=5?21:16);
linha(190,100,175,120,corCSS,nivel>=5?18:13);
linha(310,100,325,120,corCSS,nivel>=5?18:13);

linha(190,94,310,94,"rgba(255,255,255,0.75)",3);
linha(175,120,184,106,"rgba(255,255,255,0.65)",3);
linha(325,120,316,106,"rgba(255,255,255,0.65)",3);

if(nivel>=3){
linha(205,100,205,113,"rgba(0,0,0,0.35)",3);
linha(295,100,295,113,"rgba(0,0,0,0.35)",3);
}

if(nivel>=5){
ctx.shadowBlur=0;
linha(250,82,250,60,corCSS,5);
linha(230,88,216,75,corCSS,4);
linha(270,88,284,75,corCSS,4);
retangulo(242,88,16,17,"#fff",4);
retangulo(246,92,8,9,corCSS,2);
}

if(nivel>=10){
for(let i=0;i<5;i++)linha(195+i*27,110,195+i*27,121,corCSS,3);
retangulo(244,155,12,12,"#fff",3);
retangulo(247,158,6,6,corCSS,2);
}

if(nivel>=15){
ctx.shadowColor=corCSS;
ctx.shadowBlur=18;
linha(180,100,190,77,corCSS,5);
linha(320,100,310,77,corCSS,5);
linha(250,82,250,48,"#fff",3);
}

if(nivel>=20){
linha(210,85,220,65,"#fff",3);
linha(290,85,280,65,"#fff",3);
brilho(250,75,20,corCSS);
}

if(nivel>=26){
ctx.shadowColor=corCSS;
ctx.shadowBlur=25;
linha(180,100,165,78,corCSS,6);
linha(320,100,335,78,corCSS,6);
linha(165,78,185,82,"#fff",3);
linha(335,78,315,82,"#fff",3);
retangulo(239,68,22,22,corCSS,5);
retangulo(245,74,10,10,"#fff",3);
linha(220,100,220,125,"rgba(255,255,255,0.65)",3);
linha(280,100,280,125,"rgba(255,255,255,0.65)",3);
}

if(nivel>=30){
linha(190,65,210,45,corCSS,4);
linha(310,65,290,45,corCSS,4);
linha(250,60,250,35,"#fff",4);
brilho(250,58,28,corCSS);
}

if(nivel>=33){
linha(175,95,155,95,"#fff",3);
linha(325,95,345,95,"#fff",3);
linha(250,35,235,20,corCSS,4);
linha(250,35,265,20,corCSS,4);
}

ctx.restore();
}

function desenharMinerio(){
const cor=minerios[minerioAtual][3];
const corCSS=`rgb(${cor.join(",")})`;

texto(minerios[minerioAtual][0],417,143,20,corCSS,"center");

retangulo(370,155,95,95,"#292929",7);
retangulo(374,159,87,87,corCSS,5);

ctx.fillStyle="rgba(255,255,255,0.17)";
ctx.beginPath();
ctx.moveTo(380,166);
ctx.lineTo(405,163);
ctx.lineTo(418,190);
ctx.lineTo(395,205);
ctx.closePath();
ctx.fill();

ctx.fillStyle="rgba(0,0,0,0.17)";
ctx.beginPath();
ctx.moveTo(418,190);
ctx.lineTo(457,168);
ctx.lineTo(454,235);
ctx.lineTo(421,240);
ctx.closePath();
ctx.fill();

ctx.fillStyle="rgba(255,255,255,0.24)";
ctx.beginPath();
ctx.moveTo(390,213);
ctx.lineTo(416,195);
ctx.lineTo(440,224);
ctx.lineTo(410,238);
ctx.closePath();
ctx.fill();

linha(380,164,455,164,"rgba(255,255,255,0.35)",2);
linha(380,240,455,240,"rgba(0,0,0,0.25)",2);
}

// LOJA DE PICARETAS E MINÉRIOS

function desenharLoja(){
retangulo(25,30,450,250,"#171722",12);

const fundo=ctx.createLinearGradient(25,30,475,280);
fundo.addColorStop(0,"#292b40");
fundo.addColorStop(1,"#171722");

retangulo(27,32,446,246,fundo,10);

ctx.strokeStyle="#747da8";
ctx.lineWidth=2;
ctx.beginPath();
ctx.roundRect(25,30,450,250,12);
ctx.stroke();

texto("MINING SHOP",45,61,25,"#ffdc00","left");

retangulo(435,40,28,28,"#b42828",6);
texto("X",449,61,19,"#fff","center");

retangulo(45,72,175,28,categoria==="picaretas"?"#2864c8":"#414150",6);
retangulo(230,72,175,28,categoria==="minerios"?"#2864c8":"#414150",6);

texto("Pickaxes",132,92,17,"#fff","center");
texto("Ores",317,92,17,"#fff","center");

const lista=categoria==="picaretas"?picaretas.slice(1):minerios.slice(1);

ctx.save();
ctx.beginPath();
ctx.rect(40,102,425,168);
ctx.clip();

for(let linhaIndex=0;linhaIndex<3;linhaIndex++){
const i=scroll+linhaIndex;
if(i>=lista.length)break;

const item=lista[i],y=105+linhaIndex*55;

const gradiente=ctx.createLinearGradient(40,y,465,y+45);
gradiente.addColorStop(0,"#41445b");
gradiente.addColorStop(1,"#292b3c");

retangulo(40,y,425,45,gradiente,7);

ctx.strokeStyle="rgba(255,255,255,0.12)";
ctx.lineWidth=1;
ctx.beginPath();
ctx.roundRect(40,y,425,45,7);
ctx.stroke();

const indiceReal=i+1;

const comprados=categoria==="picaretas"?picaretasCompradas:mineriosComprados;
const atual=categoria==="picaretas"?picaretaAtual:minerioAtual;

if(categoria==="picaretas"){
desenharPicaretaPequena(61,y+24,34,item[3],indiceReal);
texto(item[0],88,y+18,14,"#fff");
texto("POWER: "+formatarDinheiro(item[2]),88,y+36,12,"#70dcff");

if(indiceReal>=26)texto("NEW",310,y+17,9,"#ffe36e");

}else{
retangulo(49,y+10,25,25,`rgb(${item[3].join(",")})`,5);
retangulo(53,y+13,9,7,"rgba(255,255,255,0.4)",2);

texto(item[0],85,y+18,14,"#fff");
texto("MULTIPLIER: "+item[2]+"x",85,y+36,12,"#70dcff");
}

let corBotao,nomeBotao;

if(comprados.includes(indiceReal)){
if(atual===indiceReal){
corBotao="#23964d";
nomeBotao="EQUIPPED";
}else{
corBotao="#2864b4";
nomeBotao="EQUIP";
}
}else{
corBotao=moedas>=item[1]?"#1e8c46":"#754044";
nomeBotao="$ "+formatarDinheiro(item[1]);
}

retangulo(350,y+7,105,30,corBotao,7);
texto(nomeBotao,402,y+27,12,"#fff","center");
}

ctx.restore();

if(lista.length>3){
retangulo(468,105,4,155,"#414150",3);

const altura=Math.max(20,155*3/lista.length);
const posicao=scroll*(155-altura)/(lista.length-3);

retangulo(468,105+posicao,4,altura,"#64b4ff",3);
}

texto(
categoria==="picaretas"
?picaretasCompradas.length+"/"+picaretas.length+" UNLOCKED"
:mineriosComprados.length+"/"+minerios.length+" UNLOCKED",
45,267,10,"#aab5d9"
);
}

// PAINEL UPGRADES

function obterLinhasMelhorias(){
 const ci=CUSTOS_INVENTARIO_PETS[melhoriaInventarioPets],ce=CUSTOS_EQUIPAR_PETS[melhoriaPetsEquipados];
 return [
  {id:"multiplicador",t:"MELHORIA DE DINHEIRO",d:"Nível "+multiplicadorCompras+" | Bônus "+multiplicadorMelhoria().toFixed(1)+"x",b:"$ "+formatarDinheiro(precoMultiplicador),c:moedas>=precoMultiplicador?"#218b4a":"#754044"},
  {id:"auto",t:"AUTO CLICK",d:autoClickerComprado?"NÍVEL MÁXIMO ALCANÇADO":"Desbloqueia 5 cliques por segundo",b:autoClickerComprado?"MAX":"$ 100K",c:autoClickerComprado?"#777777":(moedas>=100000?"#218b4a":"#754044"),max:autoClickerComprado},
  {id:"autopro",t:"AUTO CLICK PRO",d:autoClickerProComprado?"NÍVEL MÁXIMO ALCANÇADO":"Desbloqueia 25 cliques por segundo",b:autoClickerProComprado?"MAX":"$ 10M",c:autoClickerProComprado?"#777777":(moedas>=10000000?"#218b4a":"#754044"),max:autoClickerProComprado},
  {id:"triplo",t:"OVOS TRIPLOS",d:triploOvoComprado?"NÍVEL MÁXIMO ALCANÇADO":"Desbloqueia abertura de 3 ovos por vez",b:triploOvoComprado?"MAX":"$ 25M",c:triploOvoComprado?"#777777":(moedas>=CUSTO_TRIPLO_OVO?"#218b4a":"#754044"),max:triploOvoComprado},
  {id:"sorte",t:"SORTE DE OVO",d:sorteOvoNivel>=20?"NÍVEL MÁXIMO ALCANÇADO":"Nível "+sorteOvoNivel+" | Mais chance de raridades altas",b:sorteOvoNivel>=20?"MAX":"$ "+formatarDinheiro(precoSorteOvo),c:sorteOvoNivel>=20?"#777777":(moedas>=precoSorteOvo?"#218b4a":"#754044"),max:sorteOvoNivel>=20},
  {id:"impulso",t:"IMPULSO DE PET",d:impulsoPetsNivel>=20?"NÍVEL MÁXIMO ALCANÇADO":"Nível "+impulsoPetsNivel+" | +"+(impulsoPetsNivel*15)+"% no bônus dos pets",b:impulsoPetsNivel>=20?"MAX":"$ "+formatarDinheiro(precoImpulsoPets),c:impulsoPetsNivel>=20?"#777777":(moedas>=precoImpulsoPets?"#218b4a":"#754044"),max:impulsoPetsNivel>=20},
  {id:"inventario",t:"MAIS ESPAÇO NO INVENTÁRIO",d:"ATUAL: "+limiteInventarioPets()+" | PRÓXIMO: "+(melhoriaInventarioPets>=6?"200 (MÁX.)":limiteInventarioPets()+25),b:melhoriaInventarioPets>=6?"MAX":"$ "+formatarDinheiro(ci),c:melhoriaInventarioPets>=6?"#777777":(moedas>=ci?"#218b4a":"#754044"),max:melhoriaInventarioPets>=6},
  {id:"equipar",t:"MAIS PETS EQUIPADOS",d:"ATUAL: "+limitePetsEquipados()+" | PRÓXIMO: "+(melhoriaPetsEquipados>=3?"6 (MÁX.)":limitePetsEquipados()+1),b:melhoriaPetsEquipados>=3?"MAX":"$ "+formatarDinheiro(ce),c:melhoriaPetsEquipados>=3?"#777777":(moedas>=ce?"#218b4a":"#754044"),max:melhoriaPetsEquipados>=3}
 ];
}
function desenharMelhorias(){
 retangulo(15,5,470,290,"#171722",12);
 const fundo=ctx.createLinearGradient(15,5,485,295);fundo.addColorStop(0,"#263d55");fundo.addColorStop(1,"#171722");retangulo(17,7,466,286,fundo,10);
 ctx.strokeStyle="#64b4ff";ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(15,5,470,290,12);ctx.stroke();
 texto("UPGRADES",34,35,22,"#64b4ff");
 retangulo(435,15,34,32,"#b42828",6);texto("X",452,38,21,"#fff","center");
 const linhas=obterLinhasMelhorias(),maxScroll=Math.max(0,linhas.length*ALTURA_LINHA_MELHORIA-ALTURA_LISTA_MELHORIAS);
 scrollMelhorias=Math.max(0,Math.min(maxScroll,scrollMelhorias));
 ctx.save();ctx.beginPath();ctx.rect(25,TOPO_LISTA_MELHORIAS,450,ALTURA_LISTA_MELHORIAS);ctx.clip();
 linhas.forEach((l,i)=>{const y=TOPO_LISTA_MELHORIAS+i*ALTURA_LINHA_MELHORIA-scrollMelhorias;
  retangulo(29,y+2,442,38,"#34394e",6);texto(l.t,40,y+16,12,l.id==="inventario"||l.id==="equipar"?"#ffe08a":"#ffffff");texto(l.d,40,y+31,10,l.max?"#a0a0a0":"#bdc9da");retangulo(365,y+7,96,27,l.c,5);texto(l.b,413,y+25,10,l.max?"#d0d0d0":"#fff","center");
 });ctx.restore();
 retangulo(477,TOPO_LISTA_MELHORIAS,4,ALTURA_LISTA_MELHORIAS,"#414150",2);
 const altura=Math.max(28,ALTURA_LISTA_MELHORIAS*ALTURA_LISTA_MELHORIAS/(linhas.length*ALTURA_LINHA_MELHORIA));
 retangulo(477,TOPO_LISTA_MELHORIAS+(ALTURA_LISTA_MELHORIAS-altura)*(maxScroll?scrollMelhorias/maxScroll:0),4,altura,"#64b4ff",2);
 texto("ROLE, USE AS SETAS OU ARRASTE PARA VER TODAS AS MELHORIAS",250,282,9,"#a9bed8","center");
}
function comprarMelhoriaPorIndice(indice){
 const ids=obterLinhasMelhorias().map(l=>l.id),id=ids[indice];
 if(id==="multiplicador")comprarMultiplicador();else if(id==="auto")comprarAutoClicker();else if(id==="autopro")comprarAutoClickerPro();else if(id==="triplo")comprarTriploOvo();else if(id==="sorte")comprarSorteOvo();else if(id==="impulso")comprarImpulsoPets();else if(id==="inventario")comprarEspacoInventarioPets();else if(id==="equipar")comprarEspacoPetsEquipados();
}

function comprarTriploOvo(){
 if(triploOvoComprado){mostrarAviso("O upgrade OVOS TRIPLOS já está no máximo.","info");return;}
 if(moedas<CUSTO_TRIPLO_OVO){mostrarAviso("Você precisa de $ 25M para desbloquear OVOS TRIPLOS.","erro");return;}
 moedas-=CUSTO_TRIPLO_OVO;triploOvoComprado=true;salvar();atualizarControlesOvo();somRaro();mostrarAviso("OVOS TRIPLOS desbloqueados! Agora você pode abrir 3 ovos de uma vez.","ok");
}
function comprarSorteOvo(){
 if(sorteOvoNivel>=20){mostrarAviso("A sorte de ovo já está no nível máximo.","info");return;}
 if(moedas<precoSorteOvo){mostrarAviso("Saldo insuficiente para melhorar a sorte de ovo.","erro");return;}
 moedas-=precoSorteOvo;sorteOvoNivel++;precoSorteOvo*=3;salvar();renderizarChancesOvo();somRaro();mostrarAviso("Sorte de ovo aumentada para o nível "+sorteOvoNivel+"!","ok");
}
function comprarImpulsoPets(){
 if(impulsoPetsNivel>=20){mostrarAviso("O impulso de pets já está no nível máximo.","info");return;}
 if(moedas<precoImpulsoPets){mostrarAviso("Saldo insuficiente para melhorar o impulso de pets.","erro");return;}
 moedas-=precoImpulsoPets;impulsoPetsNivel++;precoImpulsoPets*=2;salvar();renderizarResumoPets();somRaro();mostrarAviso("Impulso de pets aumentado! Bônus adicional: +"+(impulsoPetsNivel*15)+"%.","ok");
}
const CUSTOS_INVENTARIO_PETS=[2000000,8000000,25000000,75000000,200000000,500000000];
const CUSTOS_EQUIPAR_PETS=[15000000,75000000,300000000];
function comprarEspacoInventarioPets(){
 if(melhoriaInventarioPets>=6){mostrarAviso("O inventário já está no máximo: 200 pets.","info");return;}
 const custo=CUSTOS_INVENTARIO_PETS[melhoriaInventarioPets];
 if(moedas<custo){mostrarAviso("Você precisa de $ "+formatarDinheiro(custo)+" para aumentar o inventário para "+(limiteInventarioPets()+25)+" pets.","erro");return;}
 moedas-=custo;melhoriaInventarioPets++;salvar();renderizarResumoPets();somRaro();mostrarAviso("Inventário aumentado! Novo limite: "+limiteInventarioPets()+" pets.","ok");
}
function comprarEspacoPetsEquipados(){
 if(melhoriaPetsEquipados>=3){mostrarAviso("Você já atingiu o máximo de 6 pets equipados.","info");return;}
 const custo=CUSTOS_EQUIPAR_PETS[melhoriaPetsEquipados];
 if(moedas<custo){mostrarAviso("Você precisa de $ "+formatarDinheiro(custo)+" para liberar o espaço de número "+(limitePetsEquipados()+1)+".","erro");return;}
 moedas-=custo;melhoriaPetsEquipados++;salvar();renderizarResumoPets();somRaro();mostrarAviso("Melhoria comprada! Agora você pode equipar até "+limitePetsEquipados()+" pets.","ok");
}
function alternarPaginaMelhorias(){paginaMelhorias=paginaMelhorias?0:1;somClique();}
function comprarOuAlternarAutoOvo(){
 if(!autoOvoComprado){if(moedas<5000000){mostrarAviso("Você precisa de $ 5M para desbloquear ovos automáticos.","erro");return;}moedas-=5000000;autoOvoComprado=true;autoOvoAtivo=false;mostrarAviso("Ovos automáticos desbloqueados! Toque novamente para ativar.","ok");}
 else{autoOvoAtivo=!autoOvoAtivo;ultimoAutoOvo=Date.now();mostrarAviso(autoOvoAtivo?"Abertura automática de ovos ativada.":"Abertura automática de ovos desativada.","info");}
 salvar();
}

// CONFIGURAÇÕES

function desenharConfiguracoes(){
retangulo(25,30,450,250,"#171722",12);

const fundo=ctx.createLinearGradient(25,30,475,280);
fundo.addColorStop(0,"#202d49");
fundo.addColorStop(1,"#171722");

retangulo(27,32,446,246,fundo,10);

ctx.strokeStyle="#64b4ff";
ctx.lineWidth=2;
ctx.beginPath();
ctx.roundRect(25,30,450,250,12);
ctx.stroke();

texto("CONFIGURAÇÕES",45,62,23,"#64b4ff");

retangulo(435,40,28,28,"#b42828",6);
texto("X",449,61,19,"#fff","center");

// VOLUME

texto("VOLUME DOS EFEITOS",250,91,15,"#fff","center");

retangulo(90,103,320,10,"#414150",6);
retangulo(90,103,320*volumeGeral,10,"#42a5ff",6);
retangulo(82+320*volumeGeral,95,18,26,"#fff",7);

texto(Math.round(volumeGeral*100)+"%",250,137,15,"#ffdc00","center");

// AUTO CLICK NORMAL

if(autoClickerComprado){
retangulo(45,145,410,30,autoClickerAtivo?"#187d43":"#414150",7);

texto("AUTO CLICKER",57,165,13,"#fff");

texto(
autoClickerAtivo?"ATIVADO":"DESATIVADO",
437,165,12,autoClickerAtivo?"#75ff9a":"#bbb","right"
);
}

// AUTO CLICK PRO

if(autoClickerProComprado){
retangulo(45,179,410,30,autoClickerProAtivo?"#7134bd":"#414150",7);

texto("AUTO CLICKER PRO",57,199,13,"#fff");

texto(
autoClickerProAtivo?"ATIVADO":"DESATIVADO",
437,199,12,autoClickerProAtivo?"#e3baff":"#bbb","right"
);
}

// TROCAR SENHA

retangulo(45,214,410,27,"#2864a8",7);
texto("TROCAR SENHA",250,233,13,"#fff","center");

// CÓDIGOS E SAIR DA CONTA

retangulo(45,246,190,28,"#7134bd",7);
texto("CODIGOS",140,265,13,"#fff","center");

retangulo(255,246,200,28,"#a83232",7);
texto("SAIR",355,265,13,"#fff","center");
}

// ENGRENAGEM

function desenharEngrenagem(x,y){
ctx.save();
ctx.translate(x,y);
ctx.strokeStyle="#fff";
ctx.lineWidth=3;
ctx.lineCap="round";

for(let i=0;i<8;i++){
const a=i*Math.PI/4;
linha(
Math.cos(a)*7,
Math.sin(a)*7,
Math.cos(a)*12,
Math.sin(a)*12,
"#fff",3
);
}

ctx.beginPath();
ctx.arc(0,0,7,0,Math.PI*2);
ctx.stroke();

ctx.beginPath();
ctx.arc(0,0,2,0,Math.PI*2);
ctx.fillStyle="#fff";
ctx.fill();

ctx.restore();
}

// Cenários cartoon desenhados no canvas, sem dependência de imagens externas.
function desenharCenarioCartoon(){
 const t=Date.now()/1000, w=Math.max(0,Math.min(4,mundoAtual));
 const temas=[['#83d8ff','#e6f9ff','#64bd72','#358f63'],['#253a65','#6676a9','#35456e','#202e53'],['#ff9b55','#5e2447','#7a3548','#48213a'],['#a8edff','#eafaff','#87c5e7','#5d9ac9'],['#24154d','#613c9a','#47307b','#221443']];
 const c=temas[w],g=ctx.createLinearGradient(0,0,0,300);g.addColorStop(0,c[0]);g.addColorStop(1,c[1]);ctx.fillStyle=g;ctx.fillRect(0,0,500,300);
 const circle=(x,y,r,color)=>{ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();};
 const hill=(x,y,rx,ry,color)=>{ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,Math.PI,Math.PI*2);ctx.lineTo(x+rx,300);ctx.lineTo(x-rx,300);ctx.closePath();ctx.fillStyle=color;ctx.fill();};
 if(w===0){
  circle(404,65,30,'#fff0a1');for(let i=0;i<5;i++){let x=(i*127+35)%520;circle(x,65+(i%2)*24,19,'#ffffffbb');circle(x+22,65+(i%2)*24,24,'#ffffffbb');}
  hill(120,240,210,100,c[2]);hill(395,245,230,110,c[3]);
  for(let i=0;i<8;i++){let x=i*74+20;ctx.fillStyle='#78573b';ctx.fillRect(x,221,10,38);circle(x+5,216,22,i%2?'#2cae67':'#4ccf77');circle(x-7,220,13,'#73df88');}
 }else if(w===1){
  hill(140,245,230,100,c[2]);hill(390,250,190,85,c[3]);
  for(let i=0;i<12;i++){let x=i*48+15, h=20+(i*17)%57;ctx.fillStyle=i%2?'#5268a0':'#435785';ctx.beginPath();ctx.moveTo(x-18,0);ctx.lineTo(x,h);ctx.lineTo(x+18,0);ctx.fill();}
  for(let i=0;i<12;i++){let x=20+i*44,y=210+(i%3)*20;ctx.fillStyle=i%2?'#6cf1e8':'#aa8dff';ctx.beginPath();ctx.moveTo(x,y-17);ctx.lineTo(x+12,y);ctx.lineTo(x,y+13);ctx.lineTo(x-12,y);ctx.fill();}
 }else if(w===2){
  circle(398,58,37,'#ffcf79');hill(150,230,240,120,c[2]);hill(380,235,220,135,c[3]);
  ctx.fillStyle='#ff7139';ctx.beginPath();ctx.moveTo(0,270);ctx.bezierCurveTo(130,225,190,302,300,260);ctx.bezierCurveTo(390,230,420,268,500,235);ctx.lineTo(500,300);ctx.lineTo(0,300);ctx.fill();
  for(let i=0;i<15;i++){let x=(i*83+27)%500,y=80+(i*41)%155;circle(x,y+Math.sin(t+i)*4,2+(i%3),'#ffdb73');}
 }else if(w===3){
  circle(409,62,28,'#fffdf0');hill(120,245,240,105,c[2]);hill(380,240,220,110,c[3]);
  for(let i=0;i<11;i++){let x=i*52-10,y=165+(i%3)*23;ctx.fillStyle=i%2?'#e9ffff':'#c2efff';ctx.beginPath();ctx.moveTo(x,y-48);ctx.lineTo(x+25,y+35);ctx.lineTo(x-26,y+35);ctx.fill();}
  for(let i=0;i<20;i++)circle((i*71)%500,((i*39+t*9)%310),2,'#ffffffcc');
 }else{
  for(let i=0;i<75;i++){let x=(i*137)%500,y=(i*83)%300;circle(x,y, i%7===0?2:1,'#ffffffcc');}
  circle(394,88,46,'#b784f5');circle(378,74,13,'#d9b7ff');circle(110,199,32,'#ffb8d4');
  ctx.save();ctx.translate(110,199);ctx.rotate(-0.3);ctx.strokeStyle='#ffd5f0';ctx.lineWidth=9;ctx.beginPath();ctx.ellipse(0,0,52,13,0,0,Math.PI*2);ctx.stroke();ctx.restore();
  hill(250,290,280,70,c[2]);
 }
 // Base suavemente sombreada para preservar contraste dos elementos do jogo.
 const shade=ctx.createLinearGradient(0,0,0,300);shade.addColorStop(0,'#07132615');shade.addColorStop(.6,'#07132600');shade.addColorStop(1,'#07132655');ctx.fillStyle=shade;ctx.fillRect(0,0,500,300);
}

// BOTÃO PRINCIPAL

function desenharQuadro(){
ctx.setTransform(umRenderScale,0,0,umRenderScale,0,0);
ctx.clearRect(0,0,500,300);
desenharCenarioCartoon();

const cor=picaretas[picaretaAtual][3];

texto(
picaretas[picaretaAtual][0],
250,56,20,
`rgb(${cor.join(",")})`,
"center"
);

desenharPicareta();

if(Date.now()-tempoGolpe>=100)diagonal=false;

desenharMinerio();

// Atalhos compactos para os três sistemas novos, sem ocupar os botões existentes.
const atalhos=[{x:300,nome:"MUNDO",cor:"#174d78",borda:"#78c8ff"},{x:337,nome:"OVOS",cor:"#66501b",borda:"#ffe08a"},{x:374,nome:"PETS",cor:"#28643a",borda:"#a8ef9b"},{x:411,nome:"RANK",cor:"#4b3b78",borda:"#c4a8ff"}];
atalhos.forEach(a=>{retangulo(a.x,5,35,30,a.cor,6);ctx.strokeStyle=a.borda;ctx.lineWidth=1;ctx.strokeRect(a.x+0.5,5.5,34,29);texto(a.nome,a.x+17.5,23,6.4,"#fff","center");});

if(mostrarRecompensa){
texto(recompensaTexto,350,85,25,"#ffdc00");

if(Date.now()-tempoRecompensa>=1000){
mostrarRecompensa=false;
}
}

// O indicador amarelo antigo do evento de dinheiro foi removido.
// O saldo permanece no local original; eventos ativos aparecem nos badges do canto.
texto("$ "+formatarDinheiro(moedas),420,288,23,"#ffdc00","right");

// BOTÃO DE RENASCIMENTO (canto superior esquerdo)
const gradRen=ctx.createLinearGradient(7,5,132,35);
gradRen.addColorStop(0,"#e7b94f");
gradRen.addColorStop(0.5,"#b77a22");
gradRen.addColorStop(1,"#754313");
retangulo(7,5,126,31,"#3b260c",7);
retangulo(9,7,122,27,gradRen,5);
texto("RENASCIMENTO",70,25,12,"#fff","center");

retangulo(450,5,42,30,"#343b55",6);
desenharEngrenagem(471,20);

// BOTÃO UPGRADES

const gradUpgrade=ctx.createLinearGradient(18,172,142,203);
gradUpgrade.addColorStop(0,"#9b59d0");
gradUpgrade.addColorStop(0.52,"#7134bd");
gradUpgrade.addColorStop(1,"#45206f");
retangulo(16,170,128,35,"#30144e",8);
retangulo(18,172,124,31,gradUpgrade,6);
texto("⬆ UPGRADES",80,193,15,"#fff","center");

// BOTÃO ADMIN

if(adminDesbloqueado&&usuarioAtual&&usuarioAtual.uid===ADMIN_UID){
const gradAdmin=ctx.createLinearGradient(18,127,142,158);
gradAdmin.addColorStop(0,"#c47bea");
gradAdmin.addColorStop(0.48,"#914bd0");
gradAdmin.addColorStop(1,"#54268d");
retangulo(16,125,128,35,"#30144e",8);
retangulo(18,127,124,31,gradAdmin,6);
texto("ADMIN",80,148,15,"#fff","center");
}

// BOTÃO SHOP

const g=ctx.createLinearGradient(20,220,20,275);
g.addColorStop(0,"#54a8ff");
g.addColorStop(0.45,"#2468d8");
g.addColorStop(1,"#123b91");

retangulo(16,216,128,63,"#081a3b",13);
retangulo(19,219,122,57,g,11);

ctx.strokeStyle="#8bc8ff";
ctx.lineWidth=2;
ctx.beginPath();
ctx.roundRect(20,220,120,55,10);
ctx.stroke();

retangulo(29,237,25,19,"#f4c542",4);
retangulo(29,233,25,7,"#ffe58a",3);
linha(41,234,41,256,"#9b6415",2);

texto("SHOP",91,254,21,"#fff","center");

// AUTO CLICK E ABERTURA AUTOMÁTICA DE OVOS

processarAutoClick();
processarOvosAutomaticos();

// PAINÉIS

if(lojaAberta)desenharLoja();
if(melhoriasAbertas)desenharMelhorias();
if(configuracoesAbertas)desenharConfiguracoes();

}

// Auto clicker por tempo decorrido: mantém 5/s (normal) e 25/s (Pro) mesmo com 30 ou 60 FPS.
function processarAutoClick(){
const agora=Date.now();
const pro=autoClickerProAtivo&&autoClickerProComprado;
const normal=!pro&&autoClickerAtivo&&autoClickerComprado;
const intervalo=pro?40:(normal?200:0);
if(!intervalo||codigoModalAberto||!jogoPronto()){
ultimoAutoClick=agora;
return;
}
let repeticoes=0;
while(agora-ultimoAutoClick>=intervalo&&repeticoes<4){
ultimoAutoClick+=intervalo;
minerar();
repeticoes++;
}
if(agora-ultimoAutoClick>=intervalo)ultimoAutoClick=agora;
}

// Se um quadro falhar, o jogo continua rodando em vez de congelar
function desenhar(){
try{desenharQuadro();}catch(erro){console.error("Erro ao desenhar:",erro);}
requestAnimationFrame(desenhar);
}

// POSIÇÃO

function posicao(evento){
const r=canvas.getBoundingClientRect();

return{
x:(evento.clientX-r.left)*500/r.width,
y:(evento.clientY-r.top)*300/r.height
};
}

// CLIQUES

canvas.addEventListener("pointerdown",evento=>{
iniciarAudio();

const p=posicao(evento);

if(!jogoPronto()||adminAberto)return;

// Atalhos dos novos sistemas (área superior direita).
if(!lojaAberta&&!melhoriasAbertas&&!configuracoesAbertas){
 if(p.y>=5&&p.y<=35&&p.x>=300&&p.x<335){abrirNovoModal("mundos");return;}
 if(p.y>=5&&p.y<=35&&p.x>=337&&p.x<372){abrirNovoModal("ovos");return;}
 if(p.y>=5&&p.y<=35&&p.x>=374&&p.x<409){abrirNovoModal("inventario");return;}
 if(p.y>=5&&p.y<=35&&p.x>=411&&p.x<=446){abrirNovoModal("ranking");return;}
}

// CONFIGURAÇÕES

if(configuracoesAbertas){

if(p.x>=435&&p.x<=463&&p.y>=40&&p.y<=68){
configuracoesAbertas=false;
somFecharLoja();
return;
}

// VOLUME

if(p.x>=80&&p.x<=430&&p.y>=94&&p.y<=139){
volumeArrastando=true;

volumeGeral=Math.max(0,Math.min(1,(p.x-90)/320));

if(masterGain){
masterGain.gain.setTargetAtTime(volumeGeral*1.8,audio.currentTime,0.03);
}

salvar();
canvas.setPointerCapture(evento.pointerId);
return;
}

// AUTO CLICK NORMAL

if(autoClickerComprado&&p.x>=45&&p.x<=455&&p.y>=145&&p.y<=175){
alternarAutoClicker();
return;
}

// AUTO CLICK PRO

if(autoClickerProComprado&&p.x>=45&&p.x<=455&&p.y>=179&&p.y<=209){
alternarAutoClickerPro();
return;
}

// TROCAR SENHA

if(p.x>=45&&p.x<=455&&p.y>=214&&p.y<=241){
abrirTrocaSenha();
return;
}

// CÓDIGOS

if(p.x>=45&&p.x<=235&&p.y>=246&&p.y<=274){
abrirResgate();
return;
}

// SAIR DA CONTA

if(p.x>=255&&p.x<=455&&p.y>=246&&p.y<=274){
sairDaConta();
return;
}

return;
}

// ADMIN: o painel agora é em HTML e cobre o canvas enquanto está aberto

// UPGRADES

if(melhoriasAbertas){

if(p.x>=435&&p.x<=463&&p.y>=18&&p.y<=46){
melhoriasAbertas=false;
somFecharLoja();
return;
}

// Lista única: todas as melhorias ficam no mesmo painel e podem ser roladas.
if(p.y>=TOPO_LISTA_MELHORIAS&&p.y<=TOPO_LISTA_MELHORIAS+ALTURA_LISTA_MELHORIAS){
 if(p.x>=350&&p.x<=465){const indice=Math.floor((p.y-TOPO_LISTA_MELHORIAS+scrollMelhorias)/ALTURA_LINHA_MELHORIA);comprarMelhoriaPorIndice(indice);return;}
 arrastandoMelhorias=true;inicioYMelhorias=p.y;scrollInicialMelhorias=scrollMelhorias;canvas.setPointerCapture(evento.pointerId);return;
}
return;
}

// LOJA

if(lojaAberta){

if(p.x>=435&&p.x<=463&&p.y>=40&&p.y<=68){
lojaAberta=false;
somFecharLoja();
return;
}

if(p.y>=72&&p.y<=100){
if(p.x>=45&&p.x<=220){
categoria="picaretas";
scroll=0;
somClique();
return;
}

if(p.x>=230&&p.x<=405){
categoria="minerios";
scroll=0;
somClique();
return;
}
}

if(p.x>=40&&p.x<=465&&p.y>=102&&p.y<=270){
arrastando=true;
moveuLista=false;
inicioY=p.y;
scrollInicial=scroll;
canvas.setPointerCapture(evento.pointerId);
}

}else{

if(p.x>=7&&p.x<=133&&p.y>=5&&p.y<=36){
abrirRenascimento();
return;

}else if(p.x>=450&&p.x<=492&&p.y>=5&&p.y<=35){
configuracoesAbertas=true;
somAbrirLoja();

}else if(adminDesbloqueado&&usuarioAtual&&usuarioAtual.uid===ADMIN_UID&&p.x>=15&&p.x<=145&&p.y>=125&&p.y<=160){
abrirAdmin();

}else if(p.x>=16&&p.x<=144&&p.y>=170&&p.y<=205){
melhoriasAbertas=true;
somAbrirLoja();

}else if(p.x>=20&&p.x<=140&&p.y>=220&&p.y<=275){
lojaAberta=true;
scroll=0;
somAbrirLoja();

}else{
minerar();
}
}

});

// ARRASTAR

canvas.addEventListener("pointermove",evento=>{

if(volumeArrastando){
const p=posicao(evento);

volumeGeral=Math.max(0,Math.min(1,(p.x-90)/320));

if(masterGain&&audio){
masterGain.gain.setTargetAtTime(volumeGeral*1.8,audio.currentTime,0.03);
}

salvar();
return;
}

if(arrastandoMelhorias){const p=posicao(evento);scrollMelhorias=Math.max(0,Math.min(Math.max(0,obterLinhasMelhorias().length*ALTURA_LINHA_MELHORIA-ALTURA_LISTA_MELHORIAS),scrollInicialMelhorias+(inicioYMelhorias-p.y)*1.25));return;}

if(!arrastando)return;

const p=posicao(evento);
const movimento=inicioY-p.y;

if(Math.abs(movimento)>5)moveuLista=true;

const total=categoria==="picaretas"?picaretas.length-1:minerios.length-1;

scroll=Math.max(
0,
Math.min(scrollInicial+Math.round(movimento/55),total-3)
);

});

// Rolagem por mouse/trackpad na lista de upgrades.
canvas.addEventListener("wheel",evento=>{
 if(!melhoriasAbertas)return;const r=canvas.getBoundingClientRect();const x=(evento.clientX-r.left)*500/r.width,y=(evento.clientY-r.top)*300/r.height;
 if(x>=15&&x<=485&&y>=TOPO_LISTA_MELHORIAS&&y<=TOPO_LISTA_MELHORIAS+ALTURA_LISTA_MELHORIAS){evento.preventDefault();const max=Math.max(0,obterLinhasMelhorias().length*ALTURA_LINHA_MELHORIA-ALTURA_LISTA_MELHORIAS);scrollMelhorias=Math.max(0,Math.min(max,scrollMelhorias+Math.sign(evento.deltaY)*ALTURA_LINHA_MELHORIA));}
},{passive:false});
window.addEventListener("keydown",evento=>{if(!melhoriasAbertas)return;const max=Math.max(0,obterLinhasMelhorias().length*ALTURA_LINHA_MELHORIA-ALTURA_LISTA_MELHORIAS);if(evento.key==="ArrowDown"){scrollMelhorias=Math.min(max,scrollMelhorias+ALTURA_LINHA_MELHORIA);evento.preventDefault();}else if(evento.key==="ArrowUp"){scrollMelhorias=Math.max(0,scrollMelhorias-ALTURA_LINHA_MELHORIA);evento.preventDefault();}});

// SOLTAR

canvas.addEventListener("pointerup",evento=>{

if(arrastandoMelhorias){arrastandoMelhorias=false;return;}

if(volumeArrastando){
volumeArrastando=false;
salvar();
return;
}

if(!arrastando)return;

const p=posicao(evento);

const linhaClicada=Math.floor((p.y-105)/55);
const dentroDaLinha=p.y>=105&&(p.y-105)-linhaClicada*55<=45;
if(!moveuLista&&dentroDaLinha&&p.x>=40&&p.x<=465&&p.y<=270){
selecionarItem(linhaClicada);
}

arrastando=false;

});

canvas.addEventListener("pointercancel",()=>{
arrastando=false;
arrastandoMelhorias=false;
volumeArrastando=false;
});

// ROLAGEM

canvas.addEventListener("wheel",evento=>{
if(!lojaAberta)return;

const p=posicao(evento);

if(p.x>=40&&p.x<=465&&p.y>=102&&p.y<=270){
scroll+=evento.deltaY>0?1:-1;
limitarScroll();
}

evento.preventDefault();

},{passive:false});

// TECLADO

document.addEventListener("keydown",evento=>{

const alvo=evento.target;
const digitando=alvo&&(alvo.tagName==="INPUT"||alvo.tagName==="TEXTAREA"||alvo.tagName==="SELECT"||alvo.isContentEditable);
if(digitando||codigoModalAberto||adminAberto||!jogoPronto())return;

if(evento.code==="Space"&&!lojaAberta&&!adminAberto&&!configuracoesAbertas&&!melhoriasAbertas){
evento.preventDefault();
iniciarAudio();
minerar();
return;
}

if(!lojaAberta)return;

if(evento.key==="ArrowDown"){
evento.preventDefault();
scroll++;
limitarScroll();
}

if(evento.key==="ArrowUp"){
evento.preventDefault();
scroll--;
limitarScroll();
}

if(evento.key==="ArrowRight"){
evento.preventDefault();
categoria="minerios";
scroll=0;
somClique();
}

if(evento.key==="ArrowLeft"){
evento.preventDefault();
categoria="picaretas";
scroll=0;
somClique();
}

});

// CONTROLES DOS NOVOS SISTEMAS
 document.querySelectorAll("[data-fechar-novo]").forEach(b=>b.addEventListener("click",fecharNovosModais));
 ["mundosModal","ovosPetsModal","inventarioPetsModal","rankingModal"].forEach(id=>document.getElementById(id).addEventListener("click",e=>{if(e.target.id===id)fecharNovosModais();}));
 document.getElementById("venderPetsModal").addEventListener("click",e=>{if(e.target.id==="venderPetsModal")document.getElementById("venderPetsModal").style.display="none";});
 document.getElementById("abrirVendaPets").addEventListener("click",()=>{modoVendaPets="raridade";petsMarcadosVenda.clear();renderizarModoVendaPets();document.getElementById("venderPetsModal").style.display="flex";});
 document.getElementById("fecharVendaPets").addEventListener("click",()=>{document.getElementById("venderPetsModal").style.display="none";});
 document.getElementById("comprarOvoPet").addEventListener("click",()=>abrirOvoPet(false));
 document.getElementById("abrirTresOvosPet").addEventListener("click",abrirTresOvosPet);
 document.getElementById("alternarAutoOvoPet").addEventListener("click",()=>{comprarOuAlternarAutoOvo();atualizarControlesOvo();});
 document.getElementById("botaoAFKOvos").addEventListener("click",()=>{painelAFKAberto=!painelAFKAberto;atualizarPainelAFK();});
 document.querySelectorAll("[data-pets-ordem]").forEach(b=>b.addEventListener("click",()=>{petsOrdenacao=b.dataset.petsOrdem;renderizarPets();}));
 document.getElementById("equiparMelhoresPets").addEventListener("click",equiparMelhoresPets);
 document.getElementById("fundirTodosDourados").addEventListener("click",fundirTodosPetsDourados);
 document.getElementById("desequiparPets").addEventListener("click",()=>{petsEquipados=[];salvar();renderizarPets();mostrarAviso("Todos os pets foram desequipados.","ok");});
 document.getElementById("venderPetsSelecionados").addEventListener("click",venderPetsSelecionados);
document.querySelectorAll("[data-modo-venda]").forEach(b=>b.addEventListener("click",()=>{modoVendaPets=b.dataset.modoVenda;petsMarcadosVenda.clear();renderizarModoVendaPets();}));
 document.getElementById("rankDinheiro").addEventListener("click",()=>{rankingTipo="dinheiro";document.getElementById("rankDinheiro").classList.add("ativa");document.getElementById("rankRenascimentos").classList.remove("ativa");if(rankingUltimoSnapshot)renderizarListaRanking(rankingUltimoSnapshot);else carregarRanking();});
 document.getElementById("rankRenascimentos").addEventListener("click",()=>{rankingTipo="renascimentos";document.getElementById("rankRenascimentos").classList.add("ativa");document.getElementById("rankDinheiro").classList.remove("ativa");if(rankingUltimoSnapshot)renderizarListaRanking(rankingUltimoSnapshot);else carregarRanking();});
 setInterval(atualizarContagemRanking,1000);

// INICIAR JOGO

atualizarControlesOvo();
iniciarSistemaLogin();
desenhar();